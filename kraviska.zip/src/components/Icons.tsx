import type { ReactNode, SVGProps } from "react";

type IconProps = SVGProps<SVGSVGElement>;

function Icon({ children, ...props }: IconProps & { children: ReactNode }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.5}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
      {...props}
    >
      {children}
    </svg>
  );
}

export const Asterisk = (props: IconProps) => (
  <Icon {...props}>
    <path d="M12 2.5v19M3.77 7.25l16.46 9.5M3.77 16.75l16.46-9.5" />
    <circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none" />
  </Icon>
);

export const Sparkle = (props: IconProps) => (
  <Icon {...props}>
    <path d="M12 2.75c.7 4.7 2.8 6.8 7.5 7.5-4.7.7-6.8 2.8-7.5 7.5-.7-4.7-2.8-6.8-7.5-7.5 4.7-.7 6.8-2.8 7.5-7.5Z" />
  </Icon>
);

export const ArrowUpRight = (props: IconProps) => (
  <Icon {...props}>
    <path d="M6.5 17.5 17.5 6.5M8 6.5h9.5V16" />
  </Icon>
);

export const ArrowUp = (props: IconProps) => (
  <Icon {...props}>
    <path d="M12 20V4.5M6 10.5l6-6 6 6" />
  </Icon>
);

export const ArrowDown = (props: IconProps) => (
  <Icon {...props}>
    <path d="M12 4v15.5M6 13.5l6 6 6-6" />
  </Icon>
);

export const ArrowRight = (props: IconProps) => (
  <Icon {...props}>
    <path d="M4 12h15.5M13.5 6l6 6-6 6" />
  </Icon>
);

export const ArrowLeft = (props: IconProps) => (
  <Icon {...props}>
    <path d="M20 12H4.5M10.5 6l-6 6 6 6" />
  </Icon>
);

export const X = (props: IconProps) => (
  <Icon {...props}>
    <path d="M6 6l12 12M18 6 6 18" />
  </Icon>
);

export const Plus = (props: IconProps) => (
  <Icon {...props}>
    <path d="M12 5v14M5 12h14" />
  </Icon>
);

export const Minus = (props: IconProps) => (
  <Icon {...props}>
    <path d="M5 12h14" />
  </Icon>
);

export const Lock = (props: IconProps) => (
  <Icon {...props}>
    <rect x="4.5" y="10.5" width="15" height="10" rx="1.5" />
    <path d="M8 10.5V8a4 4 0 0 1 8 0v2.5M12 14.5v2.5" />
  </Icon>
);

export const Unlock = (props: IconProps) => (
  <Icon {...props}>
    <rect x="4.5" y="10.5" width="15" height="10" rx="1.5" />
    <path d="M8 10.5V8a4 4 0 0 1 7.6-1.7M12 14.5v2.5" />
  </Icon>
);

export const SoundOn = (props: IconProps) => (
  <Icon {...props}>
    <path d="M4 9.5h3.5L12 5.5v13L7.5 14.5H4z" />
    <path d="M15.5 8.5a5 5 0 0 1 0 7M18 6a8.5 8.5 0 0 1 0 12" />
  </Icon>
);

export const SoundOff = (props: IconProps) => (
  <Icon {...props}>
    <path d="M4 9.5h3.5L12 5.5v13L7.5 14.5H4z" />
    <path d="M16 9l5 6M21 9l-5 6" />
  </Icon>
);

export const Upload = (props: IconProps) => (
  <Icon {...props}>
    <path d="M12 16.5V4.5M7.5 9 12 4.5 16.5 9M4.5 16v2.5a1.5 1.5 0 0 0 1.5 1.5h12a1.5 1.5 0 0 0 1.5-1.5V16" />
  </Icon>
);

export const Download = (props: IconProps) => (
  <Icon {...props}>
    <path d="M12 4.5v12M7.5 12l4.5 4.5 4.5-4.5M4.5 16v2.5A1.5 1.5 0 0 0 6 20h12a1.5 1.5 0 0 0 1.5-1.5V16" />
  </Icon>
);

export const Trash = (props: IconProps) => (
  <Icon {...props}>
    <path d="M4.5 7h15M9.5 7V4.5h5V7M7 7l.8 12.5h8.4L17 7M10 10.5v5.5M14 10.5v5.5" />
  </Icon>
);

export const Pencil = (props: IconProps) => (
  <Icon {...props}>
    <path d="m14.5 5.5 4 4M4.5 19.5l1-4.5 10-10 4 4-10 10z" />
  </Icon>
);

export const FileText = (props: IconProps) => (
  <Icon {...props}>
    <path d="M6 3.5h8l4 4v13H6zM14 3.5v4h4M9 11.5h6M9 15h6M9 18.5h3.5" />
  </Icon>
);

export const ImageIcon = (props: IconProps) => (
  <Icon {...props}>
    <rect x="3.5" y="4.5" width="17" height="15" rx="1.5" />
    <circle cx="8.75" cy="9.25" r="1.25" />
    <path d="m4.5 16 4.5-4 3.5 3 3-2.5 4 3.5" />
  </Icon>
);

export const AlertTriangle = (props: IconProps) => (
  <Icon {...props}>
    <path d="M12 3.5 22 20H2zM12 9v5M12 17v.4" />
  </Icon>
);

export const ChevronDown = (props: IconProps) => (
  <Icon {...props}>
    <path d="m5 9 7 7 7-7" />
  </Icon>
);

export const Check = (props: IconProps) => (
  <Icon {...props}>
    <path d="m4.5 12.5 5 5 10-11" />
  </Icon>
);

export const Instagram = (props: IconProps) => (
  <Icon {...props}>
    <rect x="3.5" y="3.5" width="17" height="17" rx="5" />
    <circle cx="12" cy="12" r="4" />
    <circle cx="17.2" cy="6.8" r="1" fill="currentColor" stroke="none" />
  </Icon>
);

export const TikTok = (props: IconProps) => (
  <Icon {...props}>
    <path d="M14 3.5v10.6a4.1 4.1 0 1 1-4.1-4.1" />
    <path d="M14 3.5c.4 2.6 2.1 4.3 4.8 4.6" />
  </Icon>
);

export const VGen = (props: IconProps) => (
  <Icon {...props}>
    <path d="m4 6 7.5 12L19 6" />
    <path d="M19 3.5v3M17.5 5h3" />
  </Icon>
);

export const Discord = (props: IconProps) => (
  <Icon {...props}>
    <path d="M6 6.5c3.5-1.6 8.5-1.6 12 0 1.5 3 2 6.2 1.8 9.8-1.6 1.3-3.4 2.2-5.3 2.7l-1-1.7c-1-.2-2-.2-3 0L9.5 19c-1.9-.5-3.7-1.4-5.3-2.7-.2-3.6.3-6.8 1.8-9.8Z" />
    <circle cx="9.3" cy="11.5" r="1" fill="currentColor" stroke="none" />
    <circle cx="14.7" cy="11.5" r="1" fill="currentColor" stroke="none" />
    <path d="M9.5 15c1.6 1 3.4 1 5 0" />
  </Icon>
);

export const Gumroad = (props: IconProps) => (
  <Icon {...props}>
    <path d="M5 8.5h14l-1 12H6zM8.5 8.5V6a3.5 3.5 0 0 1 7 0v2.5" />
    <path d="M9.5 14.5h5M9.5 17.5h3" />
  </Icon>
);

export const Payoneer = (props: IconProps) => (
  <Icon {...props}>
    <rect x="2.5" y="5.5" width="19" height="13" rx="2" />
    <path d="M2.5 10h19M6 14.5h4" />
    <path d="M17 12.5v3.5M15.2 14.3 17 16l1.8-1.7" />
  </Icon>
);

export const Steam = (props: IconProps) => (
  <Icon {...props}>
    <circle cx="12" cy="12" r="9" />
    <circle cx="15" cy="9.5" r="2.3" />
    <path d="M3.4 14.5 9 16.8M10.5 17l.3.1" />
    <circle cx="11.5" cy="16.5" r="1.6" />
  </Icon>
);

export const Folder = (props: IconProps) => (
  <Icon {...props}>
    <path d="M3.5 6.5h6l2 2h9v10.5h-17z" />
    <path d="M3.5 9h17" />
  </Icon>
);

export const FolderPlus = (props: IconProps) => (
  <Icon {...props}>
    <path d="M3.5 6.5h6l2 2h9v10.5h-17z" />
    <path d="M12 12v4.5M9.75 14.25h4.5" />
  </Icon>
);

export const Pin = (props: IconProps) => (
  <Icon {...props}>
    <path d="m9 4.5 6 6M14.5 3.5l6 6-3 1.5-3.5 3.5L15 20l-5-5-5-5 5 .5L13.5 7z" />
    <path d="m5.5 18.5-2 2" />
  </Icon>
);

export const Eraser = (props: IconProps) => (
  <Icon {...props}>
    <path d="m4.5 15.5 7-7 6 6-5 5H8zM12 9l4-4 5 5-4 4" />
    <path d="M8 19.5h12" />
  </Icon>
);

export const RotateCcw = (props: IconProps) => (
  <Icon {...props}>
    <path d="M4.5 9.5V4.5h5" />
    <path d="M4.9 8.6A8 8 0 1 1 4.5 14" />
  </Icon>
);

export const Save = (props: IconProps) => (
  <Icon {...props}>
    <path d="M4.5 4.5h12l3.5 3.5v11.5h-15.5z" />
    <path d="M8 4.5v5h7v-5M8 19.5v-6h8v6" />
  </Icon>
);

export const Scissors = (props: IconProps) => (
  <Icon {...props}>
    <circle cx="6.5" cy="6.5" r="2.5" />
    <circle cx="6.5" cy="17.5" r="2.5" />
    <path d="M8.8 8 20 17M8.8 16 20 7" />
  </Icon>
);

export const Waves = (props: IconProps) => (
  <Icon {...props}>
    <path d="M2.5 8c2-2 3.5-2 5.5 0s3.5 2 5.5 0 3.5-2 5.5 0 2 2 2.5 1" />
    <path d="M2.5 13c2-2 3.5-2 5.5 0s3.5 2 5.5 0 3.5-2 5.5 0 2 2 2.5 1" />
    <path d="M2.5 18c2-2 3.5-2 5.5 0s3.5 2 5.5 0 3.5-2 5.5 0 2 2 2.5 1" />
  </Icon>
);

export const History = (props: IconProps) => (
  <Icon {...props}>
    <path d="M3.5 12a8.5 8.5 0 1 0 2.6-6.1L3.5 8" />
    <path d="M3.2 3.5V8h4.5M12 7.5V12l3 2" />
  </Icon>
);

export const Shield = (props: IconProps) => (
  <Icon {...props}>
    <path d="M12 3 20 6v6c0 4.7-3.2 7.6-8 9-4.8-1.4-8-4.3-8-9V6z" />
    <path d="M9.5 12.2l1.9 1.9 3.4-3.6" />
  </Icon>
);

export const Sliders = (props: IconProps) => (
  <Icon {...props}>
    <path d="M4 7h9M16 7h4M4 17h4M11 17h9" />
    <circle cx="14.5" cy="7" r="1.8" />
    <circle cx="9.5" cy="17" r="1.8" />
  </Icon>
);

export const AlertBox = (props: IconProps) => (
  <Icon {...props}>
    <rect x="3.5" y="4.5" width="17" height="14" rx="2" />
    <path d="M12 8.5v4M12 15.5v.3M7 4.5 5 2M17 4.5 19 2" />
  </Icon>
);

export const Rewind = (props: IconProps) => (
  <Icon {...props}>
    <path d="M3.5 5v14l8-7zM12.5 5v14l8-7z" />
  </Icon>
);

export const Eye = (props: IconProps) => (
  <Icon {...props}>
    <path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z" />
    <circle cx="12" cy="12" r="2.6" />
  </Icon>
);

export const Menu = (props: IconProps) => (
  <Icon {...props}>
    <path d="M4 7h16M4 12h16M4 17h16" />
  </Icon>
);
