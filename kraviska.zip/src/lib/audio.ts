/**
 * Web Audio sound engine.
 *
 * Default motifs come from the shared SOUND_DEFS table so that the offline
 * renderer used by the Sound studio produces exactly the same waveform the
 * visitor hears. If an owner has saved a custom sound for an event, the
 * decoded buffer is played instead.
 */
import { getActiveSoundDef, getCachedSound, type SoundDef, type SoundEvent } from "@/lib/sound";

type AudioEngine = {
  ctx: AudioContext;
  master: GainNode;
  reverb: GainNode;
};

const SOUND_PREFERENCE_KEY = "kraviska.sound.v1";
let engine: AudioEngine | null = null;
let muted = readPreference();

function readPreference(): boolean {
  try {
    return window.localStorage.getItem(SOUND_PREFERENCE_KEY) === "off";
  } catch {
    return false;
  }
}

function buildReverb(ctx: AudioContext, master: GainNode): GainNode {
  const delay = ctx.createDelay(1);
  delay.delayTime.value = 0.28;
  const feedback = ctx.createGain();
  feedback.gain.value = 0.32;
  const wet = ctx.createGain();
  wet.gain.value = 0.28;
  delay.connect(feedback);
  feedback.connect(delay);
  delay.connect(wet);
  wet.connect(master);
  return wet;
}

function getEngine(): AudioEngine | null {
  if (typeof window === "undefined") return null;
  if (engine) {
    if (engine.ctx.state === "suspended") void engine.ctx.resume();
    return engine;
  }
  const AudioCtor =
    window.AudioContext ??
    (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AudioCtor) return null;

  const ctx = new AudioCtor();
  const master = ctx.createGain();
  master.gain.value = muted ? 0 : 0.85;
  master.connect(ctx.destination);
  engine = { ctx, master, reverb: buildReverb(ctx, master) };
  return engine;
}

export function primeAudio() {
  const e = getEngine();
  if (e && e.ctx.state === "suspended") void e.ctx.resume();
}

export function isSoundMuted() {
  return muted;
}

export function setSoundMuted(nextMuted: boolean) {
  muted = nextMuted;
  try {
    window.localStorage.setItem(SOUND_PREFERENCE_KEY, nextMuted ? "off" : "on");
  } catch {
    /* storage is optional */
  }
  const e = getEngine();
  if (e) {
    e.master.gain.cancelScheduledValues(e.ctx.currentTime);
    e.master.gain.setTargetAtTime(nextMuted ? 0 : 0.85, e.ctx.currentTime, 0.06);
  }
}

function voice(
  frequency: number,
  offset: number,
  duration: number,
  options: {
    level?: number;
    type?: OscillatorType;
    attack?: number;
    glide?: number;
  } = {},
) {
  const e = getEngine();
  if (!e || muted) return;
  const { ctx, master, reverb } = e;
  const start = ctx.currentTime + Math.max(0, offset);
  const attack = Math.min(options.attack ?? 0.09, duration * 0.4);
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = options.type ?? "sine";
  osc.frequency.setValueAtTime(frequency, start);
  if (options.glide) {
    osc.frequency.exponentialRampToValueAtTime(Math.max(30, options.glide), start + duration);
  }
  gain.gain.setValueAtTime(0.0001, start);
  gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, options.level ?? 0.035), start + attack);
  gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);
  osc.connect(gain);
  gain.connect(master);
  gain.connect(reverb);
  osc.start(start);
  osc.stop(start + duration + 0.08);
}

function air(offset: number, duration: number, level = 0.012) {
  const e = getEngine();
  if (!e || muted) return;
  const { ctx, master } = e;
  const buffer = ctx.createBuffer(1, Math.ceil(ctx.sampleRate * duration), ctx.sampleRate);
  const data = buffer.getChannelData(0);
  for (let index = 0; index < data.length; index += 1) {
    data[index] = (Math.random() * 2 - 1) * (1 - index / data.length);
  }
  const source = ctx.createBufferSource();
  source.buffer = buffer;
  const filter = ctx.createBiquadFilter();
  filter.type = "highpass";
  filter.frequency.value = 4200;
  const gain = ctx.createGain();
  gain.gain.value = level;
  source.connect(filter);
  filter.connect(gain);
  gain.connect(master);
  source.start(ctx.currentTime + Math.max(0, offset));
}

/** Play an owner-saved buffer if one exists. Returns true when handled. */
function playCustom(event: SoundEvent): boolean {
  const e = getEngine();
  if (!e || muted) return false;
  const buffer = getCachedSound(event);
  if (!buffer) return false;
  const source = e.ctx.createBufferSource();
  const gain = e.ctx.createGain();
  source.buffer = buffer;
  gain.gain.value = 1;
  source.connect(gain);
  gain.connect(e.master);
  source.start();
  return true;
}

function playDef(event: SoundEvent) {
  if (muted) return;
  if (playCustom(event)) return;
  const def = getActiveSoundDef(event);
  def.notes.forEach((note) => {
    voice(note.frequency, note.offset, note.duration, {
      level: note.level,
      type: note.type,
      attack: note.attack,
      glide: note.glide,
    });
  });
  if (def.air) air(def.air.offset, def.air.duration, def.air.level);
}

export function playHover() {
  const e = engine;
  if (!e || muted || e.ctx.state !== "running") return;
  if (playCustom("hover")) return;
  const def = getActiveSoundDef("hover");
  const nudge = 1 + ((Math.floor(performance.now()) / 40) % 4) * 0.006;
  def.notes.forEach((note) => {
    voice(note.frequency * nudge, note.offset, note.duration, {
      level: note.level,
      type: note.type,
      attack: note.attack,
      glide: note.glide ? note.glide * nudge : undefined,
    });
  });
}

export function playClick() {
  primeAudio();
  playDef("click");
}

export function playEnterPage() {
  primeAudio();
  playDef("enter");
}

export function playExitPage() {
  primeAudio();
  playDef("exit");
}

export function playWelcome() {
  playEnterPage();
}

export function playOpen() {
  primeAudio();
  playDef("open");
}

export function playClose() {
  primeAudio();
  playDef("close");
}

export function playSaved() {
  primeAudio();
  playDef("saved");
}

/** Audition a built-in sound definition directly, without saving it. */
export function previewSoundDef(def: SoundDef) {
  primeAudio();
  if (muted) return;
  def.notes.forEach((note) => {
    voice(note.frequency, note.offset, note.duration, {
      level: note.level,
      type: note.type,
      attack: note.attack,
      glide: note.glide,
    });
  });
  if (def.air) air(def.air.offset, def.air.duration, def.air.level);
}

/** Audition a raw sample buffer from the Sound studio. */
export function previewSamples(samples: Float32Array, sampleRate: number, gain = 1) {
  primeAudio();
  const e = getEngine();
  if (!e || muted) return;
  const buffer = e.ctx.createBuffer(1, Math.max(1, samples.length), sampleRate);
  buffer.getChannelData(0).set(samples);
  const source = e.ctx.createBufferSource();
  const amp = e.ctx.createGain();
  amp.gain.value = Math.max(0, Math.min(2, gain));
  source.buffer = buffer;
  source.connect(amp);
  amp.connect(e.master);
  source.start();
}
