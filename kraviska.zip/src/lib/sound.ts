/**
 * Sound definitions, offline rendering and custom sound storage.
 *
 * Owners can open Studio → Sound, inspect the waveform, select a portion,
 * trim it, erase silences, add grain, fade, and save the result for a specific
 * interface event. Saved sounds live in IndexedDB with a small metadata map in
 * localStorage.
 */
import { deleteMedia, getMedia, putMedia } from "@/lib/mediaStore";

export type SoundEvent =
  | "enter"
  | "exit"
  | "hover"
  | "click"
  | "open"
  | "close"
  | "saved";

export type SoundNote = {
  frequency: number;
  offset: number;
  duration: number;
  level: number;
  type?: OscillatorType;
  attack?: number;
  glide?: number;
};

export type SoundDef = {
  label: string;
  description: string;
  duration: number;
  notes: SoundNote[];
  air?: { offset: number; duration: number; level: number };
};

const UP = [130.81, 155.56, 196.0, 246.94, 311.13, 392.0, 493.88];

const enterNotes: SoundNote[] = UP.flatMap((frequency, index) => [
  {
    frequency,
    offset: index * 0.92,
    duration: 6.4 - index * 0.22,
    level: 0.037 - index * 0.0025,
    attack: 1.35,
  },
  {
    frequency: frequency * 2,
    offset: index * 0.92,
    duration: 4.2,
    level: 0.007,
    type: "triangle" as OscillatorType,
    attack: 1.6,
  },
]);

const exitNotes: SoundNote[] = [...UP].reverse().flatMap((frequency, index) => [
  {
    frequency,
    offset: index * 0.7,
    duration: 4.6 - index * 0.16,
    level: 0.03 - index * 0.002,
    attack: 0.55,
    glide: frequency * 0.97,
  },
  {
    frequency: frequency / 2,
    offset: index * 0.7,
    duration: 5.2,
    level: 0.01,
    type: "triangle" as OscillatorType,
    attack: 0.8,
  },
]);

export const SOUND_DEFS: Record<SoundEvent, SoundDef> = {
  enter: {
    label: "Enter a page",
    description: "Seven slow notes rising from low to high.",
    duration: 9.2,
    notes: [...enterNotes, { frequency: 65.41, offset: 0, duration: 7.6, level: 0.025, attack: 2.2 }],
    air: { offset: 1.2, duration: 2.6, level: 0.0045 },
  },
  exit: {
    label: "Leave a page",
    description: "The same motif reversed, high to low.",
    duration: 9.2,
    notes: [
      ...exitNotes,
      { frequency: 65.41, offset: 0.55, duration: 6.2, level: 0.023, attack: 1.1, glide: 55 },
    ],
    air: { offset: 0.4, duration: 1.6, level: 0.0045 },
  },
  hover: {
    label: "Hover",
    description: "A barely-there breath under the pointer.",
    duration: 2.2,
    notes: [
      { frequency: 1320, offset: 0, duration: 1.35, level: 0.0055, attack: 0.34, glide: 1120 },
    ],
  },
  click: {
    label: "Click",
    description: "A muted, water-like response.",
    duration: 1.9,
    notes: [
      { frequency: 256, offset: 0, duration: 1.15, level: 0.032, attack: 0.16, glide: 174 },
      { frequency: 384, offset: 0.06, duration: 0.9, level: 0.012, type: "triangle", attack: 0.2 },
    ],
    air: { offset: 0, duration: 0.28, level: 0.008 },
  },
  open: {
    label: "Dialog opens",
    description: "A soft rising interval as a panel appears.",
    duration: 3.1,
    notes: [
      { frequency: 349.23, offset: 0, duration: 1.8, level: 0.025, attack: 0.42, glide: 523.25 },
      { frequency: 698.46, offset: 0.24, duration: 2.3, level: 0.013, attack: 0.55 },
    ],
  },
  close: {
    label: "Dialog closes",
    description: "A receding interval as a panel closes.",
    duration: 3.4,
    notes: [
      { frequency: 523.25, offset: 0, duration: 2.1, level: 0.024, attack: 0.32, glide: 349.23 },
      { frequency: 261.63, offset: 0.18, duration: 2.4, level: 0.012, type: "triangle", attack: 0.5 },
    ],
  },
  saved: {
    label: "Saved confirmation",
    description: "Warm notes confirming a change was stored.",
    duration: 4.2,
    notes: [392, 493.88, 587.33].map((frequency, index) => ({
      frequency,
      offset: index * 0.62,
      duration: 3.8,
      level: 0.027,
      attack: 0.7,
    })),
  },
};

export const SOUND_EVENTS = Object.keys(SOUND_DEFS) as SoundEvent[];

export type SoundPreset = {
  id: string;
  name: string;
  description: string;
  def: SoundDef;
};

type PresetVoice = {
  id: string;
  name: string;
  description: string;
  octave?: number;
  type?: OscillatorType;
  rhythm?: number;
  durationScale?: number;
  levelScale?: number;
  attackScale?: number;
  overtone?: { ratio: number; level: number; type?: OscillatorType };
  airScale?: number;
  glideScale?: number;
};

const PRESET_VOICES: PresetVoice[] = [
  {
    id: "original",
    name: "Original motif",
    description: "The site's original slow motif, untouched.",
  },
  {
    id: "midnight-glass",
    name: "Midnight glass",
    description: "A glassier reading one octave brighter, with a quick silver overtone.",
    octave: 1,
    rhythm: 0.94,
    durationScale: 0.82,
    levelScale: 0.82,
    overtone: { ratio: 2.01, level: 0.16 },
  },
  {
    id: "deep-current",
    name: "Deep current",
    description: "Lower, slower and heavier, like a note moving through deep water.",
    octave: -1,
    rhythm: 1.2,
    durationScale: 1.15,
    levelScale: 1.1,
    attackScale: 1.15,
    airScale: 1.2,
  },
  {
    id: "cedar-hush",
    name: "Cedar hush",
    description: "A warm wooden triangle with a long, quiet bloom.",
    type: "triangle",
    rhythm: 1.12,
    durationScale: 1.25,
    levelScale: 0.88,
    attackScale: 1.2,
    overtone: { ratio: 3, level: 0.08 },
  },
  {
    id: "paper-chime",
    name: "Paper chime",
    description: "Short, light chimes that fold away quickly.",
    octave: 1,
    rhythm: 0.8,
    durationScale: 0.62,
    levelScale: 0.95,
    airScale: 0.6,
  },
  {
    id: "ember-glow",
    name: "Ember glow",
    description: "A richer, warmer interval with a low amber overtone.",
    type: "triangle",
    rhythm: 0.95,
    durationScale: 1,
    levelScale: 1.02,
    overtone: { ratio: 1.5, level: 0.15 },
  },
  {
    id: "frost-bells",
    name: "Frost bells",
    description: "High, delicate bells with a fine frosted tail.",
    octave: 2,
    rhythm: 1.05,
    durationScale: 0.9,
    levelScale: 0.5,
    airScale: 1.3,
  },
  {
    id: "submerged",
    name: "Submerged",
    description: "Everything is slowed and bent downward, as if heard underwater.",
    octave: -1,
    rhythm: 1.28,
    durationScale: 1.2,
    levelScale: 1.05,
    attackScale: 1.35,
    glideScale: 0.88,
    airScale: 1.5,
  },
  {
    id: "sea-glass",
    name: "Sea glass",
    description: "A smooth, rounded triangle with a soft fifth above.",
    type: "triangle",
    rhythm: 1.06,
    durationScale: 0.9,
    levelScale: 0.9,
    overtone: { ratio: 2.5, level: 0.12 },
  },
  {
    id: "night-tide",
    name: "Night tide",
    description: "Very low, very slow and wide — the longest option for this action.",
    octave: -1,
    type: "triangle",
    rhythm: 1.28,
    durationScale: 1.25,
    levelScale: 0.82,
    attackScale: 1.5,
    airScale: 1.8,
    overtone: { ratio: 0.5, level: 0.12 },
  },
];

function buildPresetDef(base: SoundDef, voice: PresetVoice): SoundDef {
  if (voice.id === "original") return { ...base, description: voice.description };
  const rhythm = voice.rhythm ?? 1;
  const durationScale = voice.durationScale ?? 1;
  const levelScale = voice.levelScale ?? 1;
  const attackScale = voice.attackScale ?? 1;
  const octave = voice.octave ?? 0;
  const ratio = 2 ** octave;
  const glideScale = voice.glideScale ?? 1;
  const notes: SoundNote[] = [];
  base.notes.forEach((note) => {
    const frequency = note.frequency * ratio;
    const duration = Math.max(0.06, note.duration * durationScale);
    notes.push({
      ...note,
      frequency,
      offset: note.offset * rhythm,
      duration,
      level: Math.max(0.0012, note.level * levelScale),
      type: voice.type ?? note.type,
      attack: Math.min(duration * 0.45, (note.attack ?? 0.1) * attackScale),
      glide: note.glide ? note.glide * ratio * glideScale : undefined,
    });
    if (voice.overtone) {
      notes.push({
        frequency: frequency * voice.overtone.ratio,
        offset: note.offset * rhythm + Math.min(0.12, duration * 0.1),
        duration: Math.max(0.05, duration * 0.74),
        level: Math.max(0.0008, note.level * levelScale * voice.overtone.level),
        type: voice.overtone.type ?? "triangle",
        attack: Math.min(duration * 0.4, (note.attack ?? 0.1) * attackScale * 1.1),
      });
    }
  });
  const longest = notes.reduce((end, note) => Math.max(end, note.offset + note.duration), 0);
  return {
    label: base.label,
    description: voice.description,
    duration: Math.min(18, Math.max(longest + 0.8, base.duration * rhythm * 0.85)),
    notes,
    air: base.air
      ? {
          offset: base.air.offset * rhythm,
          duration: base.air.duration * (voice.airScale ?? 1),
          level: base.air.level * (voice.airScale ?? 1) * 0.8,
        }
      : undefined,
  };
}

export const SOUND_PRESETS: Record<SoundEvent, SoundPreset[]> = Object.fromEntries(
  SOUND_EVENTS.map((event) => [
    event,
    PRESET_VOICES.map((voice) => ({
      id: voice.id,
      name: voice.name,
      description: voice.description,
      def: buildPresetDef(SOUND_DEFS[event], voice),
    })),
  ]),
) as Record<SoundEvent, SoundPreset[]>;

const PRESET_SETTINGS_KEY = "kraviska.sounds.presets.v1";

function readPresetSettings(): Partial<Record<SoundEvent, string>> {
  try {
    const raw = window.localStorage.getItem(PRESET_SETTINGS_KEY);
    return raw ? (JSON.parse(raw) as Partial<Record<SoundEvent, string>>) : {};
  } catch {
    return {};
  }
}

export function getSelectedPreset(event: SoundEvent): string {
  const value = readPresetSettings()[event];
  return SOUND_PRESETS[event].some((preset) => preset.id === value) ? value ?? "original" : "original";
}

export function setSelectedPreset(event: SoundEvent, presetId: string) {
  if (!SOUND_PRESETS[event].some((preset) => preset.id === presetId)) return;
  const settings = readPresetSettings();
  settings[event] = presetId;
  try {
    window.localStorage.setItem(PRESET_SETTINGS_KEY, JSON.stringify(settings));
  } catch {
    /* preset choice is still applied to this session via the audio layer */
  }
  window.dispatchEvent(new Event(SOUND_EVENT_NAME));
}

export function getSoundPreset(event: SoundEvent, presetId: string): SoundPreset {
  return (
    SOUND_PRESETS[event].find((preset) => preset.id === presetId) ??
    SOUND_PRESETS[event][0]
  );
}

/** The built-in sound currently selected for an event. */
export function getActiveSoundDef(event: SoundEvent): SoundDef {
  return getSoundPreset(event, getSelectedPreset(event)).def;
}

const SETTINGS_KEY = "kraviska.sounds.custom.v1";
const SOUND_EVENT_NAME = "kraviska:sounds-changed";

export type CustomSoundMeta = {
  key: string;
  duration: number;
  editedAt: string;
};

type SoundSettings = Partial<Record<SoundEvent, CustomSoundMeta>>;

const cache = new Map<SoundEvent, AudioBuffer>();
let decodeContext: OfflineAudioContext | null = null;

function getDecodeContext(): OfflineAudioContext {
  if (!decodeContext) {
    const Ctor =
      window.OfflineAudioContext ??
      (window as unknown as { webkitOfflineAudioContext?: typeof OfflineAudioContext })
        .webkitOfflineAudioContext;
    decodeContext = new Ctor(1, 1, 44100);
  }
  return decodeContext;
}

function readSettings(): SoundSettings {
  try {
    const raw = window.localStorage.getItem(SETTINGS_KEY);
    return raw ? (JSON.parse(raw) as SoundSettings) : {};
  } catch {
    return {};
  }
}

function writeSettings(settings: SoundSettings) {
  try {
    window.localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch {
    /* storage is optional */
  }
  window.dispatchEvent(new Event(SOUND_EVENT_NAME));
}

export function getSoundSettings(): SoundSettings {
  return readSettings();
}

export function subscribeSoundChanges(listener: () => void) {
  window.addEventListener(SOUND_EVENT_NAME, listener);
  return () => window.removeEventListener(SOUND_EVENT_NAME, listener);
}

export function getCachedSound(event: SoundEvent): AudioBuffer | undefined {
  return cache.get(event);
}

export async function loadCustomSounds(): Promise<void> {
  const settings = readSettings();
  await Promise.all(
    SOUND_EVENTS.map(async (event) => {
      const meta = settings[event];
      if (!meta) {
        cache.delete(event);
        return;
      }
      try {
        const blob = await getMedia(meta.key);
        if (!blob) {
          cache.delete(event);
          return;
        }
        const buffer = await blob.arrayBuffer();
        const decoded = await getDecodeContext().decodeAudioData(buffer.slice(0));
        cache.set(event, decoded);
      } catch {
        cache.delete(event);
      }
    }),
  );
}

export async function renderBaseSound(
  event: SoundEvent,
  presetId?: string,
): Promise<{ samples: Float32Array; sampleRate: number }> {
  const def = presetId ? getSoundPreset(event, presetId).def : getActiveSoundDef(event);
  const sampleRate = 22050;
  const Ctor =
    window.OfflineAudioContext ??
    (window as unknown as { webkitOfflineAudioContext?: typeof OfflineAudioContext })
      .webkitOfflineAudioContext;
  const ctx = new Ctor(1, Math.ceil(sampleRate * def.duration), sampleRate);
  const master = ctx.createGain();
  master.gain.value = 0.9;
  master.connect(ctx.destination);

  def.notes.forEach((note) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const start = Math.max(0, note.offset);
    const duration = Math.min(note.duration, def.duration - start);
    if (duration <= 0.03) return;
    const attack = Math.min(note.attack ?? 0.1, duration * 0.4);
    osc.type = note.type ?? "sine";
    osc.frequency.setValueAtTime(note.frequency, start);
    if (note.glide) {
      osc.frequency.exponentialRampToValueAtTime(Math.max(30, note.glide), start + duration);
    }
    gain.gain.setValueAtTime(0.0001, start);
    gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, note.level), start + attack);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);
    osc.connect(gain);
    gain.connect(master);
    osc.start(start);
    osc.stop(start + duration + 0.05);
  });

  if (def.air) {
    const length = Math.ceil(sampleRate * def.air.duration);
    const buffer = ctx.createBuffer(1, length, sampleRate);
    const data = buffer.getChannelData(0);
    for (let index = 0; index < length; index += 1) {
      data[index] = (Math.random() * 2 - 1) * (1 - index / length);
    }
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    const gain = ctx.createGain();
    gain.gain.value = def.air.level;
    source.connect(gain);
    gain.connect(master);
    source.start(Math.max(0, def.air.offset));
  }

  const rendered = await ctx.startRendering();
  return { samples: rendered.getChannelData(0).slice(), sampleRate: rendered.sampleRate };
}

export async function getSoundForEditing(
  event: SoundEvent,
  options: { builtIn?: boolean } = {},
): Promise<{ samples: Float32Array; sampleRate: number; custom: boolean }> {
  const meta = options.builtIn ? undefined : readSettings()[event];
  if (meta) {
    try {
      const blob = await getMedia(meta.key);
      if (blob) {
        const decoded = await getDecodeContext().decodeAudioData(await blob.arrayBuffer());
        return {
          samples: decoded.getChannelData(0).slice(),
          sampleRate: decoded.sampleRate,
          custom: true,
        };
      }
    } catch {
      /* fall back to the built-in motif */
    }
  }
  const base = await renderBaseSound(event);
  return { ...base, custom: false };
}

/** Render a specific built-in choice without changing the saved selection. */
export async function renderPresetSound(
  event: SoundEvent,
  presetId: string,
): Promise<{ samples: Float32Array; sampleRate: number }> {
  return renderBaseSound(event, presetId);
}

export function eraseSilence(
  samples: Float32Array,
  sampleRate: number,
  threshold = 0.004,
  minGap = 0.22,
): Float32Array {
  const keep: Array<[number, number]> = [];
  const minSamples = Math.ceil(minGap * sampleRate);
  let start = -1;
  for (let index = 0; index < samples.length; index += 1) {
    if (Math.abs(samples[index]) > threshold) {
      if (start === -1) start = index;
    } else if (start !== -1 && index - start > 40) {
      keep.push([start, index]);
      start = -1;
    }
  }
  if (start !== -1) keep.push([start, samples.length]);
  if (keep.length === 0) return samples;
  const merged: Array<[number, number]> = [];
  keep.forEach((range) => {
    const last = merged[merged.length - 1];
    if (last && range[0] - last[1] < minSamples) last[1] = range[1];
    else merged.push([...range] as [number, number]);
  });
  const pad = Math.ceil(0.02 * sampleRate);
  const total = merged.reduce((sum, [a, b]) => sum + (b - a) + pad * 2, 0);
  const out = new Float32Array(total);
  let cursor = 0;
  merged.forEach(([a, b]) => {
    const from = Math.max(0, a - pad);
    const to = Math.min(samples.length, b + pad);
    out.set(samples.subarray(from, to), cursor);
    cursor += to - from + pad;
  });
  return out.subarray(0, Math.min(out.length, cursor));
}

export function normalizeSamples(samples: Float32Array, target = 0.82): Float32Array {
  let peak = 0;
  for (let index = 0; index < samples.length; index += 1) {
    peak = Math.max(peak, Math.abs(samples[index]));
  }
  if (peak === 0) return samples;
  const factor = target / peak;
  const out = new Float32Array(samples.length);
  for (let index = 0; index < samples.length; index += 1) out[index] = samples[index] * factor;
  return out;
}

export type EditOptions = {
  gain: number;
  noise: number;
  fadeIn: number;
  fadeOut: number;
  speed: number;
  reverse: boolean;
  reverb: number;
  echo: number;
  warmth: number;
};

function reverseSamples(samples: Float32Array): Float32Array {
  const out = new Float32Array(samples.length);
  for (let index = 0; index < samples.length; index += 1) {
    out[index] = samples[samples.length - 1 - index];
  }
  return out;
}

/** Change speed by resampling. Values below 1 slow the sound and lower its pitch. */
export function changeSpeed(samples: Float32Array, speed: number): Float32Array {
  const factor = Math.max(0.25, Math.min(3, speed));
  if (Math.abs(factor - 1) < 0.001) return samples;
  const length = Math.max(1, Math.floor(samples.length / factor));
  const out = new Float32Array(length);
  for (let index = 0; index < length; index += 1) {
    const position = index * factor;
    const low = Math.floor(position);
    const high = Math.min(samples.length - 1, low + 1);
    const fraction = position - low;
    out[index] = samples[low] * (1 - fraction) + samples[high] * fraction;
  }
  return out;
}

function applyEcho(samples: Float32Array, sampleRate: number, mix: number): Float32Array {
  if (mix <= 0) return samples;
  const delay = Math.max(1, Math.floor(sampleRate * 0.19));
  const out = new Float32Array(samples.length + Math.floor(delay * 2.2));
  out.set(samples, 0);
  for (let index = delay; index < out.length; index += 1) {
    out[index] += (out[index - delay] || samples[index] || 0) * 0.32 * Math.min(1, mix);
  }
  return out;
}

function applyReverb(samples: Float32Array, sampleRate: number, mix: number): Float32Array {
  if (mix <= 0) return samples;
  const taps = [0.071, 0.113, 0.179, 0.257, 0.383];
  const gains = [0.2, 0.16, 0.12, 0.09, 0.06];
  const tail = Math.floor(sampleRate * taps[taps.length - 1]) + 1;
  const out = new Float32Array(samples.length + tail);
  out.set(samples, 0);
  taps.forEach((tap, tapIndex) => {
    const offset = Math.floor(sampleRate * tap);
    const gain = gains[tapIndex] * Math.min(1, mix);
    for (let index = offset; index < out.length; index += 1) {
      out[index] += (samples[index - offset] ?? 0) * gain;
    }
  });
  return out;
}

function applyWarmth(samples: Float32Array, sampleRate: number, warmth: number): Float32Array {
  if (warmth <= 0.001) return samples;
  const cutoff = Math.max(320, 16000 - warmth * 15600);
  const alpha = 1 - Math.exp((-2 * Math.PI * cutoff) / sampleRate);
  const out = new Float32Array(samples.length);
  let previous = 0;
  for (let index = 0; index < samples.length; index += 1) {
    previous += alpha * (samples[index] - previous);
    out[index] = previous;
  }
  return out;
}

export function renderEdited(samples: Float32Array, sampleRate: number, options: EditOptions): Float32Array {
  let working = options.reverse ? reverseSamples(samples) : samples;
  working = changeSpeed(working, options.speed);
  working = applyWarmth(working, sampleRate, options.warmth);
  working = applyEcho(working, sampleRate, options.echo);
  working = applyReverb(working, sampleRate, options.reverb);

  const out = new Float32Array(working.length);
  const fadeInSamples = Math.floor(options.fadeIn * sampleRate);
  const fadeOutSamples = Math.floor(options.fadeOut * sampleRate);
  for (let index = 0; index < working.length; index += 1) {
    let envelope = 1;
    if (fadeInSamples > 0 && index < fadeInSamples) envelope *= index / fadeInSamples;
    if (fadeOutSamples > 0 && index > working.length - fadeOutSamples) {
      envelope *= Math.max(0, (working.length - index) / fadeOutSamples);
    }
    const grain = options.noise > 0 ? (Math.random() * 2 - 1) * options.noise : 0;
    const value = (working[index] * envelope + grain) * options.gain;
    out[index] = Math.max(-1, Math.min(1, value));
  }
  return out;
}

export function encodeWav(samples: Float32Array, sampleRate: number): Blob {
  const bytesPerSample = 2;
  const buffer = new ArrayBuffer(44 + samples.length * bytesPerSample);
  const view = new DataView(buffer);
  const writeString = (offset: number, value: string) => {
    for (let index = 0; index < value.length; index += 1) {
      view.setUint8(offset + index, value.charCodeAt(index));
    }
  };
  writeString(0, "RIFF");
  view.setUint32(4, 36 + samples.length * bytesPerSample, true);
  writeString(8, "WAVE");
  writeString(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * bytesPerSample, true);
  view.setUint16(32, bytesPerSample, true);
  view.setUint16(34, 16, true);
  writeString(36, "data");
  view.setUint32(40, samples.length * bytesPerSample, true);
  let offset = 44;
  for (let index = 0; index < samples.length; index += 1) {
    const clamped = Math.max(-1, Math.min(1, samples[index]));
    view.setInt16(offset, clamped < 0 ? clamped * 0x8000 : clamped * 0x7fff, true);
    offset += 2;
  }
  return new Blob([view], { type: "audio/wav" });
}

export async function saveCustomSound(
  event: SoundEvent,
  samples: Float32Array,
  sampleRate: number,
): Promise<{ ok: boolean; error?: string }> {
  try {
    const key = `sound-${event}-${Date.now()}`;
    const blob = encodeWav(samples, sampleRate);
    await putMedia(key, blob);
    const settings = readSettings();
    const previous = settings[event];
    settings[event] = {
      key,
      duration: samples.length / sampleRate,
      editedAt: new Date().toISOString(),
    };
    writeSettings(settings);
    if (previous?.key) await deleteMedia(previous.key);
    await loadCustomSounds();
    return { ok: true };
  } catch {
    return { ok: false, error: "That sound could not be stored in this browser." };
  }
}

export async function clearCustomSound(event: SoundEvent): Promise<void> {
  const settings = readSettings();
  const previous = settings[event];
  delete settings[event];
  writeSettings(settings);
  if (previous?.key) await deleteMedia(previous.key);
  cache.delete(event);
}

/** Small utility used by the waveform canvas. */
export function peaks(samples: Float32Array, buckets: number): number[] {
  const result = new Array(buckets).fill(0);
  const step = Math.max(1, Math.floor(samples.length / buckets));
  for (let bucket = 0; bucket < buckets; bucket += 1) {
    let peak = 0;
    const start = bucket * step;
    const end = Math.min(samples.length, start + step);
    for (let index = start; index < end; index += 1) {
      peak = Math.max(peak, Math.abs(samples[index]));
    }
    result[bucket] = peak;
  }
  return result;
}
