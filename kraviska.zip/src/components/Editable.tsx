import { useEffect, useRef, useState } from "react";
import type { ElementType, KeyboardEvent } from "react";
import { Check, Pencil, X } from "@/components/Icons";

type EditableTextProps = {
  value: string;
  onChange: (value: string) => void;
  owner: boolean;
  as?: ElementType;
  className?: string;
  multiline?: boolean;
  label?: string;
  maxLength?: number;
};

/**
 * Owner-only inline text editing. Visitors receive plain, semantic markup;
 * owners can click the highlighted text to swap in an input.
 */
export function EditableText({
  value,
  onChange,
  owner,
  as: Tag = "span",
  className = "",
  multiline = false,
  label = "Edit text",
  maxLength = 1200,
}: EditableTextProps) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value);
  const inputRef = useRef<HTMLInputElement | HTMLTextAreaElement | null>(null);

  useEffect(() => {
    if (!editing) setDraft(value);
  }, [value, editing]);

  useEffect(() => {
    if (!editing) return;
    const timer = window.setTimeout(() => {
      inputRef.current?.focus();
      inputRef.current?.select();
    }, 40);
    return () => window.clearTimeout(timer);
  }, [editing]);

  if (!owner) return <Tag className={className}>{value}</Tag>;

  const save = () => {
    const next = draft.trim();
    if (next) onChange(next);
    setEditing(false);
  };

  const cancel = () => {
    setDraft(value);
    setEditing(false);
  };

  const onKeyDown = (event: KeyboardEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    if (event.key === "Escape") {
      event.preventDefault();
      cancel();
      return;
    }
    if (event.key === "Enter" && (!multiline || event.metaKey || event.ctrlKey)) {
      event.preventDefault();
      save();
    }
  };

  if (editing) {
    return (
      <Tag className={`${className} editable-active`}>
        {multiline ? (
          <textarea
            ref={(node) => {
              inputRef.current = node;
            }}
            className="editable-input editable-textarea"
            value={draft}
            onChange={(event) => setDraft(event.target.value)}
            onKeyDown={onKeyDown}
            rows={3}
            maxLength={maxLength}
            aria-label={label}
          />
        ) : (
          <input
            ref={(node) => {
              inputRef.current = node;
            }}
            className="editable-input"
            value={draft}
            onChange={(event) => setDraft(event.target.value)}
            onKeyDown={onKeyDown}
            maxLength={maxLength}
            aria-label={label}
          />
        )}
        <span className="editable-actions">
          <button type="button" className="editable-action is-save" onClick={save} aria-label="Save text">
            <Check className="h-3 w-3" />
          </button>
          <button type="button" className="editable-action" onClick={cancel} aria-label="Cancel editing">
            <X className="h-3 w-3" />
          </button>
        </span>
      </Tag>
    );
  }

  return (
    <Tag
      className={`${className} editable-owner`}
      onClick={(event: React.MouseEvent) => {
        event.preventDefault();
        event.stopPropagation();
        setEditing(true);
      }}
      role="button"
      tabIndex={0}
      title={label}
      onKeyDown={(event: KeyboardEvent) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          setEditing(true);
        }
      }}
    >
      {value}
      <Pencil className="editable-pencil" />
    </Tag>
  );
}
