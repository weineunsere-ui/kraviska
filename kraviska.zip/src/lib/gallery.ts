import { useCallback, useEffect, useState } from "react";
import { artForest, artMoth, artStillLife } from "@/assets/images";

export const PLACEHOLDER_TEXT = "this is a placeholder text that will be changed later.";

export type GallerySection = "art" | "offers";

export type GalleryFolder = {
  id: string;
  name: string;
  pinned: boolean;
  createdAt: number;
};

export type GalleryItem = {
  id: string;
  name: string;
  description: string;
  kind: "image" | "video";
  /** Bundled seed artwork. Owner uploads use mediaKey instead. */
  src?: string;
  mediaKey?: string;
  folderId: string | null;
  pinned: boolean;
  addedAt: number;
};

export type GallerySectionState = {
  folders: GalleryFolder[];
  items: GalleryItem[];
};

type GalleryStore = Record<GallerySection, GallerySectionState>;

const STORAGE_KEY = "kraviska.galleries.v4";
const LEGACY_KEYS = ["kraviska.galleries.v3", "kraviska.galleries.v1"];
const EVENT = "kraviska:gallery-changed";

function seededArt(): GallerySectionState {
  return {
    folders: [
      { id: "folder-creatures", name: "Creatures & omens", pinned: true, createdAt: 1 },
      { id: "folder-studies", name: "Quiet studies", pinned: false, createdAt: 2 },
    ],
    items: [
      {
        id: "seed-moonmoth",
        name: "Moonmoth",
        description: PLACEHOLDER_TEXT,
        kind: "image",
        src: artMoth,
        folderId: "folder-creatures",
        pinned: true,
        addedAt: 1,
      },
      {
        id: "seed-last-candle",
        name: "The Last Candle",
        description: PLACEHOLDER_TEXT,
        kind: "image",
        src: artStillLife,
        folderId: "folder-studies",
        pinned: false,
        addedAt: 2,
      },
      {
        id: "seed-vesper-trail",
        name: "Vesper Trail",
        description: PLACEHOLDER_TEXT,
        kind: "image",
        src: artForest,
        folderId: "folder-creatures",
        pinned: false,
        addedAt: 3,
      },
    ],
  };
}

function seededOffers(): GallerySectionState {
  return {
    folders: [
      { id: "offer-seasonal", name: "Seasonal offers", pinned: true, createdAt: 3 },
    ],
    items: [
      {
        id: "seed-rain-study",
        name: "Rain Study",
        description: PLACEHOLDER_TEXT,
        kind: "image",
        src: artForest,
        folderId: "offer-seasonal",
        pinned: true,
        addedAt: 4,
      },
      {
        id: "seed-keepers-key",
        name: "The Keeper's Key",
        description: PLACEHOLDER_TEXT,
        kind: "image",
        src: artStillLife,
        folderId: "offer-seasonal",
        pinned: false,
        addedAt: 5,
      },
    ],
  };
}

function emptyStore(): GalleryStore {
  return { art: seededArt(), offers: seededOffers() };
}

/** Used by the version ledger so the original version can restore the seeded archive. */
export function defaultGalleryStoreJson(): string {
  return JSON.stringify(emptyStore());
}

function normaliseItems(items: unknown, fallback: GalleryItem[]): GalleryItem[] {
  if (!Array.isArray(items)) return fallback;
  return items
    .filter((item): item is GalleryItem => Boolean(item) && typeof item === "object")
    .map((item) => ({
      ...item,
      kind: item.kind === "video" ? "video" : "image",
      description: item.description || PLACEHOLDER_TEXT,
      folderId: item.folderId ?? null,
      pinned: Boolean(item.pinned),
    }));
}

function normaliseSection(value: unknown, fallback: GallerySectionState): GallerySectionState {
  if (Array.isArray(value)) {
    return { folders: fallback.folders, items: normaliseItems(value, fallback.items) };
  }
  if (!value || typeof value !== "object") return fallback;
  const record = value as Partial<GallerySectionState>;
  return {
    folders: Array.isArray(record.folders) ? record.folders : fallback.folders,
    items: normaliseItems(record.items, fallback.items),
  };
}

function readStore(): GalleryStore {
  const fallback = emptyStore();
  if (typeof window === "undefined") return fallback;
  try {
    for (const key of [STORAGE_KEY, ...LEGACY_KEYS]) {
      const raw = window.localStorage.getItem(key);
      if (!raw) continue;
      const parsed = JSON.parse(raw) as Partial<Record<GallerySection, unknown>>;
      return {
        art: normaliseSection(parsed.art, fallback.art),
        offers: normaliseSection(parsed.offers, fallback.offers),
      };
    }
  } catch {
    /* corrupt storage falls back to the seeded archive */
  }
  return fallback;
}

function writeStore(store: GalleryStore) {
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(store));
  window.dispatchEvent(new Event(EVENT));
}

export type SaveResult = { ok: true } | { ok: false; message: string };

const SAVE_ERROR =
  "That change could not be saved in this browser's storage. Try removing an older piece first.";

export function useGallery(section: GallerySection) {
  const [state, setState] = useState<GallerySectionState>(() => readStore()[section]);

  useEffect(() => {
    const refresh = () => setState(readStore()[section]);
    refresh();
    window.addEventListener(EVENT, refresh);
    window.addEventListener("storage", refresh);
    return () => {
      window.removeEventListener(EVENT, refresh);
      window.removeEventListener("storage", refresh);
    };
  }, [section]);

  const commit = useCallback(
    (mutator: (current: GallerySectionState) => GallerySectionState): SaveResult => {
      const store = readStore();
      try {
        const next = mutator(store[section]);
        writeStore({ ...store, [section]: next });
        setState(next);
        return { ok: true };
      } catch {
        return { ok: false, message: SAVE_ERROR };
      }
    },
    [section],
  );

  const addItem = useCallback(
    (item: Omit<GalleryItem, "id" | "addedAt">): SaveResult =>
      commit((current) => ({
        ...current,
        items: [
          ...current.items,
          {
            ...item,
            id: `piece-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
            addedAt: Date.now(),
          },
        ],
      })),
    [commit],
  );

  const updateItem = useCallback(
    (
      itemId: string,
      patch: Partial<Pick<GalleryItem, "name" | "description" | "folderId" | "pinned">>,
    ): SaveResult =>
      commit((current) => ({
        ...current,
        items: current.items.map((item) =>
          item.id === itemId ? { ...item, ...patch } : item,
        ),
      })),
    [commit],
  );

  const removeItem = useCallback(
    (itemId: string): SaveResult =>
      commit((current) => ({
        ...current,
        items: current.items.filter((item) => item.id !== itemId),
      })),
    [commit],
  );

  const addFolder = useCallback(
    (name: string, pinned: boolean): SaveResult =>
      commit((current) => ({
        ...current,
        folders: [
          ...current.folders,
          {
            id: `folder-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
            name,
            pinned,
            createdAt: Date.now(),
          },
        ],
      })),
    [commit],
  );

  const updateFolder = useCallback(
    (folderId: string, patch: Partial<Pick<GalleryFolder, "name" | "pinned">>): SaveResult =>
      commit((current) => ({
        ...current,
        folders: current.folders.map((folder) =>
          folder.id === folderId ? { ...folder, ...patch } : folder,
        ),
      })),
    [commit],
  );

  const removeFolder = useCallback(
    (folderId: string): SaveResult =>
      commit((current) => ({
        folders: current.folders.filter((folder) => folder.id !== folderId),
        items: current.items.map((item) =>
          item.folderId === folderId ? { ...item, folderId: null } : item,
        ),
      })),
    [commit],
  );

  const toggleItemPin = useCallback(
    (itemId: string): SaveResult =>
      commit((current) => ({
        ...current,
        items: current.items.map((item) =>
          item.id === itemId ? { ...item, pinned: !item.pinned } : item,
        ),
      })),
    [commit],
  );

  const toggleFolderPin = useCallback(
    (folderId: string): SaveResult =>
      commit((current) => ({
        ...current,
        folders: current.folders.map((folder) =>
          folder.id === folderId ? { ...folder, pinned: !folder.pinned } : folder,
        ),
      })),
    [commit],
  );

  return {
    folders: state.folders,
    items: state.items,
    addItem,
    updateItem,
    removeItem,
    addFolder,
    updateFolder,
    removeFolder,
    toggleItemPin,
    toggleFolderPin,
  };
}

export function formatMediaType(kind: "image" | "video") {
  return kind === "video" ? "Video" : "Image";
}
