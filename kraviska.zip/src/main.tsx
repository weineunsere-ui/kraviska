import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>
);

/*
 * Static hosts often return 404 when a clean URL such as /about-me is
 * reloaded. The service worker serves the newest index.html for those
 * navigations, so returning to any page always opens the latest saved site.
 */
if ("serviceWorker" in navigator && window.location.protocol.startsWith("http")) {
  window.addEventListener("load", () => {
    const swUrl = new URL("sw.js", document.baseURI).href;
    navigator.serviceWorker.register(swUrl, { scope: "./" }).catch(() => {
      /* Hosting may not allow service workers; clean-URL fallbacks still work via the router. */
    });
  });
}
