import { useEffect, useId, useRef } from "react";
import type { ReactNode } from "react";
import { createPortal } from "react-dom";
import { playClose, playOpen } from "@/lib/audio";
import { NavLink } from "@/lib/router";
import {
  updateSiteContent,
  useSiteContent,
  type PageKey,
} from "@/lib/siteContent";
import { ArrowLeft, Asterisk, Sparkle, X } from "@/components/Icons";
import { EditableText } from "@/components/Editable";
import { EditLabel } from "@/components/EditLabel";

/* ------------------------------------------------------------------ */
/* Dialog                                                              */
/* ------------------------------------------------------------------ */

type ModalProps = {
  open: boolean;
  onClose: () => void;
  children: ReactNode;
  labelledBy?: string;
  className?: string;
  dismissible?: boolean;
  showClose?: boolean;
};

export function Modal({
  open,
  onClose,
  children,
  labelledBy,
  className = "",
  dismissible = true,
  showClose = true,
}: ModalProps) {
  const cardRef = useRef<HTMLDivElement>(null);
  const fallbackId = useId();
  const titleId = labelledBy ?? fallbackId;
  const closeRef = useRef(onClose);
  const dismiss = () => {
    playClose();
    closeRef.current();
  };
  closeRef.current = onClose;

  useEffect(() => {
    if (!open) return;
    playOpen();
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const timer = window.setTimeout(() => {
      const card = cardRef.current;
      const focusable =
        card?.querySelector<HTMLElement>(
          "[data-autofocus], input:not([type='hidden']), textarea, select",
        ) ??
        card?.querySelector<HTMLElement>(
          "button:not([disabled]), a[href], [tabindex]:not([tabindex='-1'])",
        );
      focusable?.focus();
    }, 60);

    const handleKey = (event: KeyboardEvent) => {
      if (event.key === "Escape" && dismissible) {
        event.preventDefault();
        playClose();
        closeRef.current();
      }
      if (event.key === "Tab" && cardRef.current) {
        const focusable = Array.from(
          cardRef.current.querySelectorAll<HTMLElement>(
            "input:not([disabled]), textarea:not([disabled]), select:not([disabled]), button:not([disabled]), a[href], [tabindex]:not([tabindex='-1'])",
          ),
        ).filter((element) => element.offsetParent !== null);
        if (focusable.length === 0) return;
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      }
    };
    window.addEventListener("keydown", handleKey);
    return () => {
      window.clearTimeout(timer);
      window.removeEventListener("keydown", handleKey);
      document.body.style.overflow = previousOverflow;
    };
  }, [open, dismissible]);

  if (!open) return null;

  return createPortal(
    <div className="modal-root">
      <div
        className="modal-scrim"
        onClick={(event) => {
          if (event.target === event.currentTarget && dismissible) dismiss();
        }}
      />
      <div
        ref={cardRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={labelledBy ? titleId : undefined}
        className={`modal-card ${className}`}
      >
        {showClose && (
          <button
            type="button"
            className="modal-x"
            onClick={dismiss}
            aria-label="Close dialog"
          >
            <X className="h-4 w-4" />
          </button>
        )}
        {children}
      </div>
    </div>,
    document.body,
  );
}

/* ------------------------------------------------------------------ */
/* Page building blocks                                                */
/* ------------------------------------------------------------------ */

export function PageIntro({
  index,
  pageKey,
  owner,
}: {
  index: string;
  pageKey: PageKey;
  owner: boolean;
}) {
  const site = useSiteContent();
  const page = site.pages[pageKey];
  const save = (patch: Partial<typeof page>) =>
    updateSiteContent((draft) => {
      draft.pages[pageKey] = { ...draft.pages[pageKey], ...patch };
    });

  return (
    <header className="page-heading">
      <div className="page-topline">
        <NavLink to="/" className="back-link">
          <ArrowLeft className="h-3.5 w-3.5" />
          <EditLabel k="backToIndex" owner={owner} />
        </NavLink>
        <span className="mono-label flex items-center gap-2">
          <span className="inline-block h-1.5 w-1.5 rounded-full bg-[var(--aqua)]" />
          <EditLabel k="sectionPrefix" owner={owner} />
          <span>{index}</span>
        </span>
      </div>

      <div className="page-title-row">
        <EditableText
          owner={owner}
          as="h1"
          className="page-title"
          value={page.title}
          onChange={(value) => save({ title: value })}
          label="Edit page title"
          maxLength={90}
        />
        <Sparkle className="page-title-spark" />
      </div>

      <div className="page-intro-row">
        <EditableText
          owner={owner}
          as="p"
          multiline
          className="page-lead"
          value={page.lead}
          onChange={(value) => save({ lead: value })}
          label="Edit page introduction"
          maxLength={500}
        />
        <div className="page-meta">
          <EditableText
            owner={owner}
            as="span"
            value={page.meta}
            onChange={(value) => save({ meta: value })}
            label="Edit page meta label"
            maxLength={60}
          />
          <span className="text-[var(--aqua)]">✦</span>
          <EditLabel k="established" owner={owner} as="span" />
        </div>
      </div>
    </header>
  );
}

export function SectionLabel({
  children,
  meta,
}: {
  children: ReactNode;
  meta?: ReactNode;
}) {
  return (
    <div className="section-label">
      <span className="flex items-center gap-2.5">
        <Asterisk className="h-3.5 w-3.5 text-[var(--aqua)]" />
        {children}
      </span>
      {meta && <span className="section-meta">{meta}</span>}
    </div>
  );
}

export function EndNote({
  pageKey,
  owner,
}: {
  pageKey?: PageKey;
  owner: boolean;
}) {
  const site = useSiteContent();
  const value = pageKey ? site.pages[pageKey].end : site.home.end;
  const save = (next: string) =>
    updateSiteContent((draft) => {
      if (pageKey) draft.pages[pageKey].end = next;
      else draft.home.end = next;
    });

  return (
    <div className="endnote">
      <div className="endnote-mark" aria-hidden="true">
        <span />
        <Asterisk className="h-4 w-4" />
        <span />
      </div>
      <EditableText
        owner={owner}
        as="p"
        multiline
        className="placeholder-copy"
        value={value}
        onChange={save}
        label="Edit closing note"
        maxLength={400}
      />
      <span className="mono-label mt-3 block text-[9px] tracking-[0.28em]">
        <EditLabel k="endOfPage" owner={owner} />
      </span>
    </div>
  );
}

export function ContentShell({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return <div className={`content-shell ${className}`}>{children}</div>;
}

/* ------------------------------------------------------------------ */
/* Small bits                                                          */
/* ------------------------------------------------------------------ */

export function SoundBars({ active }: { active: boolean }) {
  return (
    <span className={`sound-bars ${active ? "is-active" : ""}`} aria-hidden="true">
      <i />
      <i />
      <i />
      <i />
    </span>
  );
}

export function Pill({
  children,
  tone = "neutral",
}: {
  children: ReactNode;
  tone?: "neutral" | "lime";
}) {
  return <span className={`mini-pill ${tone === "lime" ? "mini-pill-lime" : ""}`}>{children}</span>;
}
