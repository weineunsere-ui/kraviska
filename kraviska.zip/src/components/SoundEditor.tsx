import { useCallback, useEffect, useRef, useState } from "react";
import { previewSamples, previewSoundDef } from "@/lib/audio";
import {
  SOUND_DEFS,
  SOUND_EVENTS,
  SOUND_PRESETS,
  clearCustomSound,
  eraseSilence,
  getSelectedPreset,
  getSoundForEditing,
  getSoundSettings,
  normalizeSamples,
  peaks,
  renderEdited,
  saveCustomSound,
  setSelectedPreset,
  type SoundEvent,
  type SoundPreset,
} from "@/lib/sound";
import { touchSiteUpdatedAt } from "@/lib/siteContent";
import { playSaved } from "@/lib/audio";
import {
  Check,
  Pin,
  Rewind,
  RotateCcw,
  Save,
  Scissors,
  SoundOn,
  Sparkle,
  Trash,
  Waves,
} from "@/components/Icons";

type LoadedSound = {
  samples: Float32Array;
  sampleRate: number;
  custom: boolean;
};

function drawWaveform(
  canvas: HTMLCanvasElement | null,
  samples: Float32Array | null,
  selection: { start: number; end: number },
) {
  if (!canvas) return;
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const width = Math.max(260, canvas.clientWidth);
  const height = Math.max(150, canvas.clientHeight);
  canvas.width = width * dpr;
  canvas.height = height * dpr;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, width, height);

  const gradient = ctx.createLinearGradient(0, 0, 0, height);
  gradient.addColorStop(0, "rgba(89, 227, 199, 0.16)");
  gradient.addColorStop(1, "rgba(89, 227, 199, 0.025)");
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, width, height);

  ctx.strokeStyle = "rgba(224, 242, 238, 0.1)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(0, height / 2);
  ctx.lineTo(width, height / 2);
  ctx.stroke();

  const x1 = selection.start * width;
  const x2 = selection.end * width;
  ctx.fillStyle = "rgba(89, 227, 199, 0.1)";
  ctx.fillRect(x1, 0, Math.max(1, x2 - x1), height);
  ctx.strokeStyle = "rgba(89, 227, 199, 0.75)";
  ctx.setLineDash([3, 3]);
  ctx.beginPath();
  ctx.moveTo(x1, 0);
  ctx.lineTo(x1, height);
  ctx.moveTo(x2, 0);
  ctx.lineTo(x2, height);
  ctx.stroke();
  ctx.setLineDash([]);

  if (!samples || samples.length === 0) {
    ctx.fillStyle = "rgba(224, 242, 238, 0.4)";
    ctx.font = "10px IBM Plex Mono, monospace";
    ctx.textAlign = "center";
    ctx.fillText("NO SOUND", width / 2, height / 2 - 8);
    return;
  }

  const buckets = Math.max(40, Math.floor(width / 3));
  const levels = peaks(samples, buckets);
  const mid = height / 2;
  const barWidth = width / buckets;
  ctx.fillStyle = "rgba(191, 254, 241, 0.82)";
  levels.forEach((level, index) => {
    const amplitude = Math.max(1.5, level * (height * 0.88));
    ctx.fillRect(index * barWidth, mid - amplitude / 2, Math.max(1, barWidth - 1.4), amplitude);
  });
}

const DEFAULTS = {
  gain: 1,
  noise: 0,
  fadeIn: 0.2,
  fadeOut: 0.5,
  speed: 1,
  reverse: false,
  reverb: 0,
  echo: 0,
  warmth: 0,
};

export function SoundEditor() {
  const [event, setEvent] = useState<SoundEvent>("enter");
  const [original, setOriginal] = useState<LoadedSound | null>(null);
  const [samples, setSamples] = useState<Float32Array | null>(null);
  const [selection, setSelection] = useState({ start: 0, end: 1 });
  const [effects, setEffects] = useState(DEFAULTS);
  const [status, setStatus] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [settings, setSettings] = useState(getSoundSettings());
  const [selectedPresetId, setSelectedPresetId] = useState(() => getSelectedPreset("enter"));
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const load = useCallback(async (target: SoundEvent, builtIn = false) => {
    setBusy(true);
    setError("");
    setStatus("");
    try {
      const result = await getSoundForEditing(target, { builtIn });
      setOriginal(result);
      setSamples(result.samples);
      setSelection({ start: 0, end: 1 });
      setSettings(getSoundSettings());
      setSelectedPresetId(getSelectedPreset(target));
      setStatus(
        result.custom
          ? "Editing your saved custom take."
          : "Editing the selected built-in choice.",
      );
    } catch {
      setError("That sound could not be prepared in this browser.");
    } finally {
      setBusy(false);
    }
  }, []);

  useEffect(() => {
    void load(event);
  }, [event, load]);

  useEffect(() => {
    drawWaveform(canvasRef.current, samples, selection);
  }, [samples, selection]);

  useEffect(() => {
    const onResize = () => drawWaveform(canvasRef.current, samples, selection);
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, [samples, selection]);

  const duration = original ? (samples?.length ?? 0) / original.sampleRate : 0;
  const customMeta = settings[event];
  const presets = SOUND_PRESETS[event];
  const selectedPreset =
    presets.find((preset) => preset.id === selectedPresetId) ?? presets[0];

  function editedSamples() {
    if (!samples || !original) return null;
    return renderEdited(samples, original.sampleRate, effects);
  }

  function preview() {
    const prepared = editedSamples();
    if (!prepared || !original || prepared.length === 0) return;
    previewSamples(prepared, original.sampleRate, 1);
    setStatus("Previewing your edit.");
  }

  async function choosePreset(preset: SoundPreset) {
    setSelectedPreset(event, preset.id);
    setSelectedPresetId(preset.id);
    await load(event, true);
    if (settings[event]) {
      setStatus(
        `“${preset.name}” selected. Your saved custom take still overrides it; remove the custom take below to hear this choice on the site.`,
      );
    } else {
      setStatus(`“${preset.name}” is now the built-in choice for ${SOUND_DEFS[event].label.toLowerCase()}.`);
    }
  }

  function updateEffect<K extends keyof typeof DEFAULTS>(key: K, value: (typeof DEFAULTS)[K]) {
    setEffects((current) => ({ ...current, [key]: value }));
  }

  function useSelection() {
    if (!samples || !original) return;
    const from = Math.max(0, Math.floor(selection.start * samples.length));
    const to = Math.max(from + 1, Math.floor(selection.end * samples.length));
    setSamples(samples.slice(from, to));
    setSelection({ start: 0, end: 1 });
    setStatus("Only the selected portion is kept.");
  }

  function removeSilence() {
    if (!samples || !original) return;
    setSamples(eraseSilence(samples, original.sampleRate));
    setSelection({ start: 0, end: 1 });
    setStatus("Quiet gaps were trimmed out.");
  }

  function normalize() {
    if (!samples) return;
    setSamples(normalizeSamples(samples));
    setStatus("The sound is normalised to a safe peak.");
  }

  function resetTake() {
    if (!original) return;
    setSamples(original.samples);
    setSelection({ start: 0, end: 1 });
    setEffects(DEFAULTS);
    setStatus("Back to the version that loaded with this action.");
  }

  async function save() {
    if (!samples || !original) return;
    const prepared = editedSamples();
    if (!prepared || prepared.length < 800) {
      setError("This sound is too short to save. Keep at least a fraction of a second.");
      return;
    }
    setBusy(true);
    const result = await saveCustomSound(event, prepared, original.sampleRate);
    setBusy(false);
    if (!result.ok) {
      setError(result.error ?? "That sound could not be saved.");
      return;
    }
    touchSiteUpdatedAt("Sound saved");
    setOriginal({ samples: prepared, sampleRate: original.sampleRate, custom: true });
    setSamples(prepared);
    setSettings(getSoundSettings());
    playSaved();
    setStatus("Saved. Visitors will hear this custom take for the selected event.");
  }

  async function removeCustom() {
    await clearCustomSound(event);
    await load(event, true);
    touchSiteUpdatedAt("Custom sound removed");
    setSettings(getSoundSettings());
    setStatus(`The saved custom take was removed. “${selectedPreset.name}” is now active.`);
  }

  const sliders: Array<{
    key: keyof typeof DEFAULTS;
    label: string;
    min: number;
    max: number;
    step: number;
    format: (value: number) => string;
  }> = [
    { key: "gain", label: "Gain", min: 0.1, max: 2, step: 0.01, format: (v) => `${v.toFixed(2)}×` },
    { key: "speed", label: "Speed / pitch", min: 0.45, max: 1.8, step: 0.01, format: (v) => `${v.toFixed(2)}×` },
    { key: "noise", label: "Room noise", min: 0, max: 0.16, step: 0.005, format: (v) => v.toFixed(3) },
    { key: "reverb", label: "Reverb", min: 0, max: 1, step: 0.01, format: (v) => `${Math.round(v * 100)}%` },
    { key: "echo", label: "Echo", min: 0, max: 1, step: 0.01, format: (v) => `${Math.round(v * 100)}%` },
    { key: "warmth", label: "Warmth / muffling", min: 0, max: 1, step: 0.01, format: (v) => `${Math.round(v * 100)}%` },
    { key: "fadeIn", label: "Fade in", min: 0, max: 3, step: 0.05, format: (v) => `${v.toFixed(2)}s` },
    { key: "fadeOut", label: "Fade out", min: 0, max: 4, step: 0.05, format: (v) => `${v.toFixed(2)}s` },
  ];

  return (
    <div className="sound-editor">
      <div className="sound-event-grid" role="tablist" aria-label="Sound events">
        {SOUND_EVENTS.map((entry) => (
          <button
            key={entry}
            type="button"
            role="tab"
            aria-selected={event === entry}
            className={`sound-event ${event === entry ? "is-active" : ""}`}
            onClick={() => setEvent(entry)}
          >
            <span>{SOUND_DEFS[entry].label}</span>
            {settings[entry] ? <em>custom</em> : <em>10 choices</em>}
          </button>
        ))}
      </div>

      <div className="sound-presets-block">
        <div className="sound-presets-head">
          <div>
            <span className="mono-label">Built-in choices · 10 for this action</span>
            <h3>{SOUND_DEFS[event].label}</h3>
            <p>Choose a character, audition it, then tweak it below if you want to make it your own.</p>
          </div>
          <span className="mini-pill mini-pill-aqua">
            <Pin className="h-3 w-3" /> {selectedPreset.name}
          </span>
        </div>
        <div className="sound-preset-grid" role="radiogroup" aria-label={`Built-in sounds for ${SOUND_DEFS[event].label}`}>
          {presets.map((preset, index) => (
            <div
              key={preset.id}
              className={`sound-preset-card ${preset.id === selectedPresetId ? "is-active" : ""}`}
            >
              <button
                type="button"
                role="radio"
                aria-checked={preset.id === selectedPresetId}
                className="sound-preset-select"
                onClick={() => void choosePreset(preset)}
              >
                <span className="sound-preset-index">{String(index + 1).padStart(2, "0")}</span>
                <span className="sound-preset-copy">
                  <strong>{preset.name}</strong>
                  <small>{preset.description}</small>
                </span>
              </button>
              <button
                type="button"
                className="sound-preset-preview"
                onClick={() => previewSoundDef(preset.def)}
                aria-label={`Preview ${preset.name}`}
                title="Preview this choice"
              >
                <SoundOn className="h-3.5 w-3.5" />
              </button>
            </div>
          ))}
        </div>
        {customMeta && (
          <p className="sound-custom-note">
            <Trash className="h-3.5 w-3.5" />
            A custom take is saved for this action and currently overrides the built-in choice.
            Remove it with “Remove custom take” at the bottom to let your choice play.
          </p>
        )}
      </div>

      <div className="sound-window">
        <div className="sound-window-head">
          <div>
            <span className="mono-label">Sound window</span>
            <h3>{selectedPreset.name}</h3>
            <p>{selectedPreset.description}</p>
          </div>
          <div className="sound-meta">
            <span>{duration.toFixed(2)}s</span>
            <span>{original?.sampleRate ?? 22050} Hz</span>
            <span className={customMeta ? "is-custom" : ""}>
              {customMeta ? "Custom take active" : `Built-in · ${selectedPreset.name}`}
            </span>
          </div>
        </div>

        <div className="sound-wave-wrap">
          <canvas
            ref={canvasRef}
            className="sound-wave"
            aria-label={`Waveform for ${SOUND_DEFS[event].label}`}
          />
          <div className="sound-time-row" aria-hidden="true">
            <span>0.00s</span>
            <span>{(duration / 2).toFixed(2)}s</span>
            <span>{duration.toFixed(2)}s</span>
          </div>
        </div>

        <div className="sound-selection">
          <label className="slider-row">
            <span className="slider-label">
              Selection start
              <em>{(selection.start * duration).toFixed(2)}s</em>
            </span>
            <input
              type="range"
              min={0}
              max={1000}
              value={Math.round(selection.start * 1000)}
              onChange={(event_) => {
                const start = Math.min(Number(event_.target.value) / 1000, selection.end - 0.005);
                setSelection((current) => ({ ...current, start: Math.max(0, start) }));
              }}
            />
          </label>
          <label className="slider-row">
            <span className="slider-label">
              Selection end
              <em>{(selection.end * duration).toFixed(2)}s</em>
            </span>
            <input
              type="range"
              min={0}
              max={1000}
              value={Math.round(selection.end * 1000)}
              onChange={(event_) => {
                const end = Math.max(Number(event_.target.value) / 1000, selection.start + 0.005);
                setSelection((current) => ({ ...current, end: Math.min(1, end) }));
              }}
            />
          </label>
        </div>

        <div className="sound-tools">
          <button type="button" className="btn btn-aqua btn-compact" onClick={preview} disabled={busy}>
            <SoundOn className="h-3.5 w-3.5" />
            Preview edit
          </button>
          <button type="button" className="btn btn-ghost btn-compact" onClick={useSelection} disabled={busy}>
            <Scissors className="h-3.5 w-3.5" />
            Use selection
          </button>
          <button type="button" className="btn btn-ghost btn-compact" onClick={removeSilence} disabled={busy}>
            <Waves className="h-3.5 w-3.5" />
            Erase silences
          </button>
          <button type="button" className="btn btn-ghost btn-compact" onClick={normalize} disabled={busy}>
            <Sparkle className="h-3.5 w-3.5" />
            Normalise
          </button>
          <button
            type="button"
            className={`btn btn-compact ${effects.reverse ? "btn-aqua" : "btn-ghost"}`}
            onClick={() => updateEffect("reverse", !effects.reverse)}
            aria-pressed={effects.reverse}
          >
            <Rewind className="h-3.5 w-3.5" />
            Reverse
          </button>
          <button
            type="button"
            className="btn btn-ghost btn-compact"
            onClick={() => updateEffect("speed", 0.62)}
            title="Slows the sound and lowers its pitch"
          >
            Slow motion
          </button>
          <button type="button" className="btn btn-ghost btn-compact" onClick={resetTake} disabled={busy || !original}>
            <RotateCcw className="h-3.5 w-3.5" />
            Reset take
          </button>
        </div>

        <div className="sound-sliders">
          {sliders.map((slider) => (
            <label className="slider-row" key={slider.key}>
              <span className="slider-label">
                {slider.label}
                <em>{slider.format(effects[slider.key] as number)}</em>
              </span>
              <input
                type="range"
                min={slider.min}
                max={slider.max}
                step={slider.step}
                value={effects[slider.key] as number}
                onChange={(input) =>
                  updateEffect(slider.key, Number(input.target.value) as never)
                }
              />
            </label>
          ))}
        </div>

        {status && (
          <p className="sound-status" role="status">
            <Check className="h-3.5 w-3.5" />
            {status}
          </p>
        )}
        {error && (
          <p className="field-error" role="alert">
            {error}
          </p>
        )}

        <div className="sound-actions">
          <button
            type="button"
            className="btn btn-ghost btn-compact"
            onClick={() => void removeCustom()}
            disabled={busy || !customMeta}
          >
            <Trash className="h-3.5 w-3.5" />
            Remove custom take
          </button>
          <span className="sound-save">
            <em>
              <Pin className="h-3 w-3" />
              Applies to “{SOUND_DEFS[event].label}”
            </em>
            <button type="button" className="btn btn-aqua" onClick={() => void save()} disabled={busy || !samples}>
              <Save className="h-3.5 w-3.5" />
              {busy ? "Saving…" : "Save custom sound"}
            </button>
          </span>
        </div>
      </div>
    </div>
  );
}
