import { DOCUMENT_META, documentHasContent, useDocumentMediaUrl, useDocumentSlot, type DocumentSlot } from "@/lib/documents";
import { formatEditedDateTime } from "@/lib/siteContent";
import { Modal } from "@/components/ui";
import { Download, FileText, ImageIcon, X } from "@/components/Icons";
import { useLabel } from "@/lib/siteContent";

function ImagePage({
  mediaKey,
  name,
  index,
  total,
  openLabel,
  downloadLabel,
}: {
  mediaKey: string;
  name: string;
  index: number;
  total: number;
  openLabel: string;
  downloadLabel: string;
}) {
  const url = useDocumentMediaUrl(mediaKey);
  return (
    <figure className="document-page">
      <div className="document-page-head">
        <span className="mono-label">
          Page {String(index + 1).padStart(2, "0")} / {String(total).padStart(2, "0")}
        </span>
        <span className="document-page-name">{name}</span>
        {url && (
          <span className="document-page-actions">
            <a className="text-link" href={url} target="_blank" rel="noreferrer noopener">
              {openLabel}
            </a>
            <a className="text-link" href={url} download={name}>
              <Download className="h-3 w-3" /> {downloadLabel}
            </a>
          </span>
        )}
      </div>
      <div className="document-page-frame">
        {url ? (
          <img src={url} alt={`${name} — page ${index + 1}`} loading="lazy" />
        ) : (
          <span className="mono-label">Loading page…</span>
        )}
      </div>
    </figure>
  );
}

export function DocumentViewer({
  slot,
  title,
  open,
  onClose,
}: {
  slot: DocumentSlot;
  title: string;
  open: boolean;
  onClose: () => void;
}) {
  const state = useDocumentSlot(slot);
  const pdfUrl = useDocumentMediaUrl(state.pdfKey);
  const meta = DOCUMENT_META[slot];
  const nowViewing = useLabel("nowViewing");
  const footer = useLabel("viewerFooter");
  const missing = useLabel("documentMissing");
  const openLabel = useLabel("pdfOpenTab");
  const downloadLabel = useLabel("documentDownload");
  const preparing = useLabel("pdfPreparing");
  const viewerHint = useLabel("documentViewerHint");
  const pagesCount = useLabel("documentPagesCount");
  const domain = useLabel("domain");
  const hasContent = documentHasContent(state);

  return (
    <Modal
      open={open}
      onClose={onClose}
      showClose={false}
      labelledBy="document-viewer-title"
      className="document-viewer-dialog"
    >
      <header className="pdf-toolbar">
        <div className="pdf-heading">
          <span className="pdf-icon">
            {state.type === "images" ? <ImageIcon className="h-4 w-4" /> : <FileText className="h-4 w-4" />}
          </span>
          <div>
            <span className="mono-label block text-[9px] tracking-[0.24em]">{nowViewing}</span>
            <h2 id="document-viewer-title" className="pdf-title">
              {title || meta.label}
            </h2>
          </div>
        </div>
        <div className="pdf-actions">
          {state.type === "pdf" && pdfUrl && (
            <>
              <a className="btn btn-ghost btn-compact" href={pdfUrl} target="_blank" rel="noreferrer noopener">
                {openLabel}
              </a>
              <a
                className="btn btn-ghost btn-compact"
                href={pdfUrl}
                download={state.pdfName || `${slot}.pdf`}
              >
                <Download className="h-3.5 w-3.5" />
                {downloadLabel}
              </a>
            </>
          )}
          <button type="button" className="modal-x is-static" onClick={onClose} aria-label="Close document viewer">
            <X className="h-4 w-4" />
          </button>
        </div>
      </header>

      {!hasContent ? (
        <div className="document-empty">
          <span className="document-empty-icon">
            <FileText className="h-6 w-6" />
          </span>
          <h3>{missing}</h3>
          <p>{meta.helper}</p>
        </div>
      ) : state.type === "pdf" ? (
        <div className="pdf-frame-wrap document-pdf-frame">
          {pdfUrl ? (
            <iframe src={pdfUrl} title={state.pdfName || title} />
          ) : (
            <div className="pdf-loading">{preparing}</div>
          )}
        </div>
      ) : (
        <div className="document-pages-wrap">
          <p className="document-pages-hint">
            <span className="mono-label">{state.images.length} {pagesCount}</span>
            {viewerHint}
          </p>
          <div className="document-pages">
            {state.images.map((image, index) => (
              <ImagePage
                key={image.key}
                mediaKey={image.key}
                name={image.name}
                index={index}
                total={state.images.length}
                openLabel={openLabel}
                downloadLabel={downloadLabel}
              />
            ))}
          </div>
        </div>
      )}

      <footer className="pdf-footer">
        <span>
          {footer}
          {state.updatedAt ? ` · ${formatEditedDateTime(state.updatedAt)}` : ""}
        </span>
        <span className="text-[var(--aqua)]">{state.pdfName || (state.images.length ? `${state.images.length} ${pagesCount}` : domain)}</span>
      </footer>
    </Modal>
  );
}
