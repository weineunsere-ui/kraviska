import { useCallback, useEffect, useRef, useState } from "react";
import { backdropImage } from "@/assets/images";
import {
  isSoundMuted,
  playClick,
  playEnterPage,
  playExitPage,
  playHover,
  primeAudio,
  setSoundMuted,
} from "@/lib/audio";
import {
  LEAVE_EVENT,
  NavLink,
  ROUTE_META,
  useRoute,
  type RouteKey,
} from "@/lib/router";
import { WarningGate } from "@/components/WarningGate";
import { OwnerAccess } from "@/components/OwnerAccess";
import { BackgroundStudio } from "@/components/BackgroundStudio";
import { CustomizeStudio, type StudioTab } from "@/components/CustomizeStudio";
import { useMediaUrl } from "@/lib/mediaStore";
import { useSiteContent, type PageKey } from "@/lib/siteContent";
import { EditLabel } from "@/components/EditLabel";
import { loadCustomSounds } from "@/lib/sound";
import { SoundBars } from "@/components/ui";
import { Asterisk, Lock, SoundOff, SoundOn, Unlock } from "@/components/Icons";
import { HomePage } from "@/pages/HomePage";
import {
  AboutMePage,
  AboutPage,
  ArtExamplePage,
  CommissionInformationPage,
  FaqsPage,
  LinksPage,
  MonthlyOffersPage,
  PaymentMethodsPage,
} from "@/pages/ContentPages";

function SiteBackdrop({ backgroundUrl }: { backgroundUrl?: string }) {
  const site = useSiteContent();
  const bg = site.background;
  const hasUpload = bg.kind === "media" && Boolean(backgroundUrl);
  const { brightness, saturation, contrast, blur } = bg.filters;
  const mediaFilter = `brightness(${brightness}) saturate(${saturation}) contrast(${contrast}) blur(${blur}px)`;
  const isVideo = hasUpload && bg.mediaType === "video";
  const objectFit =
    bg.fit === "stretch" ? "fill" : bg.fit === "contain" ? "contain" : "cover";
  const backgroundSize =
    bg.fit === "stretch"
      ? "100% 100%"
      : bg.fit === "contain"
        ? "contain"
        : bg.fit === "tile"
          ? "320px auto"
          : "cover";

  return (
    <div className="site-backdrop" aria-hidden="true">
      {hasUpload ? (
        isVideo ? (
          <video
            className="site-backdrop-video"
            src={backgroundUrl}
            autoPlay
            muted
            loop
            playsInline
            style={{ objectFit, filter: mediaFilter }}
          />
        ) : (
          <div
            className="site-backdrop-upload"
            style={{
              backgroundImage: `url(${backgroundUrl})`,
              backgroundSize,
              backgroundRepeat: bg.fit === "tile" ? "repeat" : "no-repeat",
              backgroundPosition: "center",
              filter: mediaFilter,
            }}
          />
        )
      ) : (
        <div
          className="site-backdrop-image"
          style={{
            backgroundImage: `url(${backdropImage})`,
            filter: `brightness(${brightness * 0.68}) saturate(${saturation * 0.3}) contrast(${contrast}) blur(${blur}px)`,
          }}
        />
      )}
      <div className="site-backdrop-shade" />
      <div className="site-backdrop-glow" />
      <div className="site-rain" />
    </div>
  );
}

const ROUTE_PAGE_KEY: Record<RouteKey, PageKey | null> = {
  "/": null,
  "/links": "links",
  "/art-example": "art",
  "/commission-information": "commission",
  "/monthly-offers-and-more": "offers",
  "/payment-methods": "payments",
  "/about-me": "aboutMe",
  "/faqs": "faqs",
  "/about-page": "aboutPage",
};

export default function App() {
  const route = useRoute();
  const [entered, setEntered] = useState(false);
  const [soundOn, setSoundOn] = useState(() => !isSoundMuted());
  // Deliberately in-memory only: closing or reloading the site locks the studio.
  const [owner, setOwner] = useState(false);
  const [ownerDialogOpen, setOwnerDialogOpen] = useState(false);
  const [backgroundOpen, setBackgroundOpen] = useState(false);
  const [customizeOpen, setCustomizeOpen] = useState(false);
  const [studioTab, setStudioTab] = useState<StudioTab>("warning");
  const site = useSiteContent();
  const backgroundUrl = useMediaUrl(site.background.mediaKey);
  const enteredRef = useRef(false);
  const previousRoute = useRef<RouteKey>(route);

  /* Load any owner-saved sounds for this visit. */
  useEffect(() => {
    void loadCustomSounds();
  }, []);

  /* A safety net for reloads, tab closes and restores from the back/forward cache. */
  useEffect(() => {
    const lock = () => {
      setOwner(false);
      setCustomizeOpen(false);
      setOwnerDialogOpen(false);
    };
    window.addEventListener("pagehide", lock);
    return () => window.removeEventListener("pagehide", lock);
  }, []);

  /* Titles + a slow entry motif on every page change. */
  useEffect(() => {
    document.title = ROUTE_META[route].title;
    if (previousRoute.current === route) return;
    previousRoute.current = route;
    if (!enteredRef.current) return;
    const timer = window.setTimeout(() => playEnterPage(), 700);
    return () => window.clearTimeout(timer);
  }, [route]);

  /* Leaving a page plays the entry motif in reverse. */
  useEffect(() => {
    const onLeave = () => {
      if (enteredRef.current) playExitPage();
    };
    window.addEventListener(LEAVE_EVENT, onLeave);
    window.addEventListener("popstate", onLeave);
    return () => {
      window.removeEventListener(LEAVE_EVENT, onLeave);
      window.removeEventListener("popstate", onLeave);
    };
  }, []);

  /* One delegated sound layer covers every button and link, including dialogs. */
  useEffect(() => {
    let lastHover: Element | null = null;
    let lastHoverAt = 0;

    const findInteractive = (target: EventTarget | null): Element | null => {
      if (!(target instanceof Element)) return null;
      return target.closest(
        'a[href], button:not([disabled]), [role="button"]:not([aria-disabled="true"])',
      );
    };

    const onPointerOver = (event: PointerEvent) => {
      if (event.pointerType && event.pointerType !== "mouse") return;
      const current = findInteractive(event.target);
      if (!current || current === lastHover) return;
      if (findInteractive(event.relatedTarget) === current) return;
      lastHover = current;
      const now = performance.now();
      if (now - lastHoverAt > 90) {
        lastHoverAt = now;
        playHover();
      }
    };

    const onPointerOut = (event: PointerEvent) => {
      const current = findInteractive(event.target);
      if (current && current === lastHover) lastHover = null;
    };

    const onClick = (event: MouseEvent) => {
      if (!findInteractive(event.target)) return;
      primeAudio();
      playClick();
    };

    window.addEventListener("pointerover", onPointerOver, { passive: true });
    window.addEventListener("pointerout", onPointerOut, { passive: true });
    window.addEventListener("click", onClick);
    return () => {
      window.removeEventListener("pointerover", onPointerOver);
      window.removeEventListener("pointerout", onPointerOut);
      window.removeEventListener("click", onClick);
    };
  }, []);

  const handleEnter = useCallback(() => {
    enteredRef.current = true;
    setEntered(true);
    document.body.style.overflow = "";
    playEnterPage();
  }, []);

  const updateOwner = useCallback((next: boolean) => {
    setOwner(next);
    if (!next) {
      setCustomizeOpen(false);
      setBackgroundOpen(false);
    }
  }, []);

  const openCustomize = useCallback((tab: StudioTab = "warning") => {
    setStudioTab(tab);
    setOwnerDialogOpen(false);
    setBackgroundOpen(false);
    setCustomizeOpen(true);
  }, []);

  const openBackgroundFromStudio = useCallback(() => {
    setCustomizeOpen(false);
    setOwnerDialogOpen(false);
    setBackgroundOpen(true);
  }, []);

  const lockStudio = useCallback(() => {
    setOwner(false);
    setCustomizeOpen(false);
    setBackgroundOpen(false);
    setOwnerDialogOpen(false);
  }, []);

  const toggleSound = useCallback(() => {
    setSoundOn((current) => {
      const next = !current;
      setSoundMuted(!next);
      return next;
    });
  }, []);

  const page = (() => {
    switch (route) {
      case "/links":
        return <LinksPage owner={owner} />;
      case "/art-example":
        return <ArtExamplePage owner={owner} />;
      case "/commission-information":
        return <CommissionInformationPage owner={owner} />;
      case "/monthly-offers-and-more":
        return <MonthlyOffersPage owner={owner} />;
      case "/payment-methods":
        return <PaymentMethodsPage owner={owner} />;
      case "/about-me":
        return <AboutMePage owner={owner} />;
      case "/faqs":
        return <FaqsPage owner={owner} />;
      case "/about-page":
        return <AboutPage owner={owner} />;
      default:
        return <HomePage owner={owner} />;
    }
  })();

  const meta = ROUTE_META[route];
  const pageKey = ROUTE_PAGE_KEY[route];
  const crumbLabel = pageKey ? site.pages[pageKey].title : site.labels.homeIndexLabel;

  return (
    <>
      <a className="skip-link" href="#main-content">
        Skip to content
      </a>

      <SiteBackdrop backgroundUrl={backgroundUrl} />
      <div
        className="site-noise"
        aria-hidden="true"
        style={{ opacity: site.background.filters.noise }}
      />

      {entered && (
        <div className="site-frame">
          <div className="site-panel">
            <header className="site-header">
              <NavLink to="/" className="brand" aria-label="Kraviska — return to index">
                <span className="brand-mark">
                  <Asterisk className="h-5 w-5" />
                </span>
                <EditLabel k="brand" owner={owner} className="brand-word" />
                <EditLabel k="brandDomain" owner={owner} className="brand-domain" />
              </NavLink>

              <div className="header-crumb" aria-hidden="true">
                <span className="mono-label">{meta.index}</span>
                <span className="header-crumb-line" />
                <span>{crumbLabel}</span>
              </div>

              <div className="header-tools">
                <span className="header-status">
                  <span className="status-dot" aria-hidden="true" />
                  <EditLabel k="status" owner={owner} />
                </span>

                <button
                  type="button"
                  className="utility-btn"
                  onClick={toggleSound}
                  aria-pressed={soundOn}
                  aria-label={soundOn ? "Mute interface sounds" : "Enable interface sounds"}
                  title={soundOn ? "Mute interface sounds" : "Enable interface sounds"}
                >
                  <SoundBars active={soundOn} />
                  {soundOn ? (
                    <SoundOn className="sound-fallback h-4 w-4" />
                  ) : (
                    <SoundOff className="sound-fallback h-4 w-4" />
                  )}
                  <span className="utility-label">
                    <EditLabel k={soundOn ? "soundOn" : "soundOff"} owner={owner} />
                  </span>
                </button>

                <button
                  type="button"
                  className={`utility-btn owner-btn ${owner ? "is-owner" : ""}`}
                  onClick={() => setOwnerDialogOpen(true)}
                  aria-pressed={owner}
                  aria-label={owner ? "Owner tools unlocked" : "Open owner access"}
                  title={owner ? "Owner tools unlocked" : "Owner access"}
                >
                  {owner ? (
                    <Unlock className="h-4 w-4" />
                  ) : (
                    <Lock className="h-4 w-4" />
                  )}
                  <span className="utility-label">
                    <EditLabel k={owner ? "studioLabel" : "ownerLabel"} owner={owner} />
                  </span>
                  {owner && <span className="owner-live-dot" aria-hidden="true" />}
                </button>
              </div>
            </header>

            {owner && (
              <div className="studio-bar">
                <span className="studio-bar-label">
                  <span className="studio-live-dot" aria-hidden="true" />
                  Studio mode
                </span>
                <span className="studio-bar-hint">Click highlighted text to edit · add or remove rows on each page</span>
                <div className="studio-bar-actions">
                  <button type="button" className="studio-bar-btn" onClick={() => openCustomize("warning")}>
                    Customize
                  </button>
                  <button type="button" className="studio-bar-btn" onClick={() => openCustomize("sound")}>
                    Sound
                  </button>
                  <button type="button" className="studio-bar-btn" onClick={() => openCustomize("versions")}>
                    Versions
                  </button>
                  <button type="button" className="studio-bar-btn" onClick={() => setOwnerDialogOpen(true)}>
                    Studio menu
                  </button>
                  <button type="button" className="studio-bar-btn studio-bar-lock" onClick={lockStudio}>
                    Lock
                  </button>
                </div>
              </div>
            )}

            <main id="main-content" className="page-enter" key={route}>
              {page}
            </main>

            <footer className="site-footer">
              <div className="footer-inner">
                <span className="footer-brand">
                  <Asterisk className="h-3 w-3" />
                  <EditLabel k="brand" owner={owner} />
                </span>
                <span className="footer-center">
                  <EditLabel k="footerTagline" owner={owner} />
                  <span className="footer-dot" aria-hidden="true" />
                  <EditLabel k="footerDomain" owner={owner} />
                </span>
                <span className="footer-index">
                  {meta.index} / {crumbLabel}
                </span>
              </div>
            </footer>
          </div>
        </div>
      )}

      <WarningGate onEnter={handleEnter} />

      {entered && (
        <>
          <OwnerAccess
            open={ownerDialogOpen}
            owner={owner}
            onClose={() => setOwnerDialogOpen(false)}
            onChange={updateOwner}
            onOpenBackground={openBackgroundFromStudio}
            onOpenCustomize={openCustomize}
          />
          <BackgroundStudio open={backgroundOpen} onClose={() => setBackgroundOpen(false)} />
          <CustomizeStudio
            open={customizeOpen}
            tab={studioTab}
            onTab={setStudioTab}
            onClose={() => setCustomizeOpen(false)}
            onOpenBackground={openBackgroundFromStudio}
            onLock={lockStudio}
          />
        </>
      )}
    </>
  );
}
