import { useState } from "react";
import type { ComponentType, ReactNode, SVGProps } from "react";
import { NavLink } from "@/lib/router";
import {
  newId,
  updateSiteContent,
  usePageContent,
  useSiteContent,
  type LinkIcon,
  type PageKey,
  type PageLink,
} from "@/lib/siteContent";
import { Modal } from "@/components/ui";
import { EditableText } from "@/components/Editable";
import { EditLabel } from "@/components/EditLabel";
import {
  ArrowUpRight,
  Asterisk,
  Discord,
  FileText,
  Gumroad,
  Instagram,
  Payoneer,
  Pencil,
  Plus,
  Sparkle,
  Steam,
  TikTok,
  Trash,
  VGen,
} from "@/components/Icons";

type Glyph = ComponentType<SVGProps<SVGSVGElement>>;

export const LINK_ICONS: Record<LinkIcon, Glyph> = {
  instagram: Instagram,
  tiktok: TikTok,
  vgen: VGen,
  discord: Discord,
  gumroad: Gumroad,
  payoneer: Payoneer,
  steam: Steam,
  file: FileText,
  sparkle: Sparkle,
  link: ArrowUpRight,
};

const ICON_OPTIONS: Array<{ value: LinkIcon; label: string }> = [
  { value: "link", label: "Link arrow" },
  { value: "instagram", label: "Instagram" },
  { value: "tiktok", label: "TikTok" },
  { value: "vgen", label: "VGen" },
  { value: "discord", label: "Discord" },
  { value: "gumroad", label: "Gumroad" },
  { value: "payoneer", label: "Payoneer" },
  { value: "steam", label: "Steam" },
  { value: "file", label: "Document" },
  { value: "sparkle", label: "Sparkle" },
];

type Draft = {
  id?: string;
  label: string;
  description: string;
  href: string;
  icon: LinkIcon;
};

const EMPTY_DRAFT: Draft = {
  label: "",
  description: "this is a placeholder text that will be changed later.",
  href: "",
  icon: "link",
};

function destinationLabel(href: string, site: ReturnType<typeof useSiteContent>) {
  if (href.startsWith("pdf:")) return site.labels.linkPdf;
  if (href.startsWith("/")) return site.labels.linkPage;
  return site.labels.linkExternal;
}

export function ContentLinks({
  pageKey,
  owner,
}: {
  pageKey: PageKey;
  owner: boolean;
}) {
  const page = usePageContent(pageKey);
  const site = useSiteContent();
  const [draft, setDraft] = useState<Draft | null>(null);
  const [error, setError] = useState("");

  const savePage = (patch: Partial<typeof page>) => {
    updateSiteContent((site) => {
      site.pages[pageKey] = { ...site.pages[pageKey], ...patch };
    });
  };

  const openAdd = () => {
    setError("");
    setDraft({ ...EMPTY_DRAFT, description: "this is a placeholder text that will be changed later." });
  };

  const openEdit = (link: PageLink) => {
    setError("");
    setDraft({ ...link });
  };

  const saveDraft = () => {
    if (!draft) return;
    if (!draft.label.trim()) {
      setError("A link title is required.");
      return;
    }
    if (!draft.href.trim()) {
      setError("A destination is required. Use /links for a site page or a full external URL.");
      return;
    }
    const clean: PageLink = {
      id: draft.id ?? newId("link"),
      label: draft.label.trim(),
      description: draft.description.trim(),
      href: draft.href.trim(),
      icon: draft.icon,
    };
    savePage({
      links: draft.id
        ? page.links.map((link) => (link.id === draft.id ? clean : link))
        : [...page.links, clean],
    });
    setDraft(null);
  };

  const removeLink = (id: string) => {
    savePage({ links: page.links.filter((link) => link.id !== id) });
    if (draft?.id === id) setDraft(null);
  };

  const renderRow = (link: PageLink) => {
    const Glyph = LINK_ICONS[link.icon] ?? ArrowUpRight;
    const isInternal = link.href.startsWith("/");
    const body = (
      <>
        <span className="social-index" aria-hidden="true">
          {String(page.links.indexOf(link) + 1).padStart(2, "0")}
        </span>
        <span className="social-glyph" aria-hidden="true">
          <Glyph className="h-6 w-6" />
        </span>
        <span className="social-body">
          <span className="social-name">{link.label}</span>
          <span className="social-desc">{link.description}</span>
        </span>
        <span className="social-end">
          <span className="social-handle" aria-hidden="true">
            {destinationLabel(link.href, site)}
          </span>
          <span className="social-arrow" aria-hidden="true">
            <ArrowUpRight className="h-4 w-4" />
          </span>
        </span>
      </>
    );

    let control: ReactNode;
    if (isInternal) {
      control = (
        <NavLink to={link.href as "/"} className="social-link doc-link">
          {body}
        </NavLink>
      );
    } else {
      control = (
        <a className="social-link doc-link" href={link.href} target="_blank" rel="noreferrer noopener">
          {body}
        </a>
      );
    }

    return (
      <div className="managed-row" key={link.id}>
        {control}
        {owner && (
          <div className="row-owner-actions" aria-label={`Manage ${link.label}`}>
            <button type="button" className="row-owner-btn" onClick={() => openEdit(link)} aria-label={`Edit ${link.label}`}>
              <Pencil className="h-3 w-3" />
            </button>
            <button
              type="button"
              className="row-owner-btn is-danger"
              onClick={() => removeLink(link.id)}
              aria-label={`Delete ${link.label}`}
            >
              <Trash className="h-3 w-3" />
            </button>
          </div>
        )}
      </div>
    );
  };

  return (
    <section className="page-section" aria-label={page.sectionLabel || "Links"}>
      <div className="section-label">
        <span className="flex items-center gap-2.5">
          <Asterisk className="h-3.5 w-3.5 text-[var(--aqua)]" />
          <EditableText
            owner={owner}
            as="span"
            value={page.sectionLabel}
            onChange={(value) => savePage({ sectionLabel: value })}
            label="Edit section label"
          />
        </span>
        <span className="section-meta">
          <EditableText
            owner={owner}
            as="span"
            value={page.sectionMeta}
            onChange={(value) => savePage({ sectionMeta: value })}
            label="Edit section note"
          />
        </span>
      </div>

      {page.links.length === 0 ? (
        <div className="gallery-empty">
          <div className="gallery-empty-mark">
            <Asterisk className="h-6 w-6" />
          </div>
          <h2>
            <EditLabel k="noLinks" owner={owner} />
          </h2>
          <p>
            <EditLabel k="emptyPlaceholder" owner={owner} />
          </p>
          {owner && (
            <button type="button" className="btn btn-aqua mt-6" onClick={openAdd}>
              <Plus className="h-4 w-4" />
              Add link
            </button>
          )}
        </div>
      ) : (
        <div className="link-stack">{page.links.map(renderRow)}</div>
      )}

      {owner && page.links.length > 0 && (
        <div className="content-add-row">
          <button type="button" className="btn btn-aqua btn-add" onClick={openAdd}>
            <Plus className="h-4 w-4" />
            Add link or button
          </button>
          <span className="content-add-hint">New rows inherit this page&apos;s style.</span>
        </div>
      )}

      <Modal
        open={Boolean(draft)}
        onClose={() => setDraft(null)}
        labelledBy="edit-link-title"
        className="upload-dialog"
      >
        <div className="modal-kicker">
          <Pencil className="h-3.5 w-3.5 text-[var(--aqua)]" />
          Studio / link editor
        </div>
        <h2 id="edit-link-title" className="modal-title">
          {draft?.id ? "Edit link" : "Add a new link"}
        </h2>
        <p className="modal-copy">
          This row mirrors the existing page style. Use a site route such as <code>/links</code>{" "}
          for an internal page, or a full address for an external link. Price sheets and TOC
          documents are uploaded directly on the Commission Information page.
        </p>

        <label className="field-label" htmlFor="link-label">
          Title
        </label>
        <input
          id="link-label"
          className="field-input"
          value={draft?.label ?? ""}
          onChange={(event) => draft && setDraft({ ...draft, label: event.target.value })}
          placeholder="e.g. Instagram"
          maxLength={90}
          data-autofocus
        />

        <label className="field-label mt-4" htmlFor="link-description">
          Description
        </label>
        <textarea
          id="link-description"
          className="field-input field-textarea"
          value={draft?.description ?? ""}
          onChange={(event) => draft && setDraft({ ...draft, description: event.target.value })}
          rows={3}
          maxLength={300}
        />

        <div className="field-split">
          <div>
            <label className="field-label" htmlFor="link-href">
              Destination
            </label>
            <input
              id="link-href"
              className="field-input"
              value={draft?.href ?? ""}
              onChange={(event) => draft && setDraft({ ...draft, href: event.target.value })}
              placeholder="https://example.com or /faqs"
              maxLength={400}
            />
          </div>
          <div>
            <label className="field-label" htmlFor="link-icon">
              Icon
            </label>
            <select
              id="link-icon"
              className="field-input"
              value={draft?.icon ?? "link"}
              onChange={(event) =>
                draft && setDraft({ ...draft, icon: event.target.value as LinkIcon })
              }
            >
              {ICON_OPTIONS.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        {error && (
          <p className="field-error" role="alert">
            {error}
          </p>
        )}

        <div className="modal-actions modal-actions-split">
          {draft?.id ? (
            <button type="button" className="btn btn-danger" onClick={() => removeLink(draft.id!)}>
              <Trash className="h-3.5 w-3.5" />
              Delete link
            </button>
          ) : (
            <span className="field-hint">Saved to this browser immediately.</span>
          )}
          <span className="modal-actions-group">
            <button type="button" className="btn btn-ghost" onClick={() => setDraft(null)}>
              Cancel
            </button>
            <button type="button" className="btn btn-aqua" onClick={saveDraft}>
              Save link
            </button>
          </span>
        </div>
      </Modal>
    </section>
  );
}
