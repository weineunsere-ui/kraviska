import { useEffect, useRef, useState } from "react";
import type { CSSProperties, DragEvent } from "react";
import { backdropImage } from "@/assets/images";
import {
  describeMediaFile,
  mediaLimitMessage,
  putMedia,
  useMediaUrl,
} from "@/lib/mediaStore";
import {
  DEFAULT_SITE,
  updateSiteContent,
  useSiteContent,
  type BackgroundFit,
  type BackgroundSettings,
} from "@/lib/siteContent";
import { playSaved } from "@/lib/audio";
import { Modal } from "@/components/ui";
import { Asterisk, ImageIcon, Trash, Upload } from "@/components/Icons";

type PendingUpload = {
  blob: Blob;
  kind: "image" | "video";
  fileName: string;
  previewUrl: string;
};

const FIT_OPTIONS: Array<{ value: BackgroundFit; label: string; note: string }> = [
  { value: "cover", label: "Fill", note: "Crops to cover the screen" },
  { value: "contain", label: "Fit", note: "Shows the whole file" },
  { value: "stretch", label: "Stretch", note: "Fills without preserving ratio" },
  { value: "tile", label: "Tile", note: "Repeats across the page" },
];

const PRESETS: Array<{
  name: string;
  note: string;
  filters: BackgroundSettings["filters"];
}> = [
  {
    name: "Original",
    note: "As uploaded",
    filters: { brightness: 1, saturation: 1, contrast: 1, blur: 0, noise: 0.03 },
  },
  {
    name: "Soft rain",
    note: "Muted & hazy",
    filters: { brightness: 0.82, saturation: 0.72, contrast: 1.05, blur: 2, noise: 0.09 },
  },
  {
    name: "Silver",
    note: "Quietly monochrome",
    filters: { brightness: 0.86, saturation: 0, contrast: 1.18, blur: 0.5, noise: 0.06 },
  },
  {
    name: "Deep night",
    note: "Low, dark & soft",
    filters: { brightness: 0.52, saturation: 0.55, contrast: 1.28, blur: 3, noise: 0.1 },
  },
  {
    name: "Sea glass",
    note: "A turquoise breath",
    filters: { brightness: 0.94, saturation: 0.9, contrast: 1.08, blur: 0, noise: 0.05 },
  },
];

function fitStyles(fit: BackgroundFit): CSSProperties {
  if (fit === "stretch") return { backgroundSize: "100% 100%", backgroundRepeat: "no-repeat" };
  if (fit === "contain") return { backgroundSize: "contain", backgroundRepeat: "no-repeat" };
  if (fit === "tile") return { backgroundSize: "340px auto", backgroundRepeat: "repeat" };
  return { backgroundSize: "cover", backgroundRepeat: "no-repeat" };
}

export function BackgroundStudio({ open, onClose }: { open: boolean; onClose: () => void }) {
  const site = useSiteContent();
  const currentUrl = useMediaUrl(site.background.mediaKey);
  const [settings, setSettings] = useState<BackgroundSettings>(site.background);
  const [pending, setPending] = useState<PendingUpload | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const previewRef = useRef<string | null>(null);

  useEffect(() => {
    if (!open) return;
    setSettings(site.background);
    setPending(null);
    setError("");
    setBusy(false);
  }, [open, site.background]);

  useEffect(
    () => () => {
      if (previewRef.current) URL.revokeObjectURL(previewRef.current);
    },
    [],
  );

  const clearPreview = () => {
    if (previewRef.current) {
      URL.revokeObjectURL(previewRef.current);
      previewRef.current = null;
    }
  };

  async function acceptFile(file?: File) {
    if (!file) return;
    const limit = mediaLimitMessage(file);
    if (limit) {
      setError(limit);
      return;
    }
    clearPreview();
    const previewUrl = URL.createObjectURL(file);
    previewRef.current = previewUrl;
    setPending({
      blob: file,
      kind: describeMediaFile(file),
      fileName: file.name,
      previewUrl,
    });
    setSettings((current) => ({
      ...current,
      kind: "media",
      mediaType: describeMediaFile(file),
      fit: current.fit === "tile" && describeMediaFile(file) === "video" ? "cover" : current.fit,
    }));
    setError("");
    if (inputRef.current) inputRef.current.value = "";
  }

  function onDrop(event: DragEvent<HTMLButtonElement>) {
    event.preventDefault();
    setDragging(false);
    void acceptFile(event.dataTransfer.files?.[0]);
  }

  function useDefault() {
    clearPreview();
    setPending(null);
    setSettings((current) => ({
      ...current,
      kind: "default",
      mediaKey: null,
      mediaType: "image",
      fileName: "",
    }));
    setError("");
  }

  async function saveBackground() {
    setBusy(true);
    setError("");
    try {
      let next = settings;
      if (settings.kind === "media") {
        if (pending) {
          const key = `background-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
          await putMedia(key, pending.blob);
          next = {
            ...settings,
            mediaKey: key,
            mediaType: pending.kind,
            fileName: pending.fileName,
          };
        } else if (!next.mediaKey) {
          setError("Choose a background file first, or use the default scene.");
          setBusy(false);
          return;
        }
      }
      updateSiteContent((draft) => {
        draft.background = next;
      });
      playSaved();
      clearPreview();
      setPending(null);
      onClose();
    } catch {
      setError("That background could not be stored in this browser.");
    } finally {
      setBusy(false);
    }
  }

  const hasMedia = settings.kind === "media";
  const sourceUrl = pending?.previewUrl ?? currentUrl;
  const isVideo = hasMedia && settings.mediaType === "video";
  const previewImage = sourceUrl ?? backdropImage;
  const defaultScene = !sourceUrl && settings.kind === "default";
  const previewFilter = `brightness(${settings.filters.brightness}) saturate(${
    settings.filters.saturation * (defaultScene ? 0.3 : 1)
  }) contrast(${settings.filters.contrast}) blur(${settings.filters.blur}px)`;

  return (
    <Modal
      open={open}
      onClose={onClose}
      labelledBy="background-title"
      className="background-dialog"
    >
      <div className="modal-kicker">
        <Asterisk className="h-3.5 w-3.5 text-[var(--aqua)]" />
        Studio / atmosphere
      </div>
      <h2 id="background-title" className="modal-title">
        Background studio
      </h2>
      <p className="modal-copy">
        Upload an image, animated GIF or looping video, then tune its framing and atmosphere.
        The preview below updates before anything is saved.
      </p>

      <div className="background-layout">
        <div className="background-controls">
          <div className="background-section-label">Source</div>
          <input
            ref={inputRef}
            type="file"
            accept="image/*,video/*"
            className="sr-only"
            onChange={(event) => void acceptFile(event.target.files?.[0])}
          />
          <button
            type="button"
            className={`dropzone background-dropzone ${dragging ? "is-dragging" : ""}`}
            onClick={() => inputRef.current?.click()}
            onDragOver={(event) => {
              event.preventDefault();
              setDragging(true);
            }}
            onDragLeave={() => setDragging(false)}
            onDrop={onDrop}
          >
            <span className="dropzone-icon">
              <Upload className="h-5 w-5" />
            </span>
            <span className="dropzone-title">Drop a background, or browse</span>
            <span className="dropzone-hint">GIF · JPG · PNG · MP4 · WEBM · up to 40 MB</span>
          </button>

          <div className="background-source-row">
            <span className="background-source-name">
              <ImageIcon className="h-3.5 w-3.5" />
              {pending?.fileName ||
                (site.background.kind === "media"
                  ? site.background.fileName || "Current upload"
                  : "Default rainy scene")}
            </span>
            <button type="button" className="text-link" onClick={useDefault}>
              <Trash className="h-3 w-3" /> Use default
            </button>
          </div>

          <div className="background-section-label mt-5">Framing</div>
          <div className="fit-grid">
            {FIT_OPTIONS.map((option) => {
              const disabled = isVideo && option.value === "tile";
              return (
                <button
                  key={option.value}
                  type="button"
                  className={`fit-option ${settings.fit === option.value ? "is-active" : ""}`}
                  onClick={() => setSettings({ ...settings, fit: option.value })}
                  disabled={disabled}
                  title={disabled ? "Tiling requires an image or GIF" : option.note}
                >
                  <span className={`fit-icon fit-icon-${option.value}`} aria-hidden="true">
                    <i />
                  </span>
                  <span>
                    <strong>{option.label}</strong>
                    <small>{option.note}</small>
                  </span>
                </button>
              );
            })}
          </div>

          <div className="background-section-label mt-5">Presets</div>
          <div className="preset-grid">
            {PRESETS.map((preset) => (
              <button
                key={preset.name}
                type="button"
                className={`preset-card ${JSON.stringify(settings.filters) === JSON.stringify(preset.filters) ? "is-active" : ""}`}
                onClick={() => setSettings({ ...settings, filters: preset.filters })}
              >
                <span
                  className="preset-thumb"
                  style={{
                    backgroundImage: `url(${previewImage})`,
                    filter: `brightness(${preset.filters.brightness}) saturate(${preset.filters.saturation}) contrast(${preset.filters.contrast}) blur(${preset.filters.blur}px)`,
                  }}
                />
                <span className="preset-copy">
                  <strong>{preset.name}</strong>
                  <small>{preset.note}</small>
                </span>
              </button>
            ))}
          </div>
        </div>

        <div className="background-preview-column">
          <div className="background-preview">
            <div
              className="background-preview-filter"
              style={{
                filter: previewFilter,
              }}
            >
              {isVideo && sourceUrl ? (
                <video
                  className="background-preview-video"
                  src={sourceUrl}
                  autoPlay
                  muted
                  loop
                  playsInline
                  style={{ objectFit: settings.fit === "stretch" ? "fill" : settings.fit === "contain" ? "contain" : "cover" }}
                />
              ) : (
                <div
                  className="background-preview-image"
                  style={{ backgroundImage: `url(${previewImage})`, ...fitStyles(settings.fit) }}
                />
              )}
            </div>
            <div className="background-preview-content" aria-hidden="true">
              <span>Live preview</span>
              <strong>KRAVISKA</strong>
              <small>Hover &amp; save to apply</small>
            </div>
            <span
              className="background-preview-noise"
              style={{ opacity: settings.filters.noise }}
            />
          </div>

          <div className="filter-sliders">
            {(
              [
                ["brightness", "Brightness", 0.2, 1.7, 0.01],
                ["saturation", "Saturation", 0, 2, 0.01],
                ["contrast", "Contrast", 0.5, 1.8, 0.01],
                ["blur", "Blur", 0, 16, 0.5],
                ["noise", "Noise / grain", 0, 0.3, 0.01],
              ] as const
            ).map(([key, label, min, max, step]) => (
              <label className="slider-row" key={key}>
                <span className="slider-label">
                  {label}
                  <em>{key === "blur" ? `${settings.filters[key]}px` : settings.filters[key]}</em>
                </span>
                <input
                  type="range"
                  min={min}
                  max={max}
                  step={step}
                  value={settings.filters[key]}
                  onChange={(event) =>
                    setSettings({
                      ...settings,
                      filters: { ...settings.filters, [key]: Number(event.target.value) },
                    })
                  }
                />
              </label>
            ))}
          </div>

          <div className="background-note">
            <Asterisk className="h-3.5 w-3.5" />
            Videos and GIFs loop automatically. Large files stay in this browser&apos;s media store.
          </div>
        </div>
      </div>

      {error && (
        <p className="field-error" role="alert">
          {error}
        </p>
      )}

      <div className="modal-actions modal-actions-split">
        <button type="button" className="btn btn-ghost" onClick={() =>
          setSettings((current) => ({ ...current, filters: DEFAULT_SITE.background.filters }))
        }>
          Reset filters
        </button>
        <span className="modal-actions-group">
          <button type="button" className="btn btn-ghost" onClick={onClose} disabled={busy}>
            Cancel
          </button>
          <button type="button" className="btn btn-aqua" onClick={() => void saveBackground()} disabled={busy}>
            {busy ? "Saving…" : "Save background"}
          </button>
        </span>
      </div>
    </Modal>
  );
}
