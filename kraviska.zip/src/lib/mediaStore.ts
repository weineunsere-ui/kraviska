import { useEffect, useState } from "react";

/**
 * Owner uploads (images, GIFs, videos and backgrounds) live in IndexedDB,
 * which gives us far more room than localStorage. Gallery metadata and site
 * content stay in localStorage so the UI boots instantly.
 */

const DB_NAME = "kraviska-studio";
const DB_VERSION = 1;
const STORE = "media";

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") {
      reject(new Error("This browser does not support local media storage."));
      return;
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("Could not open media storage."));
  });
}

export async function putMedia(key: string, blob: Blob): Promise<void> {
  const db = await openDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).put(blob, key);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error ?? new Error("Could not save that file."));
  });
  db.close();
}

export async function getMedia(key: string): Promise<Blob | null> {
  const db = await openDb();
  const result = await new Promise<Blob | null>((resolve, reject) => {
    const tx = db.transaction(STORE, "readonly");
    const request = tx.objectStore(STORE).get(key);
    request.onsuccess = () => resolve((request.result as Blob | undefined) ?? null);
    request.onerror = () => reject(request.error ?? new Error("Could not read that file."));
  });
  db.close();
  return result;
}

export async function deleteMedia(key: string): Promise<void> {
  const db = await openDb();
  await new Promise<void>((resolve) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).delete(key);
    tx.oncomplete = () => resolve();
    tx.onerror = () => resolve();
  });
  db.close();
}

/** Resolve a stored upload into a displayable object URL. */
export function useMediaUrl(key?: string | null): string | undefined {
  const [url, setUrl] = useState<string | undefined>(undefined);

  useEffect(() => {
    if (!key) {
      setUrl(undefined);
      return;
    }
    let objectUrl: string | undefined;
    let active = true;
    getMedia(key)
      .then((blob) => {
        if (!blob || !active) return;
        objectUrl = URL.createObjectURL(blob);
        setUrl(objectUrl);
      })
      .catch(() => setUrl(undefined));
    return () => {
      active = false;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [key]);

  return url;
}

export function describeMediaFile(file: File): "image" | "video" {
  return file.type.startsWith("video/") ? "video" : "image";
}

export function isAnimatedImage(file: File): boolean {
  return file.type === "image/gif";
}

export function mediaLimitMessage(file: File): string | null {
  if (!file.type.startsWith("image/") && !file.type.startsWith("video/")) {
    return "Please choose an image, GIF or video file.";
  }
  const video = file.type.startsWith("video/");
  const limit = video ? 40 : 20;
  if (file.size > limit * 1024 * 1024) {
    return `That file is larger than ${limit} MB. Please choose a smaller one.`;
  }
  return null;
}

/**
 * Fast-path for uploads. Small files are stored untouched; larger stills are
 * compressed, but never allowed to block the dialog if canvas conversion is
 * unavailable or slow on a particular browser.
 */
export async function prepareImageBlob(file: File): Promise<Blob> {
  if (file.size <= 700 * 1024) return file;
  try {
    const compressed = await Promise.race<Blob>([
      compressImage(file),
      new Promise<Blob>((resolve) => {
        window.setTimeout(() => resolve(file), 4500);
      }),
    ]);
    return compressed;
  } catch {
    return file;
  }
}

/** Create a compressed JPEG blob for a still image upload. */
export async function compressImage(file: File): Promise<Blob> {
  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("That image could not be read."));
    reader.readAsDataURL(file);
  });

  const image = await new Promise<HTMLImageElement>((resolve, reject) => {
    const element = new Image();
    element.onload = () => resolve(element);
    element.onerror = () => reject(new Error("That image could not be opened."));
    element.src = dataUrl;
  });

  const maxSide = 1600;
  const scale = Math.min(1, maxSide / Math.max(image.width, image.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(image.width * scale));
  canvas.height = Math.max(1, Math.round(image.height * scale));
  const context = canvas.getContext("2d");
  if (!context) return file;
  context.fillStyle = "#0a0c0c";
  context.fillRect(0, 0, canvas.width, canvas.height);
  context.imageSmoothingQuality = "high";
  context.drawImage(image, 0, 0, canvas.width, canvas.height);
  const blob = await new Promise<Blob | null>((resolve) =>
    canvas.toBlob(resolve, "image/jpeg", 0.86),
  );
  return blob ?? file;
}
