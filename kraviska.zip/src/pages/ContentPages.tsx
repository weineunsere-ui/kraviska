import { useState } from "react";
import { PLACEHOLDER_TEXT } from "@/lib/gallery";
import {
  newId,
  updateSiteContent,
  usePageContent,
  type AccordionEntry,
  type FaqEntry,
  type InfoCard,
  type PageKey,
} from "@/lib/siteContent";
import { ContentShell, EndNote, PageIntro, SectionLabel } from "@/components/ui";
import { EditableText } from "@/components/Editable";
import { EditLabel } from "@/components/EditLabel";
import { Gallery } from "@/components/Gallery";
import { ContentLinks } from "@/components/ContentLinks";
import { DocumentLinks } from "@/components/DocumentLinks";
import { DocumentViewer } from "@/components/DocumentViewer";
import type { DocumentSlot } from "@/lib/documents";
import {
  Asterisk,
  ChevronDown,
  Minus,
  Pencil,
  Plus,
  Sparkle,
  Trash,
} from "@/components/Icons";

const placeholder = PLACEHOLDER_TEXT;

function usePageEditor(pageKey: PageKey) {
  const page = usePageContent(pageKey);
  const save = (patch: Partial<typeof page>) =>
    updateSiteContent((draft) => {
      draft.pages[pageKey] = { ...draft.pages[pageKey], ...patch };
    });
  return { page, save };
}

function EditableSectionHeading({
  pageKey,
  owner,
}: {
  pageKey: PageKey;
  owner: boolean;
}) {
  const { page, save } = usePageEditor(pageKey);
  return (
    <SectionLabel
      meta={
        <EditableText
          owner={owner}
          as="span"
          value={page.sectionMeta}
          onChange={(value) => save({ sectionMeta: value })}
          label="Edit section note"
        />
      }
    >
      <EditableText
        owner={owner}
        as="span"
        value={page.sectionLabel}
        onChange={(value) => save({ sectionLabel: value })}
        label="Edit section label"
      />
    </SectionLabel>
  );
}

/* ------------------------------------------------------------------ */
/* LINKS                                                               */
/* ------------------------------------------------------------------ */

export function LinksPage({ owner }: { owner: boolean }) {
  return (
    <ContentShell>
      <PageIntro index="01" pageKey="links" owner={owner} />
      <ContentLinks pageKey="links" owner={owner} />
      <EndNote pageKey="links" owner={owner} />
    </ContentShell>
  );
}

/* ------------------------------------------------------------------ */
/* ART EXAMPLE                                                         */
/* ------------------------------------------------------------------ */

export function ArtExamplePage({ owner }: { owner: boolean }) {
  return (
    <ContentShell>
      <PageIntro index="02" pageKey="art" owner={owner} />
      <div className="page-section">
        <Gallery section="art" owner={owner} />
      </div>
      <EndNote pageKey="art" owner={owner} />
    </ContentShell>
  );
}

/* ------------------------------------------------------------------ */
/* COMMISSION INFORMATION                                              */
/* ------------------------------------------------------------------ */

export function CommissionInformationPage({ owner }: { owner: boolean }) {
  const page = usePageContent("commission");
  const [documentOpen, setDocumentOpen] = useState<{ slot: DocumentSlot; title: string } | null>(null);
  return (
    <ContentShell>
      <PageIntro index="03" pageKey="commission" owner={owner} />
      <DocumentLinks
        owner={owner}
        onOpen={(slot, title) => setDocumentOpen({ slot, title })}
      />
      <DocumentViewer
        slot={documentOpen?.slot ?? "price-sheets"}
        title={documentOpen?.title ?? page.links[0]?.label ?? "Document"}
        open={Boolean(documentOpen)}
        onClose={() => setDocumentOpen(null)}
      />
      <EndNote pageKey="commission" owner={owner} />
    </ContentShell>
  );
}

/* ------------------------------------------------------------------ */
/* MONTHLY OFFERS & MORE                                               */
/* ------------------------------------------------------------------ */

export function MonthlyOffersPage({ owner }: { owner: boolean }) {
  return (
    <ContentShell>
      <PageIntro index="04" pageKey="offers" owner={owner} />
      <div className="page-section">
        <Gallery section="offers" owner={owner} />
      </div>
      <EndNote pageKey="offers" owner={owner} />
    </ContentShell>
  );
}

/* ------------------------------------------------------------------ */
/* PAYMENT METHODS                                                     */
/* ------------------------------------------------------------------ */

export function PaymentMethodsPage({ owner }: { owner: boolean }) {
  return (
    <ContentShell>
      <PageIntro index="05" pageKey="payments" owner={owner} />
      <ContentLinks pageKey="payments" owner={owner} />
      <EndNote pageKey="payments" owner={owner} />
    </ContentShell>
  );
}

/* ------------------------------------------------------------------ */
/* ABOUT ME                                                            */
/* ------------------------------------------------------------------ */

export function AboutMePage({ owner }: { owner: boolean }) {
  const { page, save } = usePageEditor("aboutMe");
  const [openIds, setOpenIds] = useState<string[]>(
    page.accordions[0] ? [page.accordions[0].id] : [],
  );

  const toggle = (id: string) =>
    setOpenIds((current) =>
      current.includes(id) ? current.filter((item) => item !== id) : [...current, id],
    );

  const patchEntry = (id: string, patch: Partial<AccordionEntry>) =>
    save({
      accordions: page.accordions.map((entry) =>
        entry.id === id ? { ...entry, ...patch } : entry,
      ),
    });

  const addSection = () => {
    const entry = { id: newId("section"), title: "NEW SECTION", text: placeholder };
    save({ accordions: [...page.accordions, entry] });
    setOpenIds((current) => [...current, entry.id]);
  };

  const removeSection = (id: string) =>
    save({ accordions: page.accordions.filter((entry) => entry.id !== id) });

  return (
    <ContentShell>
      <PageIntro index="06" pageKey="aboutMe" owner={owner} />

      <section className="page-section" aria-label="About me details">
        <EditableSectionHeading pageKey="aboutMe" owner={owner} />

        <div className="accordion-stack">
          {page.accordions.map((entry, index) => {
            const isOpen = openIds.includes(entry.id);
            const panelId = `about-panel-${entry.id}`;
            return (
              <div className={`accordion ${isOpen ? "is-open" : ""}`} key={entry.id}>
                {owner ? (
                  <div className="accordion-trigger accordion-trigger-owner">
                    <span className="accordion-number mono-label">
                      {String(index + 1).padStart(2, "0")}
                    </span>
                    <EditableText
                      owner={owner}
                      as="span"
                      className="accordion-title"
                      value={entry.title}
                      onChange={(value) => patchEntry(entry.id, { title: value })}
                      label="Edit section title"
                      maxLength={80}
                    />
                    <div className="owner-inline-actions">
                      <button
                        type="button"
                        className="row-owner-btn is-danger"
                        onClick={() => removeSection(entry.id)}
                        aria-label={`Delete ${entry.title}`}
                      >
                        <Trash className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        className="accordion-icon"
                        onClick={() => toggle(entry.id)}
                        aria-expanded={isOpen}
                        aria-controls={panelId}
                        aria-label={`${isOpen ? "Collapse" : "Expand"} ${entry.title}`}
                      >
                        {isOpen ? <Minus className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    type="button"
                    className="accordion-trigger"
                    aria-expanded={isOpen}
                    aria-controls={panelId}
                    onClick={() => toggle(entry.id)}
                  >
                    <span className="accordion-number mono-label">
                      {String(index + 1).padStart(2, "0")}
                    </span>
                    <span className="accordion-title">{entry.title}</span>
                    <span className="accordion-icon" aria-hidden="true">
                      {isOpen ? <Minus className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
                    </span>
                  </button>
                )}
                <div id={panelId} className="accordion-panel" role="region" aria-label={entry.title}>
                  <div className="accordion-panel-inner">
                    <EditableText
                      owner={owner}
                      as="p"
                      multiline
                      className="placeholder-copy"
                      value={entry.text}
                      onChange={(value) => patchEntry(entry.id, { text: value })}
                      label={`Edit ${entry.title}`}
                      maxLength={1200}
                    />
                    <span className="accordion-inner-mark" aria-hidden="true">
                      <Asterisk className="h-4 w-4" />
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {owner && (
          <div className="content-add-row">
            <button type="button" className="btn btn-aqua btn-add" onClick={addSection}>
              <Plus className="h-4 w-4" />
              Add collapsible section
            </button>
            <span className="content-add-hint">New sections match the existing rows.</span>
          </div>
        )}
      </section>

      <EndNote pageKey="aboutMe" owner={owner} />
    </ContentShell>
  );
}

/* ------------------------------------------------------------------ */
/* FAQS                                                                */
/* ------------------------------------------------------------------ */

export function FaqsPage({ owner }: { owner: boolean }) {
  const { page, save } = usePageEditor("faqs");

  const patchFaq = (id: string, patch: Partial<FaqEntry>) =>
    save({
      faqs: page.faqs.map((faq) => (faq.id === id ? { ...faq, ...patch } : faq)),
    });

  const addFaq = () =>
    save({
      faqs: [...page.faqs, { id: newId("faq"), question: "New question?", answer: placeholder }],
    });

  const removeFaq = (id: string) => save({ faqs: page.faqs.filter((faq) => faq.id !== id) });

  return (
    <ContentShell>
      <PageIntro index="07" pageKey="faqs" owner={owner} />

      <section className="page-section" aria-label="Frequently asked questions">
        <EditableSectionHeading pageKey="faqs" owner={owner} />

        <ol className="faq-list">
          {page.faqs.map((faq, index) => (
            <li className="faq-item" key={faq.id}>
              <div className="faq-item-top">
                <h2 className="faq-question">
                  <span className="faq-number mono-label" aria-hidden="true">
                    {String(index + 1).padStart(2, "0")}
                  </span>
                  <EditableText
                    owner={owner}
                    as="span"
                    value={faq.question}
                    onChange={(value) => patchFaq(faq.id, { question: value })}
                    label="Edit question"
                    maxLength={180}
                  />
                </h2>
                {owner && (
                  <button
                    type="button"
                    className="row-owner-btn is-danger faq-delete"
                    onClick={() => removeFaq(faq.id)}
                    aria-label={`Delete question ${faq.question}`}
                  >
                    <Trash className="h-3.5 w-3.5" />
                  </button>
                )}
              </div>
              <EditableText
                owner={owner}
                as="p"
                multiline
                className="faq-answer placeholder-copy"
                value={faq.answer}
                onChange={(value) => patchFaq(faq.id, { answer: value })}
                label="Edit answer"
                maxLength={1200}
              />
            </li>
          ))}
        </ol>

        {owner && (
          <div className="content-add-row">
            <button type="button" className="btn btn-aqua btn-add" onClick={addFaq}>
              <Plus className="h-4 w-4" />
              Add question
            </button>
            <span className="content-add-hint">Questions stay labelled as h2 headings.</span>
          </div>
        )}
      </section>

      <EndNote pageKey="faqs" owner={owner} />
    </ContentShell>
  );
}

/* ------------------------------------------------------------------ */
/* ABOUT PAGE                                                          */
/* ------------------------------------------------------------------ */

export function AboutPage({ owner }: { owner: boolean }) {
  const { page, save } = usePageEditor("aboutPage");

  const patchCard = (id: string, patch: Partial<InfoCard>) =>
    save({
      cards: page.cards.map((card) => (card.id === id ? { ...card, ...patch } : card)),
    });

  const addCard = () =>
    save({
      cards: [...page.cards, { id: newId("card"), label: "NEW PANEL", text: placeholder }],
    });

  return (
    <ContentShell>
      <PageIntro index="08" pageKey="aboutPage" owner={owner} />

      <section className="page-section" aria-label="About this website">
        <EditableSectionHeading pageKey="aboutPage" owner={owner} />

        <div className="about-page-cards">
          {page.cards.map((card, index) => (
            <article className="info-card" key={card.id}>
              <div className="info-card-top">
                <span className="mono-label">{String(index + 1).padStart(2, "0")}</span>
                <div className="owner-inline-actions">
                  {owner && (
                    <button
                      type="button"
                      className="row-owner-btn is-danger"
                      onClick={() =>
                        save({ cards: page.cards.filter((entry) => entry.id !== card.id) })
                      }
                      aria-label={`Delete ${card.label}`}
                    >
                      <Trash className="h-3 w-3" />
                    </button>
                  )}
                  <Sparkle className="h-4 w-4 text-[var(--aqua)]" />
                </div>
              </div>
              <EditableText
                owner={owner}
                as="h2"
                value={card.label}
                onChange={(value) => patchCard(card.id, { label: value })}
                label="Edit panel title"
                maxLength={80}
              />
              <EditableText
                owner={owner}
                as="p"
                multiline
                className="placeholder-copy"
                value={card.text}
                onChange={(value) => patchCard(card.id, { text: value })}
                label={`Edit ${card.label}`}
                maxLength={600}
              />
            </article>
          ))}
        </div>

        {owner && (
          <div className="content-add-row">
            <button type="button" className="btn btn-aqua btn-add" onClick={addCard}>
              <Plus className="h-4 w-4" />
              Add panel
            </button>
            <span className="content-add-hint">Panels flow into the same three-column grid.</span>
          </div>
        )}

        <div className="domain-plate">
          <span className="mono-label">
            <EditLabel k="homeAddress" owner={owner} />
          </span>
          <EditLabel k="domain" owner={owner} as="p" />
          <span className="domain-plate-mark" aria-hidden="true">
            <Sparkle className="h-4 w-4" />
          </span>
        </div>
      </section>

      <EndNote pageKey="aboutPage" owner={owner} />
    </ContentShell>
  );
}

/* ------------------------------------------------------------------ */
/* Small owner helpers exported for consistency                        */
/* ------------------------------------------------------------------ */

export function OwnerEditBadge() {
  return (
    <span className="owner-edit-badge">
      <Pencil className="h-3 w-3" />
      Click text to edit
    </span>
  );
}

export function ExpandMark({ open }: { open: boolean }) {
  return <ChevronDown className={`h-4 w-4 ${open ? "rotate-180" : ""}`} />;
}
