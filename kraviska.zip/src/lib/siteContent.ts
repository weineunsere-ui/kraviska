import { useSyncExternalStore } from "react";
import { PLACEHOLDER_TEXT, defaultGalleryStoreJson } from "@/lib/gallery";
import { defaultDocumentsJson, documentsSnapshot, restoreDocumentsSnapshot } from "@/lib/documents";

export type PageKey =
  | "links"
  | "art"
  | "commission"
  | "offers"
  | "payments"
  | "aboutMe"
  | "faqs"
  | "aboutPage";

export type LinkIcon =
  | "instagram"
  | "tiktok"
  | "vgen"
  | "discord"
  | "gumroad"
  | "payoneer"
  | "steam"
  | "file"
  | "sparkle"
  | "link";

export type PageLink = {
  id: string;
  label: string;
  description: string;
  href: string;
  icon: LinkIcon;
};

export type FaqEntry = { id: string; question: string; answer: string };
export type AccordionEntry = { id: string; title: string; text: string };
export type InfoCard = { id: string; label: string; text: string };

export type PageContent = {
  title: string;
  lead: string;
  meta: string;
  end: string;
  sectionLabel: string;
  sectionMeta: string;
  links: PageLink[];
  faqs: FaqEntry[];
  accordions: AccordionEntry[];
  cards: InfoCard[];
};

export type HomeCard = {
  id: string;
  label: string;
  note: string;
  href: string;
};

export type HomeContent = {
  eyebrow: string;
  heading: string;
  lead: string;
  end: string;
  soulsTitle: string;
  cards: HomeCard[];
};

export type BackgroundFit = "cover" | "contain" | "stretch" | "tile";

export type BackgroundSettings = {
  kind: "default" | "media";
  mediaKey: string | null;
  mediaType: "image" | "video";
  fileName: string;
  fit: BackgroundFit;
  filters: {
    brightness: number;
    saturation: number;
    contrast: number;
    blur: number;
    noise: number;
  };
};

export type WarningContent = {
  kicker: string;
  heading: string;
  accent: string;
  body: string;
  okText: string;
  footnote: string;
};

export type SiteLabels = {
  brand: string;
  brandDomain: string;
  status: string;
  soundOn: string;
  soundOff: string;
  ownerLabel: string;
  studioLabel: string;
  footerTagline: string;
  footerDomain: string;
  backToIndex: string;
  sectionPrefix: string;
  established: string;
  heroVolume: string;
  heroDomain: string;
  choosePage: string;
  indexPrefix: string;
  updatesNumber: string;
  lastEdited: string;
  steward: string;
  author: string;
  homeAddress: string;
  domain: string;
  endOfPage: string;
  curatorView: string;
  viewOnly: string;
  selectedMedia: string;
  allMedia: string;
  pinned: string;
  artistsNote: string;
  galleryEmpty: string;
  noLinks: string;
  lastEditedValue: string;
  nowViewing: string;
  viewerFooter: string;
  documentMissing: string;
  documentDropTitle: string;
  documentDropHint: string;
  documentReplace: string;
  documentClear: string;
  documentPages: string;
  documentPdf: string;
  documentOpen: string;
  documentDownload: string;
  galleryNoteOwner: string;
  galleryNoteVisitor: string;
  nothingPinned: string;
  folderWaiting: string;
  homeIndexLabel: string;
  linkPdf: string;
  linkPage: string;
  linkExternal: string;
  mediaImage: string;
  mediaVideo: string;
  pdfOpenTab: string;
  pdfPreparing: string;
  documentEmptyTitle: string;
  documentReorder: string;
  documentReorderHelp: string;
  documentConfirmPdf: string;
  documentConfirmPdfHelp: string;
  documentSave: string;
  documentCancel: string;
  documentDropHere: string;
  documentPagesCount: string;
  documentViewerHint: string;
  documentUploadOwnerOnly: string;
  emptyPlaceholder: string;
  commissionExtras: string;
  commissionExtrasNote: string;
};

export type SiteContent = {
  updatedAt: string;
  home: HomeContent;
  pages: Record<PageKey, PageContent>;
  background: BackgroundSettings;
  warning: WarningContent;
  labels: SiteLabels;
};

export type SiteVersion = {
  id: string;
  number: number;
  label: string;
  createdAt: string;
  content: SiteContent;
  /** Galleries and documents are stored separately; snapshot them too. */
  galleries?: string | null;
  documents?: string | null;
};

const GALLERY_STORE_KEY = "kraviska.galleries.v4";

const STORE_KEY = "kraviska.site.content.v3";
const MIGRATIONS_KEY = "kraviska.migrations.v1";
const LEGACY_KEYS = ["kraviska.site.content.v2"];
const VERSIONS_KEY = "kraviska.versions.v1";
const CHANNEL_KEY = "kraviska.channel.v1";
const EVENT = "kraviska:content-changed";
const MAX_VERSIONS = 80;

const id = (prefix: string) => `${prefix}-${Math.random().toString(36).slice(2, 8)}`;

export const DEFAULT_BACKGROUND: BackgroundSettings = {
  kind: "default",
  mediaKey: null,
  mediaType: "image",
  fileName: "",
  fit: "cover",
  filters: { brightness: 1, saturation: 1, contrast: 1, blur: 0, noise: 0.03 },
};

export const DEFAULT_LABELS: SiteLabels = {
  brand: "KRAVISKA",
  brandDomain: ".org",
  status: "Open for commissions",
  soundOn: "Sound on",
  soundOff: "Sound off",
  ownerLabel: "Owner",
  studioLabel: "Studio",
  footerTagline: "Art & commissions",
  footerDomain: "kraviska.org",
  backToIndex: "Back to index",
  sectionPrefix: "Section",
  established: "Est. 2021",
  heroVolume: "Portfolio · Vol. 01",
  heroDomain: "kraviska.org",
  choosePage: "Choose a page",
  indexPrefix: "Index of pages",
  updatesNumber: "Updates / 09",
  lastEdited: "Last edited",
  steward: "Site steward",
  author: "Made by Unsere",
  homeAddress: "Home address",
  domain: "kraviska.org",
  endOfPage: "End of page — kraviska.org",
  curatorView: "Curator view",
  viewOnly: "View only",
  selectedMedia: "Selected media",
  allMedia: "All media",
  pinned: "Pinned",
  artistsNote: "Artist's note",
  galleryEmpty: "The archive is being prepared",
  noLinks: "No links yet",
  lastEditedValue: "Auto-updated on every save",
  nowViewing: "Now viewing",
  viewerFooter: "Stored locally on this device",
  documentMissing: "This document has not been uploaded yet.",
  documentDropTitle: "Drag a PDF or images here, or click to browse",
  documentDropHint: "PDF, PNG or JPEG · PDF opens in the viewer · images open in order",
  documentReplace: "Replace document",
  documentClear: "Clear document",
  documentPages: "Image pages",
  documentPdf: "PDF document",
  documentOpen: "Open document",
  documentDownload: "Download",
  galleryNoteOwner: "Organise pieces into folders, pin what matters, and add images, GIFs or videos.",
  galleryNoteVisitor: "Browse pinned work and folders from the archive. Hover a piece for its title.",
  nothingPinned: "Nothing pinned yet",
  folderWaiting: "This folder is waiting",
  homeIndexLabel: "Index",
  linkPdf: "PDF",
  linkPage: "Page",
  linkExternal: "External",
  mediaImage: "Image",
  mediaVideo: "Video",
  pdfOpenTab: "Open in tab",
  pdfPreparing: "Preparing document…",
  documentEmptyTitle: "Nothing uploaded yet",
  documentReorder: "Order the image pages",
  documentReorderHelp: "These pages will be shown from first to last. Move pages until the order is right, then save.",
  documentConfirmPdf: "Add this PDF?",
  documentConfirmPdfHelp: "The PDF is stored in this browser and opens inside the site viewer for every visitor of this device.",
  documentSave: "Add to site",
  documentCancel: "Cancel",
  documentDropHere: "Drop files here",
  documentPagesCount: "pages",
  documentViewerHint: "Pages are displayed in the order chosen by the owner.",
  documentUploadOwnerOnly: "Only the owner can replace this document.",
  emptyPlaceholder: PLACEHOLDER_TEXT,
  commissionExtras: "More from commissions",
  commissionExtrasNote: "Seasonal offers, extras & other useful pages",
};

export const DEFAULT_WARNING: WarningContent = {
  kicker: "Content advisory",
  heading: "WARNING",
  accent: "!",
  body: "The following website contains imagery that may disturb some users. Viewer discretion is advised.",
  okText: "OK",
  footnote: "Proceed only if you are comfortable continuing.",
};

export const DEFAULT_SITE: SiteContent = {
  updatedAt: "2026-02-14T18:30:00.000Z",
  home: {
    eyebrow: "Digital artist & illustrator",
    heading: "WELCOME!",
    lead: PLACEHOLDER_TEXT,
    end: PLACEHOLDER_TEXT,
    soulsTitle: "Number of souls that visited this site: ",
    cards: [
      { id: "home-links", label: "LINKS", note: "Elsewhere on the internet", href: "/links" },
      { id: "home-art", label: "ART EXAMPLE", note: "Selected work & studies", href: "/art-example" },
      {
        id: "home-commission",
        label: "COMMISSION INFORMATION",
        note: "Rates, terms & availability",
        href: "/commission-information",
      },
      {
        id: "home-payments",
        label: "PAYMENT METHODS",
        note: "Where to send payment",
        href: "/payment-methods",
      },
      { id: "home-about", label: "ABOUT ME", note: "The person behind the work", href: "/about-me" },
      { id: "home-faqs", label: "FAQS", note: "Answers, gathered in one place", href: "/faqs" },
      {
        id: "home-aboutpage",
        label: "ABOUT PAGE",
        note: "Notes on this little corner of the web",
        href: "/about-page",
      },
    ],
  },
  pages: {
    links: {
      title: "LINKS",
      lead: PLACEHOLDER_TEXT,
      meta: "Find me elsewhere",
      end: PLACEHOLDER_TEXT,
      sectionLabel: "Elsewhere on the internet",
      sectionMeta: "All links open in a new tab",
      links: [
        { id: "link-instagram", label: "Instagram", description: PLACEHOLDER_TEXT, href: "https://example.com/instagram", icon: "instagram" },
        { id: "link-tiktok", label: "Tiktok", description: PLACEHOLDER_TEXT, href: "https://example.com/tiktok", icon: "tiktok" },
        { id: "link-vgen", label: "VGen", description: PLACEHOLDER_TEXT, href: "https://example.com/vgen", icon: "vgen" },
        { id: "link-discord", label: "Discord", description: PLACEHOLDER_TEXT, href: "https://example.com/discord", icon: "discord" },
      ],
      faqs: [],
      accordions: [],
      cards: [],
    },
    art: {
      title: "ART EXAMPLE",
      lead: PLACEHOLDER_TEXT,
      meta: "Portfolio archive",
      end: PLACEHOLDER_TEXT,
      sectionLabel: "Selected pieces",
      sectionMeta: "View only",
      links: [],
      faqs: [],
      accordions: [],
      cards: [],
    },
    commission: {
      title: "COMMISSION INFORMATION",
      lead: PLACEHOLDER_TEXT,
      meta: "Rates & agreements",
      end: PLACEHOLDER_TEXT,
      sectionLabel: "Everything you need, in one place",
      sectionMeta: "03 documents",
      links: [
        {
          id: "doc-prices",
          label: "PRICE SHEETS",
          description: "Placeholder PDF · opens in the viewer",
          href: "pdf:price-sheets",
          icon: "file",
        },
        { id: "doc-toc", label: "TOC", description: "Placeholder PDF · terms of care", href: "pdf:toc", icon: "file" },
        {
          id: "doc-offers",
          label: "MONTHLY OFFERS & MORE",
          description: "Page · seasonal offers & extras",
          href: "/monthly-offers-and-more",
          icon: "sparkle",
        },
      ],
      faqs: [],
      accordions: [],
      cards: [],
    },
    offers: {
      title: "MONTHLY OFFERS & MORE",
      lead: PLACEHOLDER_TEXT,
      meta: "Seasonal archive",
      end: PLACEHOLDER_TEXT,
      sectionLabel: "Offer archive",
      sectionMeta: "View only",
      links: [],
      faqs: [],
      accordions: [],
      cards: [],
    },
    payments: {
      title: "PAYMENT METHODS",
      lead: PLACEHOLDER_TEXT,
      meta: "Payment information",
      end: PLACEHOLDER_TEXT,
      sectionLabel: "Where to send payment",
      sectionMeta: "Placeholder destinations",
      links: [
        { id: "pay-gumroad", label: "GUMROAD", description: PLACEHOLDER_TEXT, href: "https://example.com/gumroad", icon: "gumroad" },
        { id: "pay-payoneer", label: "PAYONEER", description: PLACEHOLDER_TEXT, href: "https://example.com/payoneer", icon: "payoneer" },
        { id: "pay-steam", label: "STEAM", description: PLACEHOLDER_TEXT, href: "https://example.com/steam", icon: "steam" },
      ],
      faqs: [],
      accordions: [],
      cards: [],
    },
    aboutMe: {
      title: "ABOUT ME",
      lead: PLACEHOLDER_TEXT,
      meta: "A little context",
      end: PLACEHOLDER_TEXT,
      sectionLabel: "A few things, loosely organised",
      sectionMeta: "Select a section",
      links: [],
      faqs: [],
      accordions: [
        { id: "about-likes", title: "LIKES", text: PLACEHOLDER_TEXT },
        { id: "about-interests", title: "INTERESTS", text: PLACEHOLDER_TEXT },
        { id: "about-communication", title: "COMMUNICATION STYLE", text: PLACEHOLDER_TEXT },
        { id: "about-dislikes", title: "DISLIKES", text: PLACEHOLDER_TEXT },
      ],
      cards: [],
    },
    faqs: {
      title: "FAQS",
      lead: PLACEHOLDER_TEXT,
      meta: "Frequently asked",
      end: PLACEHOLDER_TEXT,
      sectionLabel: "Before you send a message",
      sectionMeta: "Questions & answers",
      links: [],
      faqs: [
        { id: "faq-1", question: "How do commissions usually work?", answer: PLACEHOLDER_TEXT },
        { id: "faq-2", question: "What are your expected turnaround times?", answer: PLACEHOLDER_TEXT },
        { id: "faq-3", question: "Can I use the finished artwork commercially?", answer: PLACEHOLDER_TEXT },
        { id: "faq-4", question: "Do you accept character references?", answer: PLACEHOLDER_TEXT },
        { id: "faq-5", question: "How will I receive my finished files?", answer: PLACEHOLDER_TEXT },
        { id: "faq-6", question: "What happens if I need to cancel?", answer: PLACEHOLDER_TEXT },
      ],
      accordions: [],
      cards: [],
    },
    aboutPage: {
      title: "ABOUT PAGE",
      lead: PLACEHOLDER_TEXT,
      meta: "Notes & credits",
      end: PLACEHOLDER_TEXT,
      sectionLabel: "A note on this little corner",
      sectionMeta: "kraviska.org",
      links: [],
      faqs: [],
      accordions: [],
      cards: [
        { id: "aboutpage-site", label: "THE SITE", text: PLACEHOLDER_TEXT },
        { id: "aboutpage-artwork", label: "ARTWORK", text: PLACEHOLDER_TEXT },
        { id: "aboutpage-credits", label: "CREDITS", text: PLACEHOLDER_TEXT },
      ],
    },
  },
  background: DEFAULT_BACKGROUND,
  warning: DEFAULT_WARNING,
  labels: DEFAULT_LABELS,
};

let cache: SiteContent | null = null;

function clone<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T;
}

function mergePage(base: PageContent, saved?: Partial<PageContent>): PageContent {
  if (!saved) return base;
  return {
    ...base,
    ...saved,
    links: Array.isArray(saved.links) ? saved.links : base.links,
    faqs: Array.isArray(saved.faqs) ? saved.faqs : base.faqs,
    accordions: Array.isArray(saved.accordions) ? saved.accordions : base.accordions,
    cards: Array.isArray(saved.cards) ? saved.cards : base.cards,
  };
}

function mergeContent(saved?: Partial<SiteContent> | null): SiteContent {
  const base = clone(DEFAULT_SITE);
  if (!saved) return base;
  const pages = { ...base.pages };
  (Object.keys(base.pages) as PageKey[]).forEach((key) => {
    pages[key] = mergePage(base.pages[key], saved.pages?.[key]);
  });
  return {
    updatedAt: saved.updatedAt ?? base.updatedAt,
    home: {
      ...base.home,
      ...saved.home,
      cards: Array.isArray(saved.home?.cards) ? saved.home!.cards : base.home.cards,
    },
    pages,
    background: {
      ...base.background,
      ...saved.background,
      filters: { ...base.background.filters, ...saved.background?.filters },
    },
    warning: { ...base.warning, ...saved.warning },
    labels: { ...base.labels, ...saved.labels },
  };
}

function hasMigration(id: string): boolean {
  try {
    const raw = window.localStorage.getItem(MIGRATIONS_KEY);
    const parsed = raw ? (JSON.parse(raw) as string[]) : [];
    return Array.isArray(parsed) && parsed.includes(id);
  } catch {
    return false;
  }
}

function markMigration(id: string) {
  try {
    const raw = window.localStorage.getItem(MIGRATIONS_KEY);
    const parsed = raw ? (JSON.parse(raw) as string[]) : [];
    const next = Array.isArray(parsed) ? parsed : [];
    if (!next.includes(id)) next.push(id);
    window.localStorage.setItem(MIGRATIONS_KEY, JSON.stringify(next));
  } catch {
    /* migrations are best-effort */
  }
}

/**
 * One-time content migrations. A previous release placed Monthly Offers on the
 * home page by mistake; it belongs under Commission Information. These
 * migrations correct any saved site without touching a re-created menu button
 * that the owner added deliberately (those receive a new id).
 */
function migrateContent(content: SiteContent): { content: SiteContent; changed: boolean } {
  if (typeof window === "undefined") return { content, changed: false };
  let changed = false;

  if (!hasMigration("monthly-offers-home-button-removed")) {
    const filtered = content.home.cards.filter(
      (card) => card.id !== "home-offers" && card.href !== "/monthly-offers-and-more",
    );
    if (filtered.length !== content.home.cards.length) {
      content.home.cards = filtered;
      changed = true;
    }
    markMigration("monthly-offers-home-button-removed");
  }

  if (!hasMigration("monthly-offers-commission-link")) {
    const commissionLinks = content.pages.commission.links ?? [];
    const hasOffers = commissionLinks.some(
      (link) =>
        link.id === "doc-offers" || link.href === "/monthly-offers-and-more",
    );
    if (!hasOffers) {
      const link = {
        id: "doc-offers",
        label: "MONTHLY OFFERS & MORE",
        description: "Page · seasonal offers & extras",
        href: "/monthly-offers-and-more",
        icon: "sparkle" as const,
      };
      const commissionIndex = commissionLinks.findIndex((entry) => entry.id === "doc-toc");
      const nextLinks = [...commissionLinks];
      nextLinks.splice(
        commissionIndex >= 0 ? commissionIndex + 1 : nextLinks.length,
        0,
        link,
      );
      content.pages.commission.links = nextLinks;
      changed = true;
    }
    markMigration("monthly-offers-commission-link");
  }

  return { content, changed };
}

function readStoredContent(): SiteContent | null {
  try {
    for (const key of [STORE_KEY, ...LEGACY_KEYS]) {
      const raw = window.localStorage.getItem(key);
      if (raw) return mergeContent(JSON.parse(raw) as SiteContent);
    }
  } catch {
    /* ignore corrupt / unavailable storage */
  }
  return null;
}

export function getSiteContent(): SiteContent {
  if (cache) return cache;
  const stored = readStoredContent();
  if (!stored) {
    cache = clone(DEFAULT_SITE);
    return cache;
  }
  const { content, changed } = migrateContent(stored);
  cache = content;
  if (changed) {
    try {
      window.localStorage.setItem(STORE_KEY, JSON.stringify(cache));
    } catch {
      /* the migrated menu is still used for this session */
    }
  }
  return cache;
}

function broadcast() {
  window.dispatchEvent(new Event(EVENT));
  try {
    const channel = new BroadcastChannel(CHANNEL_KEY);
    channel.postMessage("refresh");
    channel.close();
  } catch {
    /* BroadcastChannel is optional */
  }
}

function readVersions(): SiteVersion[] {
  try {
    const raw = window.localStorage.getItem(VERSIONS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as SiteVersion[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeVersions(versions: SiteVersion[]) {
  try {
    window.localStorage.setItem(VERSIONS_KEY, JSON.stringify(versions));
  } catch {
    /* if history is too large, keep the live content working */
  }
}

function ensureBaseline(): SiteVersion[] {
  let versions = readVersions();
  if (versions.length === 0) {
    versions = [
      {
        id: "baseline",
        number: 1,
        label: "Original site",
        createdAt: DEFAULT_SITE.updatedAt,
        content: clone(DEFAULT_SITE),
        galleries: defaultGalleryStoreJson(),
        documents: defaultDocumentsJson(),
      },
    ];
    writeVersions(versions);
    return versions;
  }
  // Older ledgers predate gallery snapshots; seed the original version once.
  if (versions[0] && (!versions[0].galleries || versions[0].documents === undefined)) {
    versions = versions.map((version, index) =>
      index === 0
        ? {
            ...version,
            galleries: version.galleries ?? defaultGalleryStoreJson(),
            documents: version.documents ?? defaultDocumentsJson(),
          }
        : version,
    );
    writeVersions(versions);
  }
  return versions;
}

function recordVersion(content: SiteContent, label: string): SiteVersion[] {
  const versions = ensureBaseline();
  let gallerySnapshot: string | null = null;
  try {
    gallerySnapshot = window.localStorage.getItem(GALLERY_STORE_KEY);
  } catch {
    gallerySnapshot = null;
  }
  const next: SiteVersion = {
    id: `version-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    number: Math.max(...versions.map((version) => version.number)) + 1,
    label: label || "Content edit",
    createdAt: new Date().toISOString(),
    content: clone(content),
    galleries: gallerySnapshot,
    documents: documentsSnapshot(),
  };
  const trimmed = [...versions, next].filter(
    (_version, index, list) => index === 0 || index >= list.length - MAX_VERSIONS,
  );
  writeVersions(trimmed);
  return trimmed;
}

export function listSiteVersions(): SiteVersion[] {
  return ensureBaseline().slice().reverse();
}

export function deleteSiteVersion(versionId: string): { ok: boolean; message?: string } {
  const versions = ensureBaseline();
  const target = versions.find((version) => version.id === versionId);
  if (!target) return { ok: false, message: "That version no longer exists." };
  if (target.id === versions[0].id) {
    return { ok: false, message: "The original unedited version is kept as a safe fallback." };
  }
  if (target.id === versions[versions.length - 1].id) {
    return { ok: false, message: "The version currently in use cannot be deleted." };
  }
  writeVersions(versions.filter((version) => version.id !== versionId));
  broadcast();
  return { ok: true };
}

export function restoreSiteVersion(versionId: string): { ok: boolean; message?: string } {
  const versions = ensureBaseline();
  const target = versions.find((version) => version.id === versionId);
  if (!target) return { ok: false, message: "That version could not be found." };
  const restored = clone(target.content);
  // Never bring the misplaced home-menu Monthly Offers button back with an old version.
  restored.home.cards = (restored.home.cards ?? []).filter(
    (card) => card.id !== "home-offers" && card.href !== "/monthly-offers-and-more",
  );
  persist(restored, true, `Restored version ${target.number}`);
  if (target.galleries) {
    try {
      window.localStorage.setItem(GALLERY_STORE_KEY, target.galleries);
      window.dispatchEvent(new Event("kraviska:gallery-changed"));
    } catch {
      /* content still restores even if gallery storage is full */
    }
  }
  if (target.documents !== undefined) restoreDocumentsSnapshot(target.documents);
  return { ok: true };
}

export function currentSiteVersion(): SiteVersion | null {
  const versions = ensureBaseline();
  return versions[versions.length - 1] ?? null;
}

function persist(next: SiteContent, touch: boolean, label = "Content edit"): SiteContent {
  const stamped = touch ? { ...next, updatedAt: new Date().toISOString() } : next;
  cache = stamped;
  try {
    window.localStorage.setItem(STORE_KEY, JSON.stringify(stamped));
  } catch {
    /* live session still works */
  }
  if (touch) recordVersion(stamped, label);
  broadcast();
  return stamped;
}

/** Mutate site content. Each save becomes a restorable version. */
export function updateSiteContent(
  mutator: (draft: SiteContent) => void,
  label = "Content edit",
) {
  const draft = clone(getSiteContent());
  mutator(draft);
  persist(draft, true, label);
}

/** Gallery/background/audio uploads live outside the content tree; keep the date honest. */
export function touchSiteUpdatedAt(label = "Media update") {
  persist(clone(getSiteContent()), true, label);
}

export function resetSiteContent() {
  persist(clone(DEFAULT_SITE), true, "Reset to original site");
}

export function newId(prefix: string) {
  return id(prefix);
}

function subscribe(listener: () => void) {
  const onEvent = () => listener();
  const onStorage = (event: StorageEvent) => {
    if (event.key === STORE_KEY || event.key === VERSIONS_KEY || event.key === null) {
      cache = null;
      listener();
    }
  };
  const onMessage = () => {
    cache = null;
    listener();
  };
  window.addEventListener(EVENT, onEvent);
  window.addEventListener("storage", onStorage);
  let channel: BroadcastChannel | null = null;
  try {
    channel = new BroadcastChannel(CHANNEL_KEY);
    channel.onmessage = onMessage;
  } catch {
    channel = null;
  }
  return () => {
    window.removeEventListener(EVENT, onEvent);
    window.removeEventListener("storage", onStorage);
    channel?.close();
  };
}

export function useSiteContent(): SiteContent {
  return useSyncExternalStore(subscribe, getSiteContent, getSiteContent);
}

export function usePageContent(key: PageKey): PageContent {
  const site = useSiteContent();
  return site.pages[key];
}

export function updateLabel(key: keyof SiteLabels, value: string) {
  updateSiteContent((draft) => {
    draft.labels[key] = value;
  }, `Edited label: ${key}`);
}

export function getLabel(key: keyof SiteLabels): string {
  return getSiteContent().labels[key] ?? DEFAULT_LABELS[key];
}

export function useLabel(key: keyof SiteLabels): string {
  return useSiteContent().labels[key] ?? DEFAULT_LABELS[key];
}

export function formatEditedDate(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "Unknown";
  return date.toLocaleDateString(undefined, {
    day: "2-digit",
    month: "long",
    year: "numeric",
  });
}

export function formatEditedDateTime(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "Unknown";
  return date.toLocaleString(undefined, {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}
