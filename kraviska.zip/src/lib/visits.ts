import { useEffect, useState } from "react";

const COUNT_KEY = "kraviska.souls.count.v1";
const SESSION_KEY = "kraviska.soul.session.v1";
let countedThisLoad = false;

function readCount(): number {
  try {
    const parsed = Number(window.localStorage.getItem(COUNT_KEY));
    return Number.isFinite(parsed) && parsed > 0 ? parsed : 0;
  } catch {
    return 0;
  }
}

/**
 * A locally persisted visitor count. It counts each browser session once so
 * the page does not increment on every internal route change.
 */
export function useVisitCount(): number {
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (countedThisLoad) {
      setCount(readCount());
      return;
    }
    countedThisLoad = true;
    let next = readCount();
    let alreadyCounted = false;
    try {
      alreadyCounted = window.sessionStorage.getItem(SESSION_KEY) === "yes";
    } catch {
      alreadyCounted = false;
    }
    if (!alreadyCounted) {
      next += 1;
      try {
        window.localStorage.setItem(COUNT_KEY, String(next));
        window.sessionStorage.setItem(SESSION_KEY, "yes");
      } catch {
        /* counting is best-effort */
      }
    }
    setCount(next);
  }, []);

  return count;
}
