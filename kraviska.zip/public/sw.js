/*
 * SPA navigation fallback for static hosting.
 * Clean URLs such as /about-me are served index.html when the host would
 * otherwise return a 404 on reload. The newest index is always requested
 * first so the site opens the latest saved version.
 */
const SCOPE = new URL("./", self.registration.scope).href;

self.addEventListener("install", () => {
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener("fetch", (event) => {
  if (event.request.mode !== "navigate") return;
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return;

  event.respondWith(
    fetch(event.request, { cache: "no-store" })
      .then(async (response) => {
        if (response.status !== 404) return response;
        const fallback = await fetch(SCOPE, { cache: "no-store" });
        const html = await fallback.text();
        return new Response(html, {
          status: 200,
          headers: { "Content-Type": "text/html; charset=utf-8" },
        });
      })
      .catch(async () => {
        const fallback = await fetch(SCOPE, { cache: "no-store" });
        return fallback;
      }),
  );
});
