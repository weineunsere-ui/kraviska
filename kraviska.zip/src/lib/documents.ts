import { useEffect, useState } from "react";
import { deleteMedia, getMedia, putMedia, useMediaUrl } from "@/lib/mediaStore";

/**
 * Owner-managed document slots (Price sheets, TOC).
 * A slot holds either a viewer-ready PDF or an ordered gallery of PNG/JPEG pages.
 * Files live in IndexedDB and are reloaded for every visit.
 */

export type DocumentSlot = "price-sheets" | "toc";

export type DocumentImage = {
  key: string;
  name: string;
};

export type DocumentSlotState = {
  type: "pdf" | "images" | null;
  pdfKey: string | null;
  pdfName: string;
  images: DocumentImage[];
  updatedAt: string;
};

type DocumentStore = Record<DocumentSlot, DocumentSlotState>;

const STORE_KEY = "kraviska.documents.v1";
const LEGACY_KEY = "kraviska.documents.v0";
const EVENT = "kraviska:documents-changed";

export const DOCUMENT_SLOTS: DocumentSlot[] = ["price-sheets", "toc"];

export const DOCUMENT_META: Record<
  DocumentSlot,
  { label: string; short: string; helper: string }
> = {
  "price-sheets": {
    label: "PRICE SHEETS",
    short: "Price sheets",
    helper: "A PDF or an ordered set of image pages.",
  },
  toc: {
    label: "TOC",
    short: "Terms of care",
    helper: "A PDF or an ordered set of image pages.",
  },
};

function emptyState(): DocumentSlotState {
  return { type: null, pdfKey: null, pdfName: "", images: [], updatedAt: "" };
}

function emptyStore(): DocumentStore {
  return { "price-sheets": emptyState(), toc: emptyState() };
}

function normalise(value: unknown): DocumentSlotState {
  if (!value || typeof value !== "object") return emptyState();
  const state = value as Partial<DocumentSlotState>;
  return {
    type: state.type === "pdf" || state.type === "images" ? state.type : null,
    pdfKey: state.pdfKey ?? null,
    pdfName: state.pdfName ?? "",
    images: Array.isArray(state.images)
      ? state.images
          .filter((image) => image && image.key)
          .map((image) => ({ key: image.key, name: image.name || "Untitled page" }))
      : [],
    updatedAt: state.updatedAt ?? "",
  };
}

export function readDocumentStore(): DocumentStore {
  if (typeof window === "undefined") return emptyStore();
  try {
    const raw =
      window.localStorage.getItem(STORE_KEY) ?? window.localStorage.getItem(LEGACY_KEY);
    if (!raw) return emptyStore();
    const parsed = JSON.parse(raw) as Partial<Record<DocumentSlot, unknown>>;
    return {
      "price-sheets": normalise(parsed["price-sheets"]),
      toc: normalise(parsed.toc),
    };
  } catch {
    return emptyStore();
  }
}

function writeStore(store: DocumentStore) {
  window.localStorage.setItem(STORE_KEY, JSON.stringify(store));
  window.dispatchEvent(new Event(EVENT));
}

export function readDocumentSlot(slot: DocumentSlot): DocumentSlotState {
  return readDocumentStore()[slot];
}

function persist(slot: DocumentSlot, next: DocumentSlotState): { ok: boolean; error?: string } {
  try {
    writeStore({ ...readDocumentStore(), [slot]: next });
    return { ok: true };
  } catch {
    return { ok: false, error: "This browser could not store the document index." };
  }
}

const stamp = () => new Date().toISOString();

export async function uploadDocumentPdf(
  slot: DocumentSlot,
  file: File,
): Promise<{ ok: boolean; error?: string }> {
  const isPdf = file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf");
  if (!isPdf) return { ok: false, error: "Please choose a PDF file." };
  if (file.size > 40 * 1024 * 1024) return { ok: false, error: "That PDF is larger than 40 MB." };
  const key = `doc-${slot}-pdf-${Date.now()}`;
  try {
    await putMedia(key, file);
    const result = persist(slot, {
      type: "pdf",
      pdfKey: key,
      pdfName: file.name,
      images: [],
      updatedAt: stamp(),
    });
    if (!result.ok) {
      await deleteMedia(key);
      return result;
    }
    return { ok: true };
  } catch {
    return { ok: false, error: "That PDF could not be stored in this browser." };
  }
}

export async function uploadDocumentImages(
  slot: DocumentSlot,
  files: File[],
): Promise<{ ok: boolean; error?: string; images?: DocumentImage[] }> {
  if (files.length === 0) return { ok: false, error: "Choose at least one image." };
  const invalid = files.find(
    (file) => !["image/png", "image/jpeg", "image/jpg"].includes(file.type.toLowerCase()),
  );
  if (invalid) return { ok: false, error: `${invalid.name} is not a PNG or JPEG image.` };
  const oversized = files.find((file) => file.size > 20 * 1024 * 1024);
  if (oversized) return { ok: false, error: `${oversized.name} is larger than 20 MB.` };

  const stored: DocumentImage[] = [];
  for (let index = 0; index < files.length; index += 1) {
    const file = files[index];
    const key = `doc-${slot}-img-${Date.now()}-${index}-${Math.random().toString(36).slice(2, 5)}`;
    try {
      await putMedia(key, file);
      stored.push({ key, name: file.name });
    } catch {
      return { ok: false, error: `Could not store ${file.name} in this browser.` };
    }
  }
  const result = persist(slot, {
    type: "images",
    pdfKey: null,
    pdfName: "",
    images: stored,
    updatedAt: stamp(),
  });
  return result.ok ? { ok: true, images: stored } : result;
}

export function replaceDocumentImages(slot: DocumentSlot, images: DocumentImage[]) {
  return persist(slot, { ...readDocumentSlot(slot), images, updatedAt: stamp() });
}

export function renameDocumentImage(slot: DocumentSlot, key: string, name: string) {
  const state = readDocumentSlot(slot);
  return persist(slot, {
    ...state,
    images: state.images.map((image) => (image.key === key ? { ...image, name } : image)),
  });
}

export function removeDocumentImage(slot: DocumentSlot, key: string) {
  const state = readDocumentSlot(slot);
  return persist(slot, {
    ...state,
    images: state.images.filter((image) => image.key !== key),
    updatedAt: stamp(),
  });
}

export function clearDocumentSlot(slot: DocumentSlot) {
  return persist(slot, emptyState());
}

export function documentHasContent(state: DocumentSlotState): boolean {
  return state.type === "pdf"
    ? Boolean(state.pdfKey)
    : state.type === "images"
      ? state.images.length > 0
      : false;
}

export function documentKindLabel(state: DocumentSlotState): string {
  if (state.type === "pdf") return "PDF document";
  if (state.type === "images")
    return `${state.images.length} image page${state.images.length === 1 ? "" : "s"}`;
  return "Not uploaded yet";
}

function subscribe(listener: () => void) {
  window.addEventListener(EVENT, listener);
  window.addEventListener("storage", listener);
  return () => {
    window.removeEventListener(EVENT, listener);
    window.removeEventListener("storage", listener);
  };
}

export function useDocumentSlot(slot: DocumentSlot): DocumentSlotState {
  const [state, setState] = useState<DocumentSlotState>(() => readDocumentSlot(slot));
  useEffect(() => {
    const refresh = () => setState(readDocumentSlot(slot));
    refresh();
    return subscribe(refresh);
  }, [slot]);
  return state;
}

export function useDocumentStore(): DocumentStore {
  const [store, setStore] = useState<DocumentStore>(() => readDocumentStore());
  useEffect(() => {
    const refresh = () => setStore(readDocumentStore());
    refresh();
    return subscribe(refresh);
  }, []);
  return store;
}

export function useDocumentMediaUrl(key?: string | null): string | undefined {
  return useMediaUrl(key ?? undefined);
}

export function defaultDocumentsJson(): string {
  return JSON.stringify(emptyStore());
}

/** Used when a document slot is part of a restorable site version. */
export function documentsSnapshot(): string | null {
  try {
    return window.localStorage.getItem(STORE_KEY);
  } catch {
    return null;
  }
}

export function restoreDocumentsSnapshot(snapshot: string | null) {
  if (!snapshot) return;
  try {
    window.localStorage.setItem(STORE_KEY, snapshot);
    window.dispatchEvent(new Event(EVENT));
  } catch {
    /* content still restores even if the document index is full */
  }
}

export async function loadDocumentBlob(key: string): Promise<Blob | null> {
  try {
    return await getMedia(key);
  } catch {
    return null;
  }
}
