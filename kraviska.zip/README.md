# Kraviska — portfolio site

A charcoal-and-turquoise portfolio for **kraviska.org**, built with React, Vite and Tailwind CSS.
The production build is a single self-contained HTML file. Text content lives in `localStorage`;
uploaded media and custom sounds live in IndexedDB; the interface sound is synthesised in-browser.

## Look & feel

- **Surfaces:** near-black and very dark charcoal (`#050707` through `#1b2222`).
- **Accents only:** turquoise (`#59e3c7`), pale sea-glass (`#bffef1`) and marine blue (`#73bce6`)
  appear on text, borders, icons, hovers and small highlights — never as the page colour.
- **Backdrop:** a desaturated rain scene under a charcoal veil. It is fixed, covers the full
  viewport (including mobile dynamic viewports and ultrawide/portrait ratios) and can be replaced
  from the studio with an image, GIF or looping video.
- **Type:** Instrument Serif for display, Manrope for copy, IBM Plex Mono for labels.

## Owner access

Press **Owner** in the header. The sign-in window never displays the passphrase.

The initial studio passphrase is:

```
kraviska
```

After unlocking, open **Studio → Security** to change it. Only a digest of the new passphrase is
stored locally. If it is ever lost, remove the `kraviska.studio.pass.v2` key from this browser's
localStorage to return to the initial passphrase documented above.

**Locking:** owner mode lives in memory only. Reloading, closing the site or locking manually ends
the session immediately.

## Customization studio

The studio bar (visible only to an owner) opens a tabbed hub:

### Warning box

A dedicated tab for the content advisory shown before the site. Edit the kicker, heading, accent
character, advisory text, confirm-button label and footnote. A live preview sits beside the fields.
Only the close X and confirm button can dismiss the warning.

### Background

Upload a still image, animated GIF or looping video. Choose:

- **Fill** — cover the viewport while preserving aspect ratio
- **Fit** — show the entire file
- **Stretch** — fill without preserving aspect ratio
- **Tile** — repeat an image or GIF (video tiling is disabled)

Five presets (Original, Soft rain, Silver, Deep night, Sea glass) plus sliders for brightness,
saturation, contrast, blur and grain. The same background (and its filters) is used behind the
warning screen and the main site.

### Sound

A visual **sound window** for every interface event:

- Enter a page, leave a page, hover, click, dialog opens/closes, saved confirmation
- Select a segment of the waveform and use only that part
- Erase silences, normalise, add room noise, adjust gain, add fade-in/out
- Preview the edited take and save it as the visitor-facing sound
- Restore that event's built-in sound at any time

Default entering sound: seven slow notes rising from low to high. Leaving a page plays the same
notes high to low. Saved sounds are WAV files in IndexedDB and load automatically on the next visit.

### Versions

Every content, background, warning or gallery save appends a snapshot to the version ledger rather
than overwriting history.

- The **latest** version is marked *Latest · in use* and is always what the site loads.
- The **original unedited site** is kept as a protected fallback and can be restored with one click.
- Restoring an older version creates a new current version (nothing is destroyed by looking back).
- Older, non-current versions can be deleted. The original and current versions are protected.
- Each snapshot includes site text, warning, background settings, gallery/folder layout and the
  commission document index.
- Uploaded media files are retained when a piece is removed so an earlier version can still show
  it.

### Security

Change the studio passphrase, see whether a custom passphrase is in use, and lock the studio
immediately. The UI never reveals the passphrase.

## Media folders & pins

Art Example and Monthly Offers & More have a folder system:

- Create folders with their own names; choose whether a folder is pinned.
- Assign media to a folder while adding or editing it.
- Pin individual images/GIFs/videos to the front of the archive.
- Filter by All, Pinned, or any folder; pinned folders sort first.
- Owners can rename, pin/unpin or delete folders. Deleting a folder keeps its pieces and marks
  them unfiled.
- Images, animated GIFs and MP4/WEBM videos are supported. Videos loop inline.
- Visitors see folders and pins but all owner controls are hidden.

## Content editing

Click highlighted text anywhere on the site to edit it. Every public heading, paragraph, label,
button caption and footer line is editable while owner mode is unlocked, including:

- Brand name and `.org` mark, header status, sound/owner labels
- Hero eyebrow, heading, volume line, domain, “Choose a page”, index label
- Page titles, intros, meta labels, section labels/notes, “Back to index”, “Section”, “Est. 2021”
- All link and payment row titles/descriptions and their destination labels
- Gallery headings, notes, folder labels, pin labels, empty states and “Artist’s note”
- FAQs, collapsible sections, About panels and the Home address/domain plate
- Updates panel titles, “Last edited”, “Site steward” and “Made by Unsere”
- Warning box contents (in the Warning tab)
- Commission document titles, descriptions and upload/status labels
- Closing note and “End of page — kraviska.org”
- Footer labels, social/payment destination captions and document buttons

**Studio → Site text** lists every remaining fixed caption and button label in one place
(67 fields, grouped into six sections) for editing in bulk. Warning-specific wording lives in the
Warning box tab.

Main-menu and link rows can be added, edited or deleted in their matching style.

## Monthly Offers & More

**MONTHLY OFFERS & MORE** lives inside **Commission Information**, directly beneath the Price
Sheets and TOC document slots — it is intentionally *not* a main-menu button. The row uses the same
styled link treatment, and owners can edit its title/description or add further commission links.

The page itself is the full seasonal archive, with the same image/GIF/video uploads, named folders,
pinning, filtering, editing and background tools as Art Example. Owners see Add Image / New folder
controls; visitors see the finished archive only.

A one-time migration removes any Monthly Offers button that an earlier release mistakenly placed on
the home menu, and restores the link under Commission Information in existing saved sites.

## Sound window & built-in library

Every interface action — Enter a page, Leave a page, Hover, Click, Dialog opens, Dialog closes and
Saved confirmation — has **ten built-in sound choices**:

Original motif, Midnight glass, Deep current, Cedar hush, Paper chime, Ember glow, Frost bells,
Submerged, Sea glass and Night tide. Each choice can be auditioned with its speaker button and
selected independently per action; the choice persists like a saved sound.

The sound window supports:

- Selecting/trimming part of the waveform and keeping only that segment
- Erasing silences, normalising, gain, room noise and fades
- **Reverse**, **Reverb**, **Echo**, **Speed / pitch** (slow-down or speed-up), and
  **Warmth / muffling**
- Slow-motion shortcut, preview, save as a custom take, and remove a custom take
- Built-in choices stay available underneath custom takes; removing the custom take lets the
  selected built-in choice play for visitors.

## Commission documents (Price sheets & TOC)

The two commission document rows accept:

- A single **PDF** — a confirmation dialog previews it before saving.
- One or more **PNG/JPEG** pages — a dialog shows the images in upload order with move up/down
  and remove controls. Press OK to save in that order.

Uploads support drag-and-drop or clicking the drop area to open the device file picker. Saved
files live in IndexedDB and open from the site for every visitor of this browser. PDFs open in the
built-in viewer with download/open-in-tab; image sets open as ordered pages. Only owners see the
drop zones; visitors see an **Open document** action. Replacing or clearing a document is available
to owners only. Version snapshots include the document index.

## Updates panel

The home page ends with the **Updates** panel:

- “Number of souls that visited this site:” and a locally counted visitor total
- The latest save date, updated automatically on every change
- “Made by Unsere”

Visitor counts are stored per browser (`kraviska.souls.count.v1`) and counted once per browser
session. A site-wide count would require a counter endpoint.

## Clean URLs on static hosting

A small service worker (`public/sw.js`) is registered automatically. On static hosts that would
return a 404 for a reloaded clean URL such as `/about-me`, it serves the newest `index.html`, so the
latest saved version always opens. For first-time direct visits before the worker is installed,
configure your host’s SPA/404 fallback to `index.html`.

## Pages & clean URLs

`/`, `/links`, `/art-example`, `/commission-information`, `/monthly-offers-and-more`,
`/payment-methods`, `/about-me`, `/faqs`, `/about-page`.

The router supports the History API, hash fallbacks (`/#/links`) and sub-directory hosting.
Configure an SPA fallback to `index.html` on a static host so direct URLs resolve.

## Local data

| Data | Storage |
| --- | --- |
| Site content + warning | `localStorage` → `kraviska.site.content.v3` |
| Version ledger | `localStorage` → `kraviska.versions.v1` |
| Gallery folders & items | `localStorage` → `kraviska.galleries.v4` |
| Uploaded media, backgrounds, sounds, documents | IndexedDB → database `kraviska-studio` |
| Commission document index | `localStorage` → `kraviska.documents.v1` |
| Custom sound map | `localStorage` → `kraviska.sounds.custom.v1` |
| Passphrase digest | `localStorage` → `kraviska.studio.pass.v2` |
| Visit count | `localStorage` → `kraviska.souls.count.v1` |

> These features are a complete client-side studio. Uploaded documents, images, GIFs, videos,
> backgrounds and sounds are stored as files inside this browser (IndexedDB), not linked from an
> external drive or website, so they reload with the site and never depend on the original device
> path. Browser storage is per browser profile: to show the same uploads on a different phone or
> computer, the site must be connected to a backend/CMS and hosted media storage (replace the
> helpers in `src/lib/mediaStore.ts`, `src/lib/documents.ts`, `src/lib/gallery.ts`,
> `src/lib/siteContent.ts` and `src/lib/sound.ts`).

## Development

```bash
npm install
npm run dev
npm run build
```

The deployable artifact is `dist/index.html`. Generated artwork is stored in
`src/assets/generated/` and exported as data URIs from `src/assets/images.ts`.
