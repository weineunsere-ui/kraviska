import { useState } from "react";
import { NavLink, ROUTES, type RouteKey } from "@/lib/router";
import {
  formatEditedDate,
  newId,
  updateSiteContent,
  useSiteContent,
  type HomeCard,
} from "@/lib/siteContent";
import { useVisitCount } from "@/lib/visits";
import { Modal, ContentShell, EndNote, SectionLabel } from "@/components/ui";
import { EditableText } from "@/components/Editable";
import { EditLabel } from "@/components/EditLabel";
import {
  ArrowUpRight,
  Asterisk,
  Eye,
  Pencil,
  Plus,
  Sparkle,
  Trash,
} from "@/components/Icons";

type CardDraft = { id?: string; label: string; note: string; href: string };

const INTERNAL_ROUTES: string[] = [...ROUTES];

export function HomePage({ owner }: { owner: boolean }) {
  const site = useSiteContent();
  const visits = useVisitCount();
  const [draft, setDraft] = useState<CardDraft | null>(null);
  const [error, setError] = useState("");

  const saveHome = (patch: Partial<typeof site.home>) =>
    updateSiteContent((content) => {
      content.home = { ...content.home, ...patch };
    });

  const saveCards = (cards: HomeCard[]) => saveHome({ cards });

  const openAdd = () => {
    setError("");
    setDraft({ label: "NEW PAGE", note: "A new destination", href: "/links" });
  };

  const openEdit = (card: HomeCard) => {
    setError("");
    setDraft({ ...card });
  };

  const saveDraft = () => {
    if (!draft) return;
    if (!draft.label.trim() || !draft.href.trim()) {
      setError("A title and destination are required.");
      return;
    }
    const card: HomeCard = {
      id: draft.id ?? newId("home"),
      label: draft.label.trim(),
      note: draft.note.trim(),
      href: draft.href.trim(),
    };
    saveCards(
      draft.id
        ? site.home.cards.map((entry) => (entry.id === draft.id ? card : entry))
        : [...site.home.cards, card],
    );
    setDraft(null);
  };

  const removeCard = (id: string) => {
    saveCards(site.home.cards.filter((card) => card.id !== id));
    if (draft?.id === id) setDraft(null);
  };

  return (
    <ContentShell className="home-shell">
      <section className="hero" aria-labelledby="home-title">
        <div className="hero-eyebrow">
          <span className="hero-eyebrow-item">
            <Asterisk className="h-3.5 w-3.5 text-[var(--aqua)]" />
            <EditableText
              owner={owner}
              as="span"
              value={site.home.eyebrow}
              onChange={(value) => saveHome({ eyebrow: value })}
              label="Edit the welcome eyebrow"
              maxLength={90}
            />
          </span>
          <span className="hero-eyebrow-dot" aria-hidden="true" />
          <span className="hero-eyebrow-item">
            <span className="status-dot" aria-hidden="true" />
            <EditLabel k="status" owner={owner} />
          </span>
        </div>

        <div className="hero-title-wrap">
          <span className="hero-ornament hero-ornament-left" aria-hidden="true">
            <Sparkle className="h-full w-full" />
          </span>
          <EditableText
            owner={owner}
            as="h1"
            className="hero-title"
            value={site.home.heading}
            onChange={(value) => saveHome({ heading: value })}
            label="Edit the welcome heading"
            maxLength={60}
          />
          <span className="hero-ornament hero-ornament-right" aria-hidden="true">
            <Sparkle className="h-full w-full" />
          </span>
        </div>

        <div className="hero-rule" aria-hidden="true">
          <span />
          <Asterisk className="h-3.5 w-3.5" />
          <span />
        </div>

        <EditableText
          owner={owner}
          as="p"
          multiline
          className="hero-lead placeholder-copy"
          value={site.home.lead}
          onChange={(value) => saveHome({ lead: value })}
          label="Edit the welcome text"
          maxLength={700}
        />

        <div className="hero-meta-row">
          <EditLabel k="heroVolume" owner={owner} />
          <span className="text-[var(--aqua)]">✦</span>
          <EditLabel k="heroDomain" owner={owner} />
        </div>
      </section>

      <section className="directory" aria-labelledby="directory-title">
        <SectionLabel
          meta={
            <span className="hidden sm:inline">
              <EditLabel k="choosePage" owner={owner} /> <span className="text-[var(--cream)]">→</span>
            </span>
          }
        >
          <span id="directory-title" className="inline-flex items-center gap-1.5">
            <EditLabel k="indexPrefix" owner={owner} /> — {String(site.home.cards.length).padStart(2, "0")}
          </span>
        </SectionLabel>

        <div className="home-links">
          {site.home.cards.map((item, index) => {
            const internal = INTERNAL_ROUTES.includes(item.href);
            const content = (
              <>
                <span className="home-link-index" aria-hidden="true">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <span className="home-link-copy">
                  <span className="home-link-title">{item.label}</span>
                  <span className="home-link-note">{item.note}</span>
                </span>
                <span className="home-link-arrow" aria-hidden="true">
                  <ArrowUpRight className="h-4 w-4" />
                </span>
                <span className="home-link-sweep" aria-hidden="true" />
              </>
            );

            return (
              <div className="managed-row home-link-row" key={item.id}>
                {internal ? (
                  <NavLink
                    to={item.href as RouteKey}
                    className="home-link"
                    style={{ animationDelay: `${100 + index * 45}ms` }}
                  >
                    {content}
                  </NavLink>
                ) : (
                  <a
                    className="home-link"
                    href={item.href}
                    target={item.href.startsWith("http") ? "_blank" : undefined}
                    rel="noreferrer noopener"
                    style={{ animationDelay: `${100 + index * 45}ms` }}
                  >
                    {content}
                  </a>
                )}
                {owner && (
                  <div className="row-owner-actions" aria-label={`Manage ${item.label}`}>
                    <button
                      type="button"
                      className="row-owner-btn"
                      onClick={() => openEdit(item)}
                      aria-label={`Edit ${item.label}`}
                    >
                      <Pencil className="h-3 w-3" />
                    </button>
                    <button
                      type="button"
                      className="row-owner-btn is-danger"
                      onClick={() => removeCard(item.id)}
                      aria-label={`Delete ${item.label}`}
                    >
                      <Trash className="h-3 w-3" />
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {owner && (
          <div className="content-add-row">
            <button type="button" className="btn btn-aqua btn-add" onClick={openAdd}>
              <Plus className="h-4 w-4" />
              Add main-menu button
            </button>
            <span className="content-add-hint">Full-width, matching the existing page links.</span>
          </div>
        )}
      </section>

      <section className="updates-panel" aria-labelledby="updates-title">
        <div className="updates-eyebrow">
          <span className="mono-label">
            <EditLabel k="updatesNumber" owner={owner} />
          </span>
          <span className="updates-rule" aria-hidden="true" />
          <Asterisk className="h-3.5 w-3.5 text-[var(--aqua)]" />
        </div>
        <h2 id="updates-title" className="updates-title">
          <Eye className="updates-eye" />
          <EditableText
            owner={owner}
            as="span"
            value={site.home.soulsTitle}
            onChange={(value) => saveHome({ soulsTitle: value })}
            label="Edit the visitor counter title"
            maxLength={120}
          />
        </h2>
        <div className="souls-display" aria-label={`${visits} visits`}>
          <span className="souls-count">{visits.toLocaleString()}</span>
          <span className="souls-spark" aria-hidden="true">
            <Asterisk className="h-4 w-4" />
          </span>
        </div>
        <div className="updates-meta">
          <div>
            <span className="mono-label">
              <EditLabel k="lastEdited" owner={owner} />
            </span>
            <p>{formatEditedDate(site.updatedAt)}</p>
          </div>
          <div className="updates-made">
            <span className="mono-label">
              <EditLabel k="steward" owner={owner} />
            </span>
            <EditLabel k="author" owner={owner} as="p" />
          </div>
        </div>
      </section>

      <EndNote owner={owner} />

      <Modal
        open={Boolean(draft)}
        onClose={() => setDraft(null)}
        labelledBy="home-card-title"
        className="upload-dialog"
      >
        <div className="modal-kicker">
          <Pencil className="h-3.5 w-3.5 text-[var(--aqua)]" />
          Studio / main menu
        </div>
        <h2 id="home-card-title" className="modal-title">
          {draft?.id ? "Edit main-menu button" : "Add a main-menu button"}
        </h2>
        <p className="modal-copy">
          Buttons stretch across the full menu, just like the smaller pages&apos; link rows.
        </p>

        <label className="field-label" htmlFor="home-card-label">
          Title
        </label>
        <input
          id="home-card-label"
          className="field-input"
          value={draft?.label ?? ""}
          onChange={(event) => draft && setDraft({ ...draft, label: event.target.value })}
          maxLength={90}
          placeholder="e.g. CONTACT"
          data-autofocus
        />

        <label className="field-label mt-4" htmlFor="home-card-note">
          Small note
        </label>
        <input
          id="home-card-note"
          className="field-input"
          value={draft?.note ?? ""}
          onChange={(event) => draft && setDraft({ ...draft, note: event.target.value })}
          maxLength={120}
          placeholder="e.g. Where to reach me"
        />

        <label className="field-label mt-4" htmlFor="home-card-href">
          Destination
        </label>
        <select
          id="home-card-href"
          className="field-input"
          value={INTERNAL_ROUTES.includes(draft?.href ?? "") ? draft?.href : "custom"}
          onChange={(event) => {
            if (!draft) return;
            setDraft({
              ...draft,
              href: event.target.value === "custom" ? "https://" : event.target.value,
            });
          }}
        >
          {INTERNAL_ROUTES.map((route) => (
            <option key={route} value={route}>
              {route === "/" ? "Home" : route}
            </option>
          ))}
          <option value="custom">External / custom URL</option>
        </select>
        {!INTERNAL_ROUTES.includes(draft?.href ?? "") && (
          <input
            className="field-input mt-2"
            value={draft?.href ?? ""}
            onChange={(event) => draft && setDraft({ ...draft, href: event.target.value })}
            placeholder="https://example.com"
            aria-label="Custom destination URL"
          />
        )}

        {error && (
          <p className="field-error" role="alert">
            {error}
          </p>
        )}

        <div className="modal-actions modal-actions-split">
          {draft?.id ? (
            <button type="button" className="btn btn-danger" onClick={() => removeCard(draft.id!)}>
              <Trash className="h-3.5 w-3.5" />
              Delete button
            </button>
          ) : (
            <span className="field-hint">Updates the edit date when saved.</span>
          )}
          <span className="modal-actions-group">
            <button type="button" className="btn btn-ghost" onClick={() => setDraft(null)}>
              Cancel
            </button>
            <button type="button" className="btn btn-aqua" onClick={saveDraft}>
              Save button
            </button>
          </span>
        </div>
      </Modal>
    </ContentShell>
  );
}
