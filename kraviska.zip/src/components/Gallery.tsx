import { useEffect, useRef, useState } from "react";
import type { DragEvent } from "react";
import {
  PLACEHOLDER_TEXT,
  useGallery,
  type GalleryFolder,
  type GalleryItem,
  type GallerySection,
} from "@/lib/gallery";
import {
  prepareImageBlob,
  deleteMedia,
  describeMediaFile,
  isAnimatedImage,
  mediaLimitMessage,
  putMedia,
  useMediaUrl,
} from "@/lib/mediaStore";
import { touchSiteUpdatedAt } from "@/lib/siteContent";
import { EditLabel } from "@/components/EditLabel";
import { playSaved } from "@/lib/audio";
import { Modal, SectionLabel } from "@/components/ui";
import {
  Asterisk,
  Folder,
  FolderPlus,
  ImageIcon,
  Pencil,
  Pin,
  Plus,
  Trash,
  Upload,
  X,
} from "@/components/Icons";

type SelectedUpload = {
  blob: Blob;
  kind: "image" | "video";
  previewUrl: string;
  label: string;
};

type FolderDraft = { id?: string; name: string; pinned: boolean };

function MediaFrame({ item, owner }: { item: GalleryItem; owner: boolean }) {
  const storedUrl = useMediaUrl(item.mediaKey);
  const source = item.src ?? storedUrl;

  if (!source) {
    return (
      <div className="art-frame art-frame-loading">
        <span className="mono-label">Loading media…</span>
      </div>
    );
  }

  if (item.kind === "video") {
    return (
      <div className="art-frame">
        <video src={source} autoPlay muted loop playsInline controls preload="metadata" />
        <span className="art-frame-index">
          <span className="media-kind-dot" /> <EditLabel k="mediaVideo" owner={owner} />
        </span>
      </div>
    );
  }

  return (
    <div className="art-frame">
      <img src={source} alt={item.name} loading="lazy" />
      <span className="art-frame-index">
        <EditLabel k="mediaImage" owner={owner} />
      </span>
    </div>
  );
}

export function Gallery({ section, owner }: { section: GallerySection; owner: boolean }) {
  const {
    folders,
    items,
    addItem,
    updateItem,
    removeItem,
    addFolder,
    updateFolder,
    removeFolder,
    toggleItemPin,
    toggleFolderPin,
  } = useGallery(section);

  const [filter, setFilter] = useState<string>("all");
  const [addOpen, setAddOpen] = useState(false);
  const [addStep, setAddStep] = useState<1 | 2>(1);
  const [selected, setSelected] = useState<SelectedUpload | null>(null);
  const [draftName, setDraftName] = useState("");
  const [draftDescription, setDraftDescription] = useState(PLACEHOLDER_TEXT);
  const [draftFolder, setDraftFolder] = useState<string | "">("");
  const [draftPinned, setDraftPinned] = useState(false);
  const [addError, setAddError] = useState("");
  const [busy, setBusy] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const previewRef = useRef<string | null>(null);

  const [editing, setEditing] = useState<GalleryItem | null>(null);
  const [editName, setEditName] = useState("");
  const [editDescription, setEditDescription] = useState("");
  const [editFolder, setEditFolder] = useState<string | "">("");
  const [editPinned, setEditPinned] = useState(false);
  const [editError, setEditError] = useState("");

  const [folderDraft, setFolderDraft] = useState<FolderDraft | null>(null);
  const [folderError, setFolderError] = useState("");
  const [folderToDelete, setFolderToDelete] = useState<GalleryFolder | null>(null);

  const [deleting, setDeleting] = useState<GalleryItem | null>(null);
  const [deleteError, setDeleteError] = useState("");
  const [toast, setToast] = useState("");

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(""), 3600);
    return () => window.clearTimeout(timer);
  }, [toast]);

  useEffect(() => {
    if (filter !== "all" && filter !== "pinned" && !folders.some((folder) => folder.id === filter)) {
      setFilter("all");
    }
  }, [folders, filter]);

  useEffect(
    () => () => {
      if (previewRef.current) URL.revokeObjectURL(previewRef.current);
    },
    [],
  );

  function clearPreview() {
    if (previewRef.current) {
      URL.revokeObjectURL(previewRef.current);
      previewRef.current = null;
    }
  }

  function openAdd() {
    setAddStep(1);
    clearPreview();
    setSelected(null);
    setDraftName("");
    setDraftDescription(PLACEHOLDER_TEXT);
    setDraftFolder(filter !== "all" && filter !== "pinned" ? filter : "");
    setDraftPinned(false);
    setAddError("");
    setBusy(false);
    setDragActive(false);
    setAddOpen(true);
  }

  function closeAdd() {
    setAddOpen(false);
    setAddError("");
    clearPreview();
    setSelected(null);
  }

  async function acceptFile(file?: File) {
    if (!file) return;
    const limitError = mediaLimitMessage(file);
    if (limitError) {
      setAddError(limitError);
      return;
    }
    setBusy(true);
    setAddError("");
    try {
      const kind = describeMediaFile(file);
      const blob = kind === "image" && !isAnimatedImage(file) ? await prepareImageBlob(file) : file;
      clearPreview();
      const previewUrl = URL.createObjectURL(blob);
      previewRef.current = previewUrl;
      setSelected({ blob, kind, previewUrl, label: file.name });
      if (!draftName) {
        setDraftName(
          file.name
            .replace(/\.[^.]+$/, "")
            .replace(/[-_]+/g, " ")
            .slice(0, 80),
        );
      }
    } catch (error) {
      setAddError(error instanceof Error ? error.message : "That file could not be prepared.");
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  function handleDrop(event: DragEvent<HTMLButtonElement>) {
    event.preventDefault();
    setDragActive(false);
    void acceptFile(event.dataTransfer.files?.[0]);
  }

  async function saveNewItem() {
    if (!selected) {
      setAddStep(1);
      setAddError("Please choose an image, GIF or video before continuing.");
      return;
    }
    if (!draftName.trim()) {
      setAddError("Please give this piece a display name.");
      return;
    }
    setBusy(true);
    const mediaKey = `gallery-${section}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    try {
      await putMedia(mediaKey, selected.blob);
      const result = addItem({
        name: draftName.trim(),
        description: draftDescription.trim() || PLACEHOLDER_TEXT,
        kind: selected.kind,
        mediaKey,
        folderId: draftFolder || null,
        pinned: draftPinned,
      });
      if (!result.ok) {
        await deleteMedia(mediaKey);
        setAddError(result.message);
        return;
      }
      touchSiteUpdatedAt("Gallery media added");
      playSaved();
      closeAdd();
      setToast(
        selected.kind === "video" ? "Video added to the archive." : "Image added to the archive.",
      );
    } catch {
      setAddError("That file could not be saved to this browser's media store.");
    } finally {
      setBusy(false);
    }
  }

  function beginEditing(item: GalleryItem) {
    setEditing(item);
    setEditName(item.name);
    setEditDescription(item.description);
    setEditFolder(item.folderId ?? "");
    setEditPinned(item.pinned);
    setEditError("");
  }

  function saveEdit() {
    if (!editing) return;
    if (!editName.trim()) {
      setEditError("A display name is required.");
      return;
    }
    const result = updateItem(editing.id, {
      name: editName.trim(),
      description: editDescription.trim() || PLACEHOLDER_TEXT,
      folderId: editFolder || null,
      pinned: editPinned,
    });
    if (!result.ok) {
      setEditError(result.message);
      return;
    }
    touchSiteUpdatedAt("Gallery details updated");
    playSaved();
    setEditing(null);
    setToast("Piece details updated.");
  }

  async function confirmDelete() {
    if (!deleting) return;
    const result = removeItem(deleting.id);
    if (!result.ok) {
      setDeleteError(result.message);
      return;
    }
    // The file is deliberately retained so earlier site versions can be restored.
    touchSiteUpdatedAt("Gallery piece removed");
    setDeleting(null);
    setToast("Piece removed from the archive.");
  }

  function openFolderAdd() {
    setFolderError("");
    setFolderDraft({ name: "", pinned: false });
  }

  function openFolderEdit(folder: GalleryFolder) {
    setFolderError("");
    setFolderDraft({ id: folder.id, name: folder.name, pinned: folder.pinned });
  }

  function saveFolder() {
    if (!folderDraft) return;
    const name = folderDraft.name.trim();
    if (!name) {
      setFolderError("Give the folder a name.");
      return;
    }
    const result = folderDraft.id
      ? updateFolder(folderDraft.id, { name, pinned: folderDraft.pinned })
      : addFolder(name, folderDraft.pinned);
    if (!result.ok) {
      setFolderError(result.message);
      return;
    }
    touchSiteUpdatedAt(folderDraft.id ? "Folder updated" : "Folder created");
    playSaved();
    setToast(folderDraft.id ? "Folder updated." : "Folder created.");
    setFolderDraft(null);
  }

  function pinFolder(folder: GalleryFolder) {
    const result = toggleFolderPin(folder.id);
    if (result.ok) touchSiteUpdatedAt("Folder pin updated");
  }

  function pinItem(item: GalleryItem) {
    const result = toggleItemPin(item.id);
    if (result.ok) touchSiteUpdatedAt("Piece pin updated");
  }

  const sortedFolders = [...folders].sort(
    (a, b) => Number(b.pinned) - Number(a.pinned) || a.createdAt - b.createdAt,
  );
  const visibleItems = (() => {
    if (filter === "pinned") return items.filter((item) => item.pinned);
    if (filter !== "all") return items.filter((item) => item.folderId === filter);
    return items;
  })();
  const displayedItems = [...visibleItems].sort(
    (a, b) => Number(b.pinned) - Number(a.pinned) || a.addedAt - b.addedAt,
  );

  const countFor = (folderId: string) => items.filter((item) => item.folderId === folderId).length;

  return (
    <section className="gallery" aria-label="Media archive">
      <SectionLabel
        meta={
          <span className={owner ? "text-[var(--aqua)]" : undefined}>
            <EditLabel k={owner ? "curatorView" : "viewOnly"} owner={owner} />
          </span>
        }
      >
        <EditLabel k="selectedMedia" owner={owner} /> — {String(items.length).padStart(2, "0")}
      </SectionLabel>

      <div className="gallery-toolbar">
        <p className="gallery-note">
          <EditLabel
            k={owner ? "galleryNoteOwner" : "galleryNoteVisitor"}
            owner={owner}
            multiline
            maxLength={260}
          />
        </p>
        <div className="gallery-toolbar-actions">
          {owner && (
            <button type="button" className="btn btn-ghost btn-add" onClick={openFolderAdd}>
              <FolderPlus className="h-4 w-4" />
              New folder
            </button>
          )}
          {owner && (
            <button type="button" className="btn btn-aqua btn-add" onClick={openAdd}>
              <Plus className="h-4 w-4" />
              Add Image / Video
            </button>
          )}
        </div>
      </div>

      <div className="folder-bar" role="tablist" aria-label="Filter media">
        <button
          type="button"
          role="tab"
          aria-selected={filter === "all"}
          className={`folder-chip ${filter === "all" ? "is-active" : ""}`}
          onClick={() => setFilter("all")}
        >
          <span className="folder-chip-inner">
            <ImageIcon className="h-3.5 w-3.5" />
            <EditLabel k="allMedia" owner={owner} />
            <em>{items.length}</em>
          </span>
        </button>
        <button
          type="button"
          role="tab"
          aria-selected={filter === "pinned"}
          className={`folder-chip ${filter === "pinned" ? "is-active" : ""}`}
          onClick={() => setFilter("pinned")}
        >
          <span className="folder-chip-inner">
            <Pin className="h-3.5 w-3.5" />
            <EditLabel k="pinned" owner={owner} />
            <em>{items.filter((item) => item.pinned).length}</em>
          </span>
        </button>
        {sortedFolders.map((folder) => (
          <span
            className={`folder-chip-group ${filter === folder.id ? "is-active" : ""}`}
            key={folder.id}
          >
            <button
              type="button"
              role="tab"
              aria-selected={filter === folder.id}
              className={`folder-chip ${filter === folder.id ? "is-active" : ""}`}
              onClick={() => setFilter(folder.id)}
            >
              <span className="folder-chip-inner">
                <Folder className="h-3.5 w-3.5" />
                {folder.name}
                {folder.pinned && <Pin className="h-3 w-3 text-[var(--aqua)]" />}
                <em>{countFor(folder.id)}</em>
              </span>
            </button>
            {owner && (
              <span className="folder-chip-owner">
                <button
                  type="button"
                  className={`folder-mini ${folder.pinned ? "is-on" : ""}`}
                  onClick={() => pinFolder(folder)}
                  aria-label={`${folder.pinned ? "Unpin" : "Pin"} folder ${folder.name}`}
                  aria-pressed={folder.pinned}
                >
                  <Pin className="h-3 w-3" />
                </button>
                <button
                  type="button"
                  className="folder-mini"
                  onClick={() => openFolderEdit(folder)}
                  aria-label={`Rename folder ${folder.name}`}
                >
                  <Pencil className="h-3 w-3" />
                </button>
                <button
                  type="button"
                  className="folder-mini is-danger"
                  onClick={() => setFolderToDelete(folder)}
                  aria-label={`Delete folder ${folder.name}`}
                >
                  <Trash className="h-3 w-3" />
                </button>
              </span>
            )}
          </span>
        ))}
      </div>

      {displayedItems.length === 0 ? (
        <div className="gallery-empty">
          <div className="gallery-empty-mark">
            <ImageIcon className="h-6 w-6" />
          </div>
          <h2>
            {filter === "pinned" ? (
              <EditLabel k="nothingPinned" owner={owner} />
            ) : filter === "all" ? (
              <EditLabel k="galleryEmpty" owner={owner} />
            ) : (
              <EditLabel k="folderWaiting" owner={owner} />
            )}
          </h2>
          <p>
            <EditLabel k="emptyPlaceholder" owner={owner} />
          </p>
          {owner && (
            <button type="button" className="btn btn-aqua mt-6" onClick={openAdd}>
              <Plus className="h-4 w-4" />
              Add Image / Video
            </button>
          )}
        </div>
      ) : (
        <div className="gallery-stack">
          {displayedItems.map((item, index) => {
            const folder = folders.find((entry) => entry.id === item.folderId);
            return (
              <figure className={`art-piece ${item.pinned ? "is-pinned" : ""}`} key={item.id}>
                <div className="art-frame-shell">
                  <MediaFrame item={item} owner={owner} />
                  <div className="art-name-overlay">
                    <span className="mono-label">
                      <EditLabel
                        k={item.kind === "video" ? "mediaVideo" : "mediaImage"}
                        owner={owner}
                      />{" "}
                      · {String(index + 1).padStart(2, "0")}
                      {folder ? ` · ${folder.name}` : ""}
                    </span>
                    <h2>{item.name}</h2>
                  </div>
                  {item.pinned && (
                    <span className="item-pin-badge" title="Pinned piece" aria-label="Pinned piece">
                      <Pin className="h-3 w-3" />
                    </span>
                  )}
                </div>
                <figcaption className="art-caption">
                  <div className="min-w-0">
                    <span className="art-caption-label">
                      <EditLabel k="artistsNote" owner={owner} />
                      {folder && <span className="art-folder-tag">{folder.name}</span>}
                    </span>
                    <p>{item.description}</p>
                  </div>
                  {owner && (
                    <div className="art-piece-actions">
                      <button
                        type="button"
                        className={`icon-action ${item.pinned ? "is-pinned" : ""}`}
                        onClick={() => pinItem(item)}
                        aria-label={`${item.pinned ? "Unpin" : "Pin"} ${item.name}`}
                        aria-pressed={item.pinned}
                      >
                        <Pin className="h-3.5 w-3.5" />
                        <span>{item.pinned ? "Pinned" : "Pin"}</span>
                      </button>
                      <button
                        type="button"
                        className="icon-action"
                        onClick={() => beginEditing(item)}
                        aria-label={`Edit ${item.name}`}
                      >
                        <Pencil className="h-3.5 w-3.5" />
                        <span>Edit</span>
                      </button>
                      <button
                        type="button"
                        className="icon-action icon-action-danger"
                        onClick={() => {
                          setDeleteError("");
                          setDeleting(item);
                        }}
                        aria-label={`Delete ${item.name}`}
                      >
                        <Trash className="h-3.5 w-3.5" />
                        <span>Delete</span>
                      </button>
                    </div>
                  )}
                </figcaption>
              </figure>
            );
          })}
        </div>
      )}

      {toast && (
        <div className="toast" role="status">
          <span className="h-2 w-2 rounded-full bg-[var(--aqua)]" />
          {toast}
        </div>
      )}

      {/* Add media */}
      <Modal open={addOpen} onClose={closeAdd} labelledBy="add-image-title" className="upload-dialog">
        <div className="modal-kicker">
          <Asterisk className="h-3.5 w-3.5 text-[var(--aqua)]" />
          Studio upload · Step {addStep} of 2
        </div>
        <h2 id="add-image-title" className="modal-title">
          {addStep === 1 ? "Upload an image or video" : "Name, describe & file the piece"}
        </h2>

        {addStep === 1 ? (
          <>
            <p className="modal-copy">
              Images are optimised automatically. GIFs stay animated, and videos loop inline.
              Everything remains framed inside the page.
            </p>
            <input
              ref={fileRef}
              type="file"
              accept="image/*,video/*"
              className="sr-only"
              onChange={(event) => void acceptFile(event.target.files?.[0])}
            />
            {selected ? (
              <div className="upload-preview">
                {selected.kind === "video" ? (
                  <video src={selected.previewUrl} autoPlay muted loop playsInline controls />
                ) : (
                  <img src={selected.previewUrl} alt="Selected upload preview" />
                )}
                <div className="upload-preview-actions">
                  <span>
                    {selected.kind === "video" ? "Video ready" : "Image ready"} ·{" "}
                    {selected.kind === "video" ? "video" : "image"}
                  </span>
                  <button type="button" className="text-link" onClick={() => fileRef.current?.click()}>
                    Choose a different file
                  </button>
                </div>
              </div>
            ) : (
              <button
                type="button"
                className={`dropzone ${dragActive ? "is-dragging" : ""}`}
                onClick={() => fileRef.current?.click()}
                onDragOver={(event) => {
                  event.preventDefault();
                  setDragActive(true);
                }}
                onDragLeave={() => setDragActive(false)}
                onDrop={handleDrop}
                disabled={busy}
              >
                <span className="dropzone-icon">
                  <Upload className="h-5 w-5" />
                </span>
                <span className="dropzone-title">
                  {busy ? "Preparing your file…" : "Drop an image, GIF or video here, or browse"}
                </span>
                <span className="dropzone-hint">
                  JPG, PNG, WEBP, GIF, MP4 or WEBM · up to 40 MB video
                </span>
              </button>
            )}

            {addError && (
              <p className="field-error" role="alert">
                {addError}
              </p>
            )}

            <div className="modal-actions">
              <button type="button" className="btn btn-ghost" onClick={closeAdd}>
                Cancel
              </button>
              <button
                type="button"
                className="btn btn-aqua"
                disabled={!selected || busy}
                onClick={() => {
                  setAddError("");
                  setAddStep(2);
                }}
              >
                Continue
              </button>
            </div>
          </>
        ) : (
          <>
            <div className="describe-grid">
              <div className="describe-thumb">
                {selected?.kind === "video" ? (
                  <video src={selected.previewUrl} autoPlay muted loop playsInline />
                ) : (
                  selected && <img src={selected.previewUrl} alt="" />
                )}
              </div>
              <div className="min-w-0 flex-1">
                <label className="field-label" htmlFor="piece-name">
                  Display name
                </label>
                <input
                  id="piece-name"
                  className="field-input"
                  value={draftName}
                  onChange={(event) => setDraftName(event.target.value)}
                  placeholder="e.g. Moonmoth"
                  maxLength={80}
                  data-autofocus
                />
                <label className="field-label mt-4" htmlFor="piece-description">
                  Description / bio
                </label>
                <textarea
                  id="piece-description"
                  className="field-input field-textarea"
                  value={draftDescription}
                  onChange={(event) => setDraftDescription(event.target.value)}
                  rows={3}
                  maxLength={400}
                />
                <label className="field-label mt-4" htmlFor="piece-folder">
                  Folder
                </label>
                <select
                  id="piece-folder"
                  className="field-input"
                  value={draftFolder}
                  onChange={(event) => setDraftFolder(event.target.value)}
                >
                  <option value="">Unfiled</option>
                  {sortedFolders.map((folder) => (
                    <option key={folder.id} value={folder.id}>
                      {folder.name}
                    </option>
                  ))}
                </select>
                <label className="check-row mt-3">
                  <input
                    type="checkbox"
                    checked={draftPinned}
                    onChange={(event) => setDraftPinned(event.target.checked)}
                  />
                  <span>
                    <Pin className="h-3.5 w-3.5" />
                    Pin this piece to the front
                  </span>
                </label>
                <p className="field-hint">
                  Shown beneath the piece. Hovering the media reveals its name.
                </p>
              </div>
            </div>

            {addError && (
              <p className="field-error" role="alert">
                {addError}
              </p>
            )}

            <div className="modal-actions">
              <button type="button" className="btn btn-ghost" onClick={() => setAddStep(1)} disabled={busy}>
                Back
              </button>
              <button type="button" className="btn btn-aqua" onClick={() => void saveNewItem()} disabled={busy}>
                {busy ? "Saving…" : "OK"}
              </button>
            </div>
          </>
        )}
      </Modal>

      {/* Edit media */}
      <Modal
        open={Boolean(editing)}
        onClose={() => setEditing(null)}
        labelledBy="edit-image-title"
        className="upload-dialog"
      >
        <div className="modal-kicker">
          <Pencil className="h-3.5 w-3.5 text-[var(--aqua)]" />
          Studio edit
        </div>
        <h2 id="edit-image-title" className="modal-title">
          Edit piece details
        </h2>
        <div className="describe-grid">
          <div className="describe-thumb">{editing && <MediaFrame item={editing} owner={owner} />}</div>
          <div className="min-w-0 flex-1">
            <label className="field-label" htmlFor="edit-piece-name">
              Display name
            </label>
            <input
              id="edit-piece-name"
              className="field-input"
              value={editName}
              onChange={(event) => setEditName(event.target.value)}
              maxLength={80}
            />
            <label className="field-label mt-4" htmlFor="edit-piece-description">
              Description / bio
            </label>
            <textarea
              id="edit-piece-description"
              className="field-input field-textarea"
              value={editDescription}
              onChange={(event) => setEditDescription(event.target.value)}
              rows={3}
              maxLength={400}
            />
            <label className="field-label mt-4" htmlFor="edit-piece-folder">
              Folder
            </label>
            <select
              id="edit-piece-folder"
              className="field-input"
              value={editFolder}
              onChange={(event) => setEditFolder(event.target.value)}
            >
              <option value="">Unfiled</option>
              {sortedFolders.map((folder) => (
                <option key={folder.id} value={folder.id}>
                  {folder.name}
                </option>
              ))}
            </select>
            <label className="check-row mt-3">
              <input
                type="checkbox"
                checked={editPinned}
                onChange={(event) => setEditPinned(event.target.checked)}
              />
              <span>
                <Pin className="h-3.5 w-3.5" />
                Pinned piece
              </span>
            </label>
          </div>
        </div>
        {editError && (
          <p className="field-error" role="alert">
            {editError}
          </p>
        )}
        <div className="modal-actions">
          <button type="button" className="btn btn-ghost" onClick={() => setEditing(null)}>
            Cancel
          </button>
          <button type="button" className="btn btn-aqua" onClick={saveEdit}>
            Save changes
          </button>
        </div>
      </Modal>

      {/* Folder editor */}
      <Modal
        open={Boolean(folderDraft)}
        onClose={() => setFolderDraft(null)}
        labelledBy="folder-editor-title"
        className="confirm-dialog"
      >
        <div className="modal-kicker">
          <Folder className="h-3.5 w-3.5 text-[var(--aqua)]" />
          Studio / folders
        </div>
        <h2 id="folder-editor-title" className="modal-title">
          {folderDraft?.id ? "Edit folder" : "Create a folder"}
        </h2>
        <label className="field-label" htmlFor="folder-name">
          Folder name
        </label>
        <input
          id="folder-name"
          className="field-input"
          value={folderDraft?.name ?? ""}
          onChange={(event) => folderDraft && setFolderDraft({ ...folderDraft, name: event.target.value })}
          maxLength={60}
          placeholder="e.g. Portrait commissions"
          data-autofocus
        />
        <label className="check-row mt-4">
          <input
            type="checkbox"
            checked={folderDraft?.pinned ?? false}
            onChange={(event) =>
              folderDraft && setFolderDraft({ ...folderDraft, pinned: event.target.checked })
            }
          />
          <span>
            <Pin className="h-3.5 w-3.5" />
            Pin this folder to the front
          </span>
        </label>
        {folderError && (
          <p className="field-error" role="alert">
            {folderError}
          </p>
        )}
        <div className="modal-actions">
          <button type="button" className="btn btn-ghost" onClick={() => setFolderDraft(null)}>
            Cancel
          </button>
          <button type="button" className="btn btn-aqua" onClick={saveFolder}>
            {folderDraft?.id ? "Save folder" : "Create folder"}
          </button>
        </div>
      </Modal>

      {/* Folder delete confirmation */}
      <Modal
        open={Boolean(folderToDelete)}
        onClose={() => setFolderToDelete(null)}
        labelledBy="folder-delete-title"
        className="confirm-dialog"
      >
        <div className="owner-icon owner-icon-danger">
          <Folder className="h-5 w-5" />
        </div>
        <h2 id="folder-delete-title" className="modal-title">
          Delete this folder?
        </h2>
        <p className="modal-copy">
          <span className="text-[var(--cream)]">{folderToDelete?.name}</span> will be removed.
          Its pieces stay in the archive and become unfiled.
        </p>
        <div className="modal-actions">
          <button type="button" className="btn btn-ghost" onClick={() => setFolderToDelete(null)}>
            Cancel
          </button>
          <button
            type="button"
            className="btn btn-danger"
            onClick={() => {
              if (!folderToDelete) return;
              const result = removeFolder(folderToDelete.id);
              if (result.ok) {
                touchSiteUpdatedAt("Folder removed");
                setFolderToDelete(null);
                setToast("Folder removed. Pieces are now unfiled.");
              }
            }}
          >
            Delete folder
          </button>
        </div>
      </Modal>

      {/* Piece delete confirmation */}
      <Modal
        open={Boolean(deleting)}
        onClose={() => setDeleting(null)}
        labelledBy="delete-image-title"
        className="confirm-dialog"
      >
        <div className="owner-icon owner-icon-danger">
          <Trash className="h-5 w-5" />
        </div>
        <h2 id="delete-image-title" className="modal-title">
          Remove this piece?
        </h2>
        <p className="modal-copy">
          <span className="text-[var(--cream)]">{deleting?.name}</span> will be removed from the
          gallery. The uploaded file stays in the local archive so earlier site versions can
          still be restored.
        </p>
        {deleteError && (
          <p className="field-error" role="alert">
            {deleteError}
          </p>
        )}
        <div className="modal-actions">
          <button type="button" className="btn btn-ghost" onClick={() => setDeleting(null)}>
            <X className="h-3.5 w-3.5" />
            Cancel
          </button>
          <button type="button" className="btn btn-danger" onClick={() => void confirmDelete()}>
            Remove
          </button>
        </div>
      </Modal>
    </section>
  );
}
