import { useEffect, useRef, useState } from "react";
import { backdropImage } from "@/assets/images";
import { primeAudio } from "@/lib/audio";
import { useSiteContent } from "@/lib/siteContent";
import { useMediaUrl } from "@/lib/mediaStore";
import { AlertTriangle, Asterisk, X } from "@/components/Icons";

export function WarningGate({ onEnter }: { onEnter: () => void }) {
  const site = useSiteContent();
  const warning = site.warning;
  const backgroundUrl = useMediaUrl(site.background.mediaKey);
  const hasUpload = site.background.kind === "media" && Boolean(backgroundUrl);
  const isVideo = hasUpload && site.background.mediaType === "video";
  const { brightness, saturation, contrast, blur } = site.background.filters;
  const mediaFilter = `brightness(${brightness}) saturate(${saturation}) contrast(${contrast}) blur(${blur}px)`;
  const [leaving, setLeaving] = useState(false);
  const [gone, setGone] = useState(false);
  const dismissed = useRef(false);
  const okRef = useRef<HTMLButtonElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const timer = window.setTimeout(() => okRef.current?.focus(), 120);
    return () => {
      window.clearTimeout(timer);
      document.body.style.overflow = previousOverflow;
    };
  }, []);

  useEffect(() => {
    if (gone) return;
    const keepFocusInside = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        event.stopPropagation();
      }
      if (event.key === "Tab" && cardRef.current) {
        const controls = Array.from(
          cardRef.current.querySelectorAll<HTMLButtonElement>("button:not([disabled])"),
        );
        if (controls.length === 0) return;
        const first = controls[0];
        const last = controls[controls.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      }
    };
    window.addEventListener("keydown", keepFocusInside, true);
    return () => window.removeEventListener("keydown", keepFocusInside, true);
  }, [gone]);

  function dismiss() {
    if (dismissed.current) return;
    dismissed.current = true;
    primeAudio();
    setLeaving(true);
    onEnter();
    window.setTimeout(() => setGone(true), 560);
  }

  if (gone) return null;

  return (
    <div className={`warning-screen ${leaving ? "is-leaving" : ""}`}>
      {isVideo ? (
        <video
          className="warning-bg-media"
          src={backgroundUrl}
          autoPlay
          muted
          loop
          playsInline
          style={{ filter: mediaFilter }}
          aria-hidden="true"
        />
      ) : (
        <div
          className="warning-bg-media"
          aria-hidden="true"
          style={{
            backgroundImage: `url(${hasUpload ? backgroundUrl : backdropImage})`,
            filter: hasUpload
              ? mediaFilter
              : `brightness(${brightness * 0.68}) saturate(${saturation * 0.3}) contrast(${contrast}) blur(${blur}px)`,
          }}
        />
      )}
      <div className="warning-veil" aria-hidden="true" />
      <div className="warning-grain" aria-hidden="true" />

      <div
        ref={cardRef}
        role="alertdialog"
        aria-modal="true"
        aria-labelledby="warning-title"
        aria-describedby="warning-description"
        className="warning-card"
      >
        <div className="warning-stripes" aria-hidden="true" />

        <button type="button" className="warning-x" onClick={dismiss} aria-label="Close warning">
          <X className="h-4 w-4" />
        </button>

        <div className="warning-body">
          <div className="warning-kicker">
            <span className="warning-kicker-line" />
            <AlertTriangle className="h-3.5 w-3.5" />
            <span>{warning.kicker || "Content advisory"}</span>
            <span className="warning-kicker-line" />
          </div>

          <h1 id="warning-title" className="warning-title">
            {warning.heading || "WARNING"}
            {warning.accent && <span>{warning.accent}</span>}
          </h1>

          <p id="warning-description" className="warning-copy">
            {warning.body}
          </p>

          <div className="warning-divider" aria-hidden="true">
            <span />
            <Asterisk className="h-3.5 w-3.5" />
            <span />
          </div>

          <div className="warning-actions">
            <button ref={okRef} type="button" className="warning-ok" onClick={dismiss}>
              <span>{warning.okText || "OK"}</span>
              <span className="warning-ok-dot" aria-hidden="true" />
            </button>
          </div>

          {warning.footnote && <p className="warning-footnote">{warning.footnote}</p>}
        </div>

        <span className="warning-corner warning-corner-tl" aria-hidden="true" />
        <span className="warning-corner warning-corner-br" aria-hidden="true" />
      </div>
    </div>
  );
}
