import { useEffect, useMemo, useRef, useState } from "react";
import type { DragEvent } from "react";
import {
  DOCUMENT_META,
  DOCUMENT_SLOTS,
  clearDocumentSlot,
  documentHasContent,
  uploadDocumentImages,
  uploadDocumentPdf,
  useDocumentStore,
  type DocumentImage,
  type DocumentSlot,
} from "@/lib/documents";
import {
  newId,
  updateSiteContent,
  useLabel,
  usePageContent,
  type LinkIcon,
  type PageLink,
} from "@/lib/siteContent";
import { NavLink } from "@/lib/router";
import { LINK_ICONS } from "@/components/ContentLinks";
import { EditLabel } from "@/components/EditLabel";
import { touchSiteUpdatedAt } from "@/lib/siteContent";
import { playSaved } from "@/lib/audio";
import { EditableText } from "@/components/Editable";
import { Modal } from "@/components/ui";
import {
  ArrowDown,
  ArrowUp,
  ArrowUpRight,
  Asterisk,
  Download,
  FileText,
  ImageIcon,
  Pencil,
  Plus,
  Trash,
  Upload,
  X,
} from "@/components/Icons";

type FileRow = DocumentImage & { file: File; url: string };

const isPdf = (file: File) =>
  file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf");
const isImage = (file: File) =>
  ["image/png", "image/jpeg", "image/jpg"].includes(file.type.toLowerCase()) ||
  /\.(png|jpe?g)$/i.test(file.name);

export function DocumentLinks({
  owner,
  onOpen,
}: {
  owner: boolean;
  onOpen: (slot: DocumentSlot, title: string) => void;
}) {
  const page = usePageContent("commission");
  const documents = useDocumentStore();
  const inputs = useRef<Record<string, HTMLInputElement | null>>({});
  const [dragging, setDragging] = useState<DocumentSlot | null>(null);
  const [error, setError] = useState<{ slot: DocumentSlot; message: string } | null>(null);
  const [pdfDraft, setPdfDraft] = useState<{ slot: DocumentSlot; file: File; url: string } | null>(null);
  const [imageDraft, setImageDraft] = useState<{ slot: DocumentSlot; rows: FileRow[] } | null>(null);
  const [busy, setBusy] = useState(false);
  const [confirmClear, setConfirmClear] = useState<DocumentSlot | null>(null);
  const [extraDraft, setExtraDraft] = useState<{
    id?: string;
    label: string;
    description: string;
    href: string;
    icon: LinkIcon;
  } | null>(null);
  const [extraError, setExtraError] = useState("");
  const [toast, setToast] = useState("");

  const notUploaded = useLabel("documentEmptyTitle");
  const pdfKind = useLabel("documentPdf");
  const pagesKind = useLabel("documentPages");
  const labels = {
    dropTitle: useLabel("documentDropTitle"),
    dropHere: useLabel("documentDropHere"),
    dropHint: useLabel("documentDropHint"),
    replace: useLabel("documentReplace"),
    clear: useLabel("documentClear"),
    open: useLabel("documentOpen"),
    save: useLabel("documentSave"),
    cancel: useLabel("documentCancel"),
    reorder: useLabel("documentReorder"),
    reorderHelp: useLabel("documentReorderHelp"),
    confirmPdf: useLabel("documentConfirmPdf"),
    confirmPdfHelp: useLabel("documentConfirmPdfHelp"),
    ownerOnly: useLabel("documentUploadOwnerOnly"),
    pages: useLabel("documentPages"),
    pdf: useLabel("documentPdf"),
    linkPage: useLabel("linkPage"),
    linkExternal: useLabel("linkExternal"),
  };

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(""), 3600);
    return () => window.clearTimeout(timer);
  }, [toast]);

  useEffect(
    () => () => {
      if (pdfDraft) URL.revokeObjectURL(pdfDraft.url);
      imageDraft?.rows.forEach((row) => URL.revokeObjectURL(row.url));
    },
    // Revoke when the drafts change/unmount; refs are intentionally omitted.
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [],
  );

  const linkFor = (slot: DocumentSlot) => {
    const legacyHref = `pdf:${slot}`;
    return (
      page.links.find((link) => link.href === legacyHref) ??
      page.links.find((link) => link.id === `doc-${slot}`) ?? {
        id: `doc-${slot}`,
        label: DOCUMENT_META[slot].label,
        description: "",
        href: legacyHref,
        icon: "file" as const,
      }
    );
  };

  const updateLink = (slot: DocumentSlot, patch: { label?: string; description?: string }) => {
    const target = linkFor(slot);
    const exists = page.links.some((link) => link.id === target.id);
    updateSiteContent((site) => {
      site.pages.commission.links = exists
        ? site.pages.commission.links.map((link) =>
            link.id === target.id ? { ...link, ...patch } : link,
          )
        : [...site.pages.commission.links, { ...target, ...patch }];
    }, "Commission document link updated");
  };

  function handleSelection(slot: DocumentSlot, files: FileList | File[] | null) {
    if (!files) return;
    const list = Array.from(files);
    setError(null);
    if (list.length === 0) return;
    const pdfs = list.filter(isPdf);
    const images = list.filter(isImage);
    if (pdfs.length + images.length !== list.length) {
      setError({ slot, message: "Use a PDF, PNG or JPEG file." });
      return;
    }
    if (pdfs.length > 1 || (pdfs.length === 1 && images.length > 0)) {
      setError({
        slot,
        message: "Add one PDF on its own, or choose one or more PNG/JPEG pages together.",
      });
      return;
    }
    if (pdfs.length === 1) {
      setPdfDraft({ slot, file: pdfs[0], url: URL.createObjectURL(pdfs[0]) });
      return;
    }
    setImageDraft({
      slot,
      rows: images.map((file, index) => ({
        key: `draft-${index}`,
        name: file.name,
        file,
        url: URL.createObjectURL(file),
      })),
    });
  }

  function onDrop(event: DragEvent<HTMLElement>, slot: DocumentSlot) {
    event.preventDefault();
    setDragging(null);
    handleSelection(slot, event.dataTransfer.files);
  }

  async function savePdf() {
    if (!pdfDraft) return;
    setBusy(true);
    const result = await uploadDocumentPdf(pdfDraft.slot, pdfDraft.file);
    setBusy(false);
    if (!result.ok) {
      setError({ slot: pdfDraft.slot, message: result.error ?? "Could not store that PDF." });
      return;
    }
    URL.revokeObjectURL(pdfDraft.url);
    setPdfDraft(null);
    touchSiteUpdatedAt("Commission PDF updated");
    playSaved();
    setToast("PDF saved. It now opens from the site.");
  }

  function moveRow(index: number, direction: -1 | 1) {
    setImageDraft((current) => {
      if (!current) return current;
      const next = [...current.rows];
      const target = index + direction;
      if (target < 0 || target >= next.length) return current;
      [next[index], next[target]] = [next[target], next[index]];
      return { ...current, rows: next };
    });
  }

  function removeRow(index: number) {
    setImageDraft((current) => {
      if (!current) return current;
      URL.revokeObjectURL(current.rows[index].url);
      return { ...current, rows: current.rows.filter((_, rowIndex) => rowIndex !== index) };
    });
  }

  async function saveImages() {
    if (!imageDraft) return;
    if (imageDraft.rows.length === 0) {
      setError({ slot: imageDraft.slot, message: "Keep at least one image page." });
      return;
    }
    setBusy(true);
    const result = await uploadDocumentImages(
      imageDraft.slot,
      imageDraft.rows.map((row) => row.file),
    );
    setBusy(false);
    if (!result.ok) {
      setError({ slot: imageDraft.slot, message: result.error ?? "Could not store those images." });
      return;
    }
    imageDraft.rows.forEach((row) => URL.revokeObjectURL(row.url));
    setImageDraft(null);
    touchSiteUpdatedAt("Commission image pages updated");
    playSaved();
    setToast(`${result.images?.length ?? 0} page${result.images?.length === 1 ? "" : "s"} saved in order.`);
  }

  function statusLabel(state: (typeof documents)[DocumentSlot]) {
    if (state.type === "pdf") return pdfKind;
    if (state.type === "images") return `${state.images.length} ${pagesKind}`;
    return notUploaded;
  }

  const extras = page.links.filter(
    (link) =>
      link.id !== "doc-prices" &&
      link.id !== "doc-toc" &&
      link.href !== "pdf:price-sheets" &&
      link.href !== "pdf:toc",
  );

  function openExtra(link?: PageLink) {
    setExtraError("");
    setExtraDraft(
      link
        ? { ...link }
        : {
            label: "NEW LINK",
            description: "this is a placeholder text that will be changed later.",
            href: "/monthly-offers-and-more",
            icon: "sparkle",
          },
    );
  }

  function saveExtra() {
    if (!extraDraft) return;
    if (!extraDraft.label.trim() || !extraDraft.href.trim()) {
      setExtraError("A title and destination are required.");
      return;
    }
    const clean: PageLink = {
      id: extraDraft.id ?? newId("commission-link"),
      label: extraDraft.label.trim(),
      description: extraDraft.description.trim(),
      href: extraDraft.href.trim(),
      icon: extraDraft.icon,
    };
    updateSiteContent((site) => {
      site.pages.commission.links = extraDraft.id
        ? site.pages.commission.links.map((link) => (link.id === extraDraft.id ? clean : link))
        : [...site.pages.commission.links, clean];
    }, "Commission extra link updated");
    playSaved();
    setExtraDraft(null);
    setToast("Commission link saved.");
  }

  function removeExtra(id: string) {
    updateSiteContent((site) => {
      site.pages.commission.links = site.pages.commission.links.filter((link) => link.id !== id);
    }, "Commission extra link removed");
    setToast("Commission link removed.");
  }

  function clear(slot: DocumentSlot) {
    clearDocumentSlot(slot);
    touchSiteUpdatedAt("Commission document cleared");
    setConfirmClear(null);
    setToast("Document cleared.");
  }

  const rows = useMemo(
    () =>
      DOCUMENT_SLOTS.map((slot) => {
        const state = documents[slot];
        const link = linkFor(slot);
        return { slot, state, link };
      }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [documents, page.links],
  );

  return (
    <section className="page-section" aria-label="Commission documents">
      <div className="section-label">
        <span className="flex items-center gap-2.5">
          <Asterisk className="h-3.5 w-3.5 text-[var(--aqua)]" />
          <EditableText
            owner={owner}
            as="span"
            value={page.sectionLabel}
            onChange={(value) =>
              updateSiteContent((site) => {
                site.pages.commission.sectionLabel = value;
              }, "Commission section label updated")
            }
            label="Edit commission section label"
          />
        </span>
        <span className="section-meta">
          <EditableText
            owner={owner}
            as="span"
            value={page.sectionMeta}
            onChange={(value) =>
              updateSiteContent((site) => {
                site.pages.commission.sectionMeta = value;
              }, "Commission section note updated")
            }
            label="Edit commission section note"
          />
        </span>
      </div>

      <div className="document-list">
        {rows.map(({ slot, state, link }) => {
          const hasContent = documentHasContent(state);
          return (
            <div className={`document-card ${hasContent ? "has-file" : ""}`} key={slot}>
              <div className="managed-row">
                <div
                  className={`social-link doc-link document-row ${hasContent ? "is-filled" : ""}`}
                  role="group"
                  aria-label={`${link.label} document`}
                >
                  <span className="social-glyph" aria-hidden="true">
                    {state.type === "images" ? (
                      <ImageIcon className="h-6 w-6" />
                    ) : (
                      <FileText className="h-6 w-6" />
                    )}
                  </span>
                  <span className="social-body">
                    <EditableText
                      owner={owner}
                      as="span"
                      className="social-name"
                      value={link.label}
                      onChange={(value) => updateLink(slot, { label: value })}
                      label="Edit document title"
                      maxLength={80}
                    />
                    <EditableText
                      owner={owner}
                      as="span"
                      className="social-desc"
                      value={link.description}
                      onChange={(value) => updateLink(slot, { description: value })}
                      label="Edit document description"
                      maxLength={180}
                    />
                  </span>
                  <span className="social-end">
                    <span className={`doc-status ${hasContent ? "is-ready" : ""}`}>
                      {hasContent ? statusLabel(state) : notUploaded}
                    </span>
                    <button
                      type="button"
                      className="social-arrow"
                      onClick={() => onOpen(slot, link.label)}
                      aria-label={`Open ${link.label}`}
                    >
                      <ArrowUpRight className="h-4 w-4" />
                    </button>
                  </span>
                </div>
              </div>

              {owner ? (
                <div className="document-owner">
                  <button
                    type="button"
                    className={`document-drop ${dragging === slot ? "is-dragging" : ""}`}
                    onClick={() => inputs.current[slot]?.click()}
                    onDragOver={(event) => {
                      event.preventDefault();
                      setDragging(slot);
                    }}
                    onDragLeave={() => setDragging(null)}
                    onDrop={(event) => onDrop(event, slot)}
                  >
                    <span className="document-drop-icon">
                      {dragging === slot ? <Download className="h-4 w-4" /> : <Upload className="h-4 w-4" />}
                    </span>
                    <span className="document-drop-copy">
                      <strong>{dragging === slot ? labels.dropHere : labels.dropTitle}</strong>
                      <small>{labels.dropHint}</small>
                    </span>
                    <span className="document-drop-plus" aria-hidden="true">
                      <Plus className="h-4 w-4" />
                    </span>
                  </button>
                  <input
                    ref={(node) => {
                      inputs.current[slot] = node;
                    }}
                    className="sr-only"
                    type="file"
                    accept="application/pdf,image/png,image/jpeg"
                    multiple
                    onChange={(event) => {
                      handleSelection(slot, event.target.files);
                      event.target.value = "";
                    }}
                  />
                  <div className="document-owner-actions">
                    <span className="document-owner-state">
                      {hasContent ? (
                        <>
                          <span className="status-dot" aria-hidden="true" />
                          {state.type === "pdf" ? state.pdfName : `${state.images.length} ${labels.pages}`}
                        </>
                      ) : (
                        labels.ownerOnly
                      )}
                    </span>
                    {hasContent && (
                      <>
                        <button
                          type="button"
                          className="btn btn-ghost btn-compact"
                          onClick={() => inputs.current[slot]?.click()}
                        >
                          {labels.replace}
                        </button>
                        <button
                          type="button"
                          className="btn btn-ghost btn-compact"
                          onClick={() => setConfirmClear(slot)}
                        >
                          <Trash className="h-3 w-3" />
                          {labels.clear}
                        </button>
                      </>
                    )}
                  </div>
                  {error?.slot === slot && (
                    <p className="field-error" role="alert">
                      {error.message}
                    </p>
                  )}
                </div>
              ) : (
                <div className="document-visitor-row">
                  <span className={`doc-status ${hasContent ? "is-ready" : ""}`}>
                    {hasContent ? statusLabel(state) : notUploaded}
                  </span>
                  <button
                    type="button"
                    className="btn btn-ghost btn-compact"
                    onClick={() => onOpen(slot, link.label)}
                  >
                    {labels.open}
                    <ArrowUpRight className="h-3 w-3" />
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="commission-extras">
        <div className="section-label">
          <span className="flex items-center gap-2.5">
            <Asterisk className="h-3.5 w-3.5 text-[var(--aqua)]" />
            <EditLabel k="commissionExtras" owner={owner} />
          </span>
          <span className="section-meta">
            <EditLabel k="commissionExtrasNote" owner={owner} />
          </span>
        </div>

        {extras.length === 0 ? (
          <p className="commission-extras-empty">
            <EditLabel k="emptyPlaceholder" owner={owner} />
          </p>
        ) : (
          <div className="link-stack">
            {extras.map((link, index) => {
              const Glyph = LINK_ICONS[link.icon] ?? ArrowUpRight;
              const internal = link.href.startsWith("/");
              const body = (
                <>
                  <span className="social-index" aria-hidden="true">
                    {String(index + 1).padStart(2, "0")}
                  </span>
                  <span className="social-glyph" aria-hidden="true">
                    <Glyph className="h-6 w-6" />
                  </span>
                  <span className="social-body">
                    <EditableText
                      owner={owner}
                      as="span"
                      className="social-name"
                      value={link.label}
                      onChange={(value) =>
                        updateSiteContent((site) => {
                          site.pages.commission.links = site.pages.commission.links.map((entry) =>
                            entry.id === link.id ? { ...entry, label: value } : entry,
                          );
                        }, "Commission extra link renamed")
                      }
                      label="Edit commission link title"
                      maxLength={90}
                    />
                    <EditableText
                      owner={owner}
                      as="span"
                      className="social-desc"
                      value={link.description}
                      onChange={(value) =>
                        updateSiteContent((site) => {
                          site.pages.commission.links = site.pages.commission.links.map((entry) =>
                            entry.id === link.id ? { ...entry, description: value } : entry,
                          );
                        }, "Commission extra link description updated")
                      }
                      label="Edit commission link description"
                      maxLength={180}
                    />
                  </span>
                  <span className="social-end">
                    <span className="social-handle" aria-hidden="true">
                      {internal ? labels.linkPage : labels.linkExternal}
                    </span>
                    <span className="social-arrow" aria-hidden="true">
                      <ArrowUpRight className="h-4 w-4" />
                    </span>
                  </span>
                </>
              );

              return (
                <div className="managed-row" key={link.id}>
                  {internal ? (
                    <NavLink to={link.href as "/"} className="social-link doc-link">
                      {body}
                    </NavLink>
                  ) : (
                    <a
                      className="social-link doc-link"
                      href={link.href}
                      target="_blank"
                      rel="noreferrer noopener"
                    >
                      {body}
                    </a>
                  )}
                  {owner && (
                    <div className="row-owner-actions" aria-label={`Manage ${link.label}`}>
                      <button
                        type="button"
                        className="row-owner-btn"
                        onClick={() => openExtra(link)}
                        aria-label={`Edit ${link.label}`}
                      >
                        <Pencil className="h-3 w-3" />
                      </button>
                      <button
                        type="button"
                        className="row-owner-btn is-danger"
                        onClick={() => removeExtra(link.id)}
                        aria-label={`Delete ${link.label}`}
                      >
                        <Trash className="h-3 w-3" />
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {owner && (
          <div className="content-add-row">
            <button type="button" className="btn btn-aqua btn-add" onClick={() => openExtra()}>
              <Plus className="h-4 w-4" />
              Add commission link
            </button>
            <span className="content-add-hint">
              Monthly Offers &amp; More belongs here, not on the main page.
            </span>
          </div>
        )}
      </div>

      {toast && (
        <div className="toast" role="status">
          <span className="h-2 w-2 rounded-full bg-[var(--aqua)]" />
          {toast}
        </div>
      )}

      {/* PDF confirmation */}
      <Modal
        open={Boolean(pdfDraft)}
        onClose={() => {
          if (pdfDraft) URL.revokeObjectURL(pdfDraft.url);
          setPdfDraft(null);
        }}
        labelledBy="pdf-confirm-title"
        className="document-dialog"
      >
        <div className="modal-kicker">
          <FileText className="h-3.5 w-3.5 text-[var(--aqua)]" />
          Studio / document upload
        </div>
        <h2 id="pdf-confirm-title" className="modal-title">
          {labels.confirmPdf}
        </h2>
        <p className="modal-copy">{labels.confirmPdfHelp}</p>
        <div className="document-pdf-preview">
          {pdfDraft && <iframe src={pdfDraft.url} title="PDF preview" />}
        </div>
        <p className="document-file-row">
          <FileText className="h-3.5 w-3.5" />
          {pdfDraft?.file.name}
          <span>{Math.max(1, Math.round((pdfDraft?.file.size ?? 0) / 1024))} KB</span>
        </p>
        <div className="modal-actions">
          <button
            type="button"
            className="btn btn-ghost"
            onClick={() => {
              if (pdfDraft) URL.revokeObjectURL(pdfDraft.url);
              setPdfDraft(null);
            }}
          >
            {labels.cancel}
          </button>
          <button type="button" className="btn btn-aqua" onClick={() => void savePdf()} disabled={busy}>
            {busy ? "Saving…" : labels.save}
          </button>
        </div>
      </Modal>

      {/* Image reorder / confirmation */}
      <Modal
        open={Boolean(imageDraft)}
        onClose={() => {
          imageDraft?.rows.forEach((row) => URL.revokeObjectURL(row.url));
          setImageDraft(null);
        }}
        labelledBy="image-order-title"
        className="document-dialog"
      >
        <div className="modal-kicker">
          <ImageIcon className="h-3.5 w-3.5 text-[var(--aqua)]" />
          Studio / image pages · {imageDraft?.rows.length ?? 0}
        </div>
        <h2 id="image-order-title" className="modal-title">
          {labels.reorder}
        </h2>
        <p className="modal-copy">{labels.reorderHelp}</p>
        <ol className="document-order-list">
          {imageDraft?.rows.map((row, index) => (
            <li className="document-order-row" key={row.key}>
              <span className="document-order-number mono-label">
                {String(index + 1).padStart(2, "0")}
              </span>
              <span className="document-order-thumb">
                <img src={row.url} alt="" />
              </span>
              <span className="document-order-name" title={row.name}>
                {row.name}
              </span>
              <span className="document-order-actions">
                <button
                  type="button"
                  className="row-owner-btn"
                  onClick={() => moveRow(index, -1)}
                  disabled={index === 0}
                  aria-label={`Move ${row.name} earlier`}
                >
                  <ArrowUp className="h-3 w-3" />
                </button>
                <button
                  type="button"
                  className="row-owner-btn"
                  onClick={() => moveRow(index, 1)}
                  disabled={index === (imageDraft?.rows.length ?? 1) - 1}
                  aria-label={`Move ${row.name} later`}
                >
                  <ArrowDown className="h-3 w-3" />
                </button>
                <button
                  type="button"
                  className="row-owner-btn is-danger"
                  onClick={() => removeRow(index)}
                  aria-label={`Remove ${row.name}`}
                >
                  <X className="h-3 w-3" />
                </button>
              </span>
            </li>
          ))}
        </ol>
        <div className="modal-actions modal-actions-split">
          <button
            type="button"
            className="btn btn-ghost"
            onClick={() => {
              if (!imageDraft) return;
              const input = inputs.current[imageDraft.slot];
              imageDraft.rows.forEach((row) => URL.revokeObjectURL(row.url));
              setImageDraft(null);
              input?.click();
            }}
          >
            <Plus className="h-3 w-3" />
            Add more images
          </button>
          <span className="modal-actions-group">
            <button
              type="button"
              className="btn btn-ghost"
              onClick={() => {
                imageDraft?.rows.forEach((row) => URL.revokeObjectURL(row.url));
                setImageDraft(null);
              }}
            >
              {labels.cancel}
            </button>
            <button type="button" className="btn btn-aqua" onClick={() => void saveImages()} disabled={busy}>
              {busy ? "Saving…" : "OK"}
            </button>
          </span>
        </div>
      </Modal>

      {/* Extra commission link editor */}
      <Modal
        open={Boolean(extraDraft)}
        onClose={() => setExtraDraft(null)}
        labelledBy="extra-link-title"
        className="upload-dialog"
      >
        <div className="modal-kicker">
          <Pencil className="h-3.5 w-3.5 text-[var(--aqua)]" />
          Studio / commission links
        </div>
        <h2 id="extra-link-title" className="modal-title">
          {extraDraft?.id ? "Edit commission link" : "Add a commission link"}
        </h2>
        <p className="modal-copy">
          These rows appear beneath Price Sheets and TOC. Use <code>/monthly-offers-and-more</code>{" "}
          for the seasonal archive, or a full address for an external page.
        </p>
        <label className="field-label" htmlFor="extra-link-label">
          Title
        </label>
        <input
          id="extra-link-label"
          className="field-input"
          value={extraDraft?.label ?? ""}
          onChange={(event) =>
            extraDraft && setExtraDraft({ ...extraDraft, label: event.target.value })
          }
          maxLength={90}
          data-autofocus
        />
        <label className="field-label mt-4" htmlFor="extra-link-description">
          Description
        </label>
        <textarea
          id="extra-link-description"
          className="field-input field-textarea"
          rows={3}
          maxLength={200}
          value={extraDraft?.description ?? ""}
          onChange={(event) =>
            extraDraft && setExtraDraft({ ...extraDraft, description: event.target.value })
          }
        />
        <div className="field-split">
          <div>
            <label className="field-label" htmlFor="extra-link-href">
              Destination
            </label>
            <input
              id="extra-link-href"
              className="field-input"
              value={extraDraft?.href ?? ""}
              onChange={(event) =>
                extraDraft && setExtraDraft({ ...extraDraft, href: event.target.value })
              }
              placeholder="/monthly-offers-and-more"
              maxLength={400}
            />
          </div>
          <div>
            <label className="field-label" htmlFor="extra-link-icon">
              Icon
            </label>
            <select
              id="extra-link-icon"
              className="field-input"
              value={extraDraft?.icon ?? "sparkle"}
              onChange={(event) =>
                extraDraft &&
                setExtraDraft({ ...extraDraft, icon: event.target.value as LinkIcon })
              }
            >
              {(Object.keys(LINK_ICONS) as LinkIcon[]).map((icon) => (
                <option key={icon} value={icon}>
                  {icon}
                </option>
              ))}
            </select>
          </div>
        </div>
        {extraError && (
          <p className="field-error" role="alert">
            {extraError}
          </p>
        )}
        <div className="modal-actions modal-actions-split">
          {extraDraft?.id ? (
            <button
              type="button"
              className="btn btn-danger"
              onClick={() => {
                removeExtra(extraDraft.id!);
                setExtraDraft(null);
              }}
            >
              <Trash className="h-3.5 w-3.5" />
              Delete link
            </button>
          ) : (
            <span className="field-hint">Saved to this browser immediately.</span>
          )}
          <span className="modal-actions-group">
            <button type="button" className="btn btn-ghost" onClick={() => setExtraDraft(null)}>
              Cancel
            </button>
            <button type="button" className="btn btn-aqua" onClick={saveExtra}>
              Save link
            </button>
          </span>
        </div>
      </Modal>

      {/* Clear confirmation */}
      <Modal
        open={Boolean(confirmClear)}
        onClose={() => setConfirmClear(null)}
        labelledBy="clear-document-title"
        className="confirm-dialog"
      >
        <span className="owner-icon owner-icon-danger">
          <Trash className="h-5 w-5" />
        </span>
        <h2 id="clear-document-title" className="modal-title">
          Clear this document?
        </h2>
        <p className="modal-copy">
          The current upload will no longer open from the commission page. You can add a new file at
          any time.
        </p>
        <div className="modal-actions">
          <button type="button" className="btn btn-ghost" onClick={() => setConfirmClear(null)}>
            {labels.cancel}
          </button>
          <button
            type="button"
            className="btn btn-danger"
            onClick={() => confirmClear && clear(confirmClear)}
          >
            <Trash className="h-3.5 w-3.5" />
            {labels.clear}
          </button>
        </div>
      </Modal>
    </section>
  );
}
