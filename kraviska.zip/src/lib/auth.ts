/**
 * Studio passphrase handling.
 *
 * The passphrase is never rendered in the interface. The default is only
 * documented in the project README so a new owner can sign in once, then
 * change it from Studio → Security. Only a digest is stored locally.
 */

const PASS_KEY = "kraviska.studio.pass.v2";
const DEFAULT_PASSPHRASE = "kraviska";

function fallbackDigest(value: string): string {
  let hash = 0x811c9dc5;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 0x01000193);
  }
  return `fallback-${(hash >>> 0).toString(16)}`;
}

async function digest(value: string): Promise<string> {
  try {
    if (typeof crypto !== "undefined" && crypto.subtle) {
      const bytes = new TextEncoder().encode(value);
      const hashed = await crypto.subtle.digest("SHA-256", bytes);
      return Array.from(new Uint8Array(hashed))
        .map((byte) => byte.toString(16).padStart(2, "0"))
        .join("");
    }
  } catch {
    /* fall through to the deterministic local digest */
  }
  return fallbackDigest(value);
}

async function currentDigest(): Promise<string> {
  try {
    const stored = window.localStorage.getItem(PASS_KEY);
    if (stored) return stored;
  } catch {
    /* storage can be unavailable */
  }
  return digest(DEFAULT_PASSPHRASE);
}

export async function verifyPassphrase(value: string): Promise<boolean> {
  const candidate = value.trim();
  if (!candidate) return false;
  const expected = await currentDigest();
  const actual = await digest(candidate);
  return actual === expected;
}

export function hasCustomPassphrase(): boolean {
  try {
    return Boolean(window.localStorage.getItem(PASS_KEY));
  } catch {
    return false;
  }
}

export async function changePassphrase(
  current: string,
  next: string,
): Promise<{ ok: boolean; error?: string }> {
  if (!(await verifyPassphrase(current))) {
    return { ok: false, error: "The current passphrase is not correct." };
  }
  const clean = next.trim();
  if (clean.length < 6) {
    return { ok: false, error: "Choose a passphrase with at least 6 characters." };
  }
  if (clean.toLowerCase() === DEFAULT_PASSPHRASE) {
    return {
      ok: false,
      error: "Choose a passphrase different from the initial studio passphrase.",
    };
  }
  try {
    window.localStorage.setItem(PASS_KEY, await digest(clean));
    return { ok: true };
  } catch {
    return { ok: false, error: "This browser could not store the new passphrase." };
  }
}

export const STUDIO_DEFAULT_PASSPHRASE_HINT =
  "The initial passphrase is documented in the project README.";
