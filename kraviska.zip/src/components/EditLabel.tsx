import type { ElementType } from "react";
import { updateLabel, useLabel, type SiteLabels } from "@/lib/siteContent";
import { EditableText } from "@/components/Editable";

/**
 * A small convenience wrapper so every visible fixed label on the site can be
 * edited by the owner while remaining plain text for visitors.
 */
export function EditLabel({
  k,
  owner,
  as = "span",
  className,
  multiline = false,
  maxLength = 180,
}: {
  k: keyof SiteLabels;
  owner: boolean;
  as?: ElementType;
  className?: string;
  multiline?: boolean;
  maxLength?: number;
}) {
  const value = useLabel(k);
  return (
    <EditableText
      owner={owner}
      as={as}
      className={className}
      multiline={multiline}
      maxLength={maxLength}
      value={value}
      onChange={(next) => updateLabel(k, next)}
      label={`Edit “${value}”`}
    />
  );
}
