import { useEffect, useState } from "react";
import type { FormEvent } from "react";
import { Modal } from "@/components/ui";
import { verifyPassphrase } from "@/lib/auth";
import { Asterisk, History, ImageIcon, Lock, Pencil, Shield, Sliders, SoundOn, Unlock } from "@/components/Icons";
import type { StudioTab } from "@/components/CustomizeStudio";

export function OwnerAccess({
  open,
  owner,
  onClose,
  onChange,
  onOpenBackground,
  onOpenCustomize,
}: {
  open: boolean;
  owner: boolean;
  onClose: () => void;
  onChange: (unlocked: boolean) => void;
  onOpenBackground: () => void;
  onOpenCustomize: (tab: StudioTab) => void;
}) {
  const [passphrase, setPassphrase] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (open) {
      setPassphrase("");
      setError("");
      setBusy(false);
    }
  }, [open]);

  async function unlock(event: FormEvent) {
    event.preventDefault();
    setError("");
    setBusy(true);
    const valid = await verifyPassphrase(passphrase);
    setBusy(false);
    if (!valid) {
      setError("That passphrase does not match the studio key.");
      return;
    }
    setPassphrase("");
    onChange(true);
    onClose();
  }

  return (
    <Modal open={open} onClose={onClose} labelledBy="owner-dialog-title" className="owner-dialog">
      <div className="modal-kicker">
        <Asterisk className="h-3.5 w-3.5 text-[var(--aqua)]" />
        Owner tools
      </div>

      {owner ? (
        <>
          <div className="owner-icon is-open">
            <Unlock className="h-6 w-6" />
          </div>
          <h2 id="owner-dialog-title" className="modal-title">
            Studio unlocked
          </h2>
          <p className="modal-copy">
            You have full editorial control. Click any highlighted heading, paragraph or link to
            edit it, or open the customization studio for the warning box, atmosphere, sounds,
            versions and security.
          </p>

          <div className="owner-capabilities">
            <button type="button" className="owner-capability" onClick={() => onOpenCustomize("warning")}>
              <Pencil className="h-4 w-4" />
              <span>
                <strong>Customization studio</strong>
                Warning box, background and sound editing with waveform tools.
              </span>
            </button>
            <button type="button" className="owner-capability" onClick={() => onOpenCustomize("versions")}>
              <History className="h-4 w-4" />
              <span>
                <strong>Version ledger</strong>
                The original site and every saved edit, with restore and delete.
              </span>
            </button>
            <button type="button" className="owner-capability" onClick={() => onOpenCustomize("security")}>
              <Shield className="h-4 w-4" />
              <span>
                <strong>Owner security</strong>
                Change the passphrase; the studio locks when the site is closed.
              </span>
            </button>
            <button type="button" className="owner-capability" onClick={onOpenBackground}>
              <Sliders className="h-4 w-4" />
              <span>
                <strong>Background studio</strong>
                Images, GIFs and looping video with framing and filters.
              </span>
            </button>
            <div className="owner-capability is-static">
              <ImageIcon className="h-4 w-4" />
              <span>
                <strong>Media &amp; folders</strong>
                Add media, create folders and pin favourites from the gallery pages.
              </span>
            </div>
            <div className="owner-capability is-static">
              <SoundOn className="h-4 w-4" />
              <span>
                <strong>Locked on exit</strong>
                This owner session ends automatically when the site is closed or reloaded.
              </span>
            </div>
          </div>

          <div className="owner-status">
            <span className="h-2 w-2 rounded-full bg-[var(--aqua)]" />
            Owner controls are visible across the site
          </div>

          <div className="modal-actions modal-actions-split">
            <button
              type="button"
              className="btn btn-ghost"
              onClick={() => {
                onChange(false);
                onClose();
              }}
            >
              <Lock className="h-3.5 w-3.5" />
              Lock studio
            </button>
            <button
              type="button"
              className="btn btn-aqua"
              onClick={() => {
                onClose();
                onOpenCustomize("warning");
              }}
            >
              Open customization studio
            </button>
          </div>
        </>
      ) : (
        <form onSubmit={unlock}>
          <div className="owner-icon">
            <Lock className="h-6 w-6" />
          </div>
          <h2 id="owner-dialog-title" className="modal-title">
            Owner access
          </h2>
          <p className="modal-copy">
            Visitor upload tools are hidden. Enter the studio passphrase to manage pages, buttons,
            media, sounds, backgrounds and site history.
          </p>

          <label className="field-label" htmlFor="owner-passphrase">
            Studio passphrase
          </label>
          <input
            id="owner-passphrase"
            type="password"
            autoComplete="current-password"
            className="field-input"
            placeholder="Enter passphrase"
            value={passphrase}
            onChange={(event) => {
              setPassphrase(event.target.value);
              if (error) setError("");
            }}
          />
          {error && (
            <p className="field-error" role="alert">
              {error}
            </p>
          )}
          <p className="field-hint owner-security-note">
            <Shield className="h-3.5 w-3.5" />
            The passphrase is never displayed. Owners can change it in Studio → Security. Owner
            mode ends when the site is closed.
          </p>

          <div className="modal-actions">
            <button type="button" className="btn btn-ghost" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="btn btn-aqua" disabled={busy}>
              {busy ? "Checking…" : "Enter studio"}
            </button>
          </div>
        </form>
      )}
    </Modal>
  );
}
