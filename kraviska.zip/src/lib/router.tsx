import { useEffect, useState } from "react";
import type { AnchorHTMLAttributes, ReactNode } from "react";

export type RouteKey =
  | "/"
  | "/links"
  | "/art-example"
  | "/commission-information"
  | "/monthly-offers-and-more"
  | "/payment-methods"
  | "/about-me"
  | "/faqs"
  | "/about-page";

export const ROUTES: RouteKey[] = [
  "/",
  "/links",
  "/art-example",
  "/commission-information",
  "/monthly-offers-and-more",
  "/payment-methods",
  "/about-me",
  "/faqs",
  "/about-page",
];

export const ROUTE_META: Record<
  RouteKey,
  { title: string; label: string; index: string }
> = {
  "/": { title: "Kraviska — Art & Commissions", label: "Index", index: "00" },
  "/links": { title: "Links — Kraviska", label: "Links", index: "01" },
  "/art-example": {
    title: "Art Example — Kraviska",
    label: "Art Example",
    index: "02",
  },
  "/commission-information": {
    title: "Commission Information — Kraviska",
    label: "Commission Information",
    index: "03",
  },
  "/monthly-offers-and-more": {
    title: "Monthly Offers & More — Kraviska",
    label: "Monthly Offers & More",
    index: "04",
  },
  "/payment-methods": {
    title: "Payment Methods — Kraviska",
    label: "Payment Methods",
    index: "05",
  },
  "/about-me": { title: "About Me — Kraviska", label: "About Me", index: "06" },
  "/faqs": { title: "FAQs — Kraviska", label: "FAQs", index: "07" },
  "/about-page": {
    title: "About Page — Kraviska",
    label: "About Page",
    index: "08",
  },
};

/** When the built site is opened directly from disk, use hash URLs. */
const FILE_PROTOCOL =
  typeof window !== "undefined" && window.location.protocol === "file:";

const ALIASES: Record<string, RouteKey> = {
  "/monthly-offers": "/monthly-offers-and-more",
  "/offers": "/monthly-offers-and-more",
  "/about": "/about-me",
  "/art": "/art-example",
  "/commissions": "/commission-information",
};

/** The site may be previewed from a sub-directory; keep that prefix when routing. */
const BASE_PATH = (() => {
  if (typeof window === "undefined") return "/";
  const pathname = window.location.pathname;
  if (/\/index\.html?$/i.test(pathname)) {
    return pathname.replace(/index\.html?$/i, "");
  }
  const known = [...ROUTES, ...Object.keys(ALIASES)]
    .filter((route) => route !== "/")
    .sort((a, b) => b.length - a.length)
    .find((route) => pathname === route || pathname.endsWith(route));
  if (known) {
    const base = pathname.slice(0, pathname.lastIndexOf(known));
    return base || "/";
  }
  if (pathname.endsWith("/")) return pathname;
  const lastSlash = pathname.lastIndexOf("/");
  return lastSlash > 0 ? pathname.slice(0, lastSlash + 1) : "/";
})();

function normalise(pathname: string): string {
  if (!pathname) return "/";
  let clean = pathname;
  if (BASE_PATH !== "/" && clean.startsWith(BASE_PATH)) {
    clean = clean.slice(BASE_PATH.length - 1);
  }
  clean = clean.replace(/\/index\.html$/i, "/");
  clean = clean.replace(/\/+$/, "");
  if (!clean) return "/";
  const hashPath = clean.includes("#/") ? clean.slice(clean.indexOf("#/") + 1) : "";
  if (hashPath) clean = hashPath.replace(/\/+$/, "") || "/";
  return clean;
}

/** Supports both clean paths (/about-me) and hash fallbacks (/#/about-me). */
export function resolveRoute(rawPath?: string): RouteKey {
  const path = normalise(rawPath ?? `${window.location.pathname}${window.location.hash}`);
  if ((ROUTES as string[]).includes(path)) return path as RouteKey;
  if (ALIASES[path]) return ALIASES[path];
  const candidates = [...ROUTES, ...Object.keys(ALIASES)].sort(
    (a, b) => b.length - a.length,
  );
  const match = candidates.find(
    (route) => route !== "/" && (path === route || path.endsWith(route)),
  );
  if (match) return (ALIASES[match] ?? match) as RouteKey;
  return "/";
}

export function hrefFor(to: RouteKey): string {
  // file:// pages cannot reliably push or reopen filesystem paths, so the
  // double-clickable build uses hash URLs (#/links) instead of clean ones.
  if (FILE_PROTOCOL) return to === "/" ? "#/" : `#${to}`;
  if (BASE_PATH === "/") return to;
  return `${BASE_PATH.replace(/\/$/, "")}${to === "/" ? "/" : to}`;
}

const NAVIGATE_EVENT = "kraviska:navigate";
export const LEAVE_EVENT = "kraviska:leave";

export function navigate(to: RouteKey) {
  const next = resolveRoute(to);
  if (FILE_PROTOCOL) {
    if (window.location.hash !== `#${next}`) {
      window.dispatchEvent(new Event(LEAVE_EVENT));
      window.location.hash = next;
    }
    window.dispatchEvent(new Event(NAVIGATE_EVENT));
    window.scrollTo({ top: 0, left: 0, behavior: "auto" });
    return;
  }
  const href = hrefFor(next);
  if (window.location.pathname === href) return;
  window.dispatchEvent(new Event(LEAVE_EVENT));
  if (window.location.pathname !== href) {
    try {
      window.history.pushState({ route: next }, "", href);
    } catch {
      window.location.hash = next;
    }
  }
  window.dispatchEvent(new Event(NAVIGATE_EVENT));
  window.scrollTo({ top: 0, left: 0, behavior: "auto" });
}

export function useRoute(): RouteKey {
  const [route, setRoute] = useState<RouteKey>(() => resolveRoute());

  useEffect(() => {
    const update = () => setRoute(resolveRoute());
    window.addEventListener("popstate", update);
    window.addEventListener(NAVIGATE_EVENT, update);
    window.addEventListener("hashchange", update);
    return () => {
      window.removeEventListener("popstate", update);
      window.removeEventListener(NAVIGATE_EVENT, update);
      window.removeEventListener("hashchange", update);
    };
  }, []);

  return route;
}

type NavLinkProps = Omit<AnchorHTMLAttributes<HTMLAnchorElement>, "href"> & {
  to: RouteKey;
  children: ReactNode;
};

/**
 * An anchor that behaves like a real link (middle-click, copy-link) but
 * navigates client-side without reloading the single-file build.
 */
export function NavLink({ to, children, onClick, ...rest }: NavLinkProps) {
  return (
    <a
      href={hrefFor(to)}
      onClick={(event) => {
        onClick?.(event);
        if (
          event.defaultPrevented ||
          event.metaKey ||
          event.ctrlKey ||
          event.shiftKey ||
          event.altKey ||
          event.button !== 0
        ) {
          return;
        }
        event.preventDefault();
        navigate(to);
      }}
      {...rest}
    >
      {children}
    </a>
  );
}
