import { useEffect, useState } from "react";
import { backdropImage } from "@/assets/images";
import {
  DEFAULT_LABELS,
  DEFAULT_WARNING,
  deleteSiteVersion,
  formatEditedDateTime,
  listSiteVersions,
  resetSiteContent,
  restoreSiteVersion,
  updateSiteContent,
  useSiteContent,
  type SiteLabels,
  type WarningContent,
} from "@/lib/siteContent";
import { useMediaUrl } from "@/lib/mediaStore";
import { playSaved } from "@/lib/audio";
import { changePassphrase, hasCustomPassphrase } from "@/lib/auth";
import { Modal } from "@/components/ui";
import { SoundEditor } from "@/components/SoundEditor";
import {
  AlertBox,
  AlertTriangle,
  Asterisk,
  Check,
  History,
  Lock,
  Pencil,
  RotateCcw,
  Save,
  Shield,
  Sliders,
  SoundOn,
  Trash,
} from "@/components/Icons";

export type StudioTab = "warning" | "labels" | "background" | "sound" | "versions" | "security";

export const STUDIO_TABS: Array<{ id: StudioTab; label: string }> = [
  { id: "warning", label: "Warning box" },
  { id: "labels", label: "Site text" },
  { id: "background", label: "Background" },
  { id: "sound", label: "Sound" },
  { id: "versions", label: "Versions" },
  { id: "security", label: "Security" },
];

const TAB_ICONS = {
  warning: AlertBox,
  labels: Pencil,
  background: Sliders,
  sound: SoundOn,
  versions: History,
  security: Shield,
} as const;

const WARNING_FIELDS: Array<{
  key: keyof WarningContent;
  label: string;
  max: number;
  multiline?: boolean;
  hint?: string;
}> = [
  { key: "kicker", label: "Small label above heading", max: 60 },
  { key: "heading", label: "Warning heading", max: 40 },
  { key: "accent", label: "Accent character", max: 4, hint: "Shown beside the heading, e.g. !" },
  { key: "body", label: "Advisory text", max: 420, multiline: true },
  { key: "okText", label: "Confirm button label", max: 24 },
  { key: "footnote", label: "Small line beneath the button", max: 140 },
];

type LabelField = { key: keyof SiteLabels; name: string };

const LABEL_GROUPS: Array<{ title: string; note: string; fields: LabelField[] }> = [
  {
    title: "Brand & navigation",
    note: "The header, menu button captions and footer.",
    fields: [
      { key: "brand", name: "Brand name" },
      { key: "brandDomain", name: "Brand domain mark" },
      { key: "status", name: "Availability note" },
      { key: "soundOn", name: "Sound-on caption" },
      { key: "soundOff", name: "Sound-off caption" },
      { key: "ownerLabel", name: "Owner button caption" },
      { key: "studioLabel", name: "Studio button caption" },
      { key: "footerTagline", name: "Footer tagline" },
      { key: "footerDomain", name: "Footer domain" },
      { key: "backToIndex", name: "Back-to-index link" },
      { key: "sectionPrefix", name: "Section word" },
      { key: "homeIndexLabel", name: "Home crumb label" },
    ],
  },
  {
    title: "Home & updates",
    note: "Hero details and the bottom updates panel.",
    fields: [
      { key: "heroVolume", name: "Portfolio volume line" },
      { key: "heroDomain", name: "Hero domain" },
      { key: "choosePage", name: "Menu instruction" },
      { key: "indexPrefix", name: "Menu heading" },
      { key: "updatesNumber", name: "Updates eyebrow" },
      { key: "lastEdited", name: "Last-edited label" },
      { key: "lastEditedValue", name: "Last-edited helper" },
      { key: "steward", name: "Steward label" },
      { key: "author", name: "Made-by credit" },
    ],
  },
  {
    title: "Page details",
    note: "Small furniture shared by the inner pages.",
    fields: [
      { key: "established", name: "Established line" },
      { key: "endOfPage", name: "End-of-page note" },
      { key: "homeAddress", name: "Home address label" },
      { key: "domain", name: "Domain plate" },
      { key: "emptyPlaceholder", name: "Empty-state sentence" },
      { key: "noLinks", name: "Empty links heading" },
    ],
  },
  {
    title: "Galleries & folders",
    note: "Archive labels, filters and media type badges.",
    fields: [
      { key: "selectedMedia", name: "Commission/archive heading" },
      { key: "galleryEmpty", name: "Empty gallery heading" },
      { key: "galleryNoteOwner", name: "Gallery note (owner)" },
      { key: "galleryNoteVisitor", name: "Gallery note (visitor)" },
      { key: "curatorView", name: "Curator badge" },
      { key: "viewOnly", name: "View-only badge" },
      { key: "allMedia", name: "All-media filter" },
      { key: "pinned", name: "Pinned filter" },
      { key: "nothingPinned", name: "Empty pinned text" },
      { key: "folderWaiting", name: "Empty folder text" },
      { key: "artistsNote", name: "Artist note label" },
      { key: "mediaImage", name: "Image type label" },
      { key: "mediaVideo", name: "Video type label" },
    ],
  },
  {
    title: "Links",
    note: "Captions that describe where a link goes.",
    fields: [
      { key: "linkPdf", name: "PDF link label" },
      { key: "linkPage", name: "Page link label" },
      { key: "linkExternal", name: "External link label" },
    ],
  },
  {
    title: "Commission documents",
    note: "Drop zones, statuses and the document viewer.",
    fields: [
      { key: "documentDropTitle", name: "Drop-zone title" },
      { key: "documentDropHint", name: "Drop-zone hint" },
      { key: "documentDropHere", name: "Active drop text" },
      { key: "documentReplace", name: "Replace button" },
      { key: "documentClear", name: "Clear button" },
      { key: "documentOpen", name: "Open document button" },
      { key: "documentDownload", name: "Download button" },
      { key: "documentPdf", name: "PDF type label" },
      { key: "documentPages", name: "Image-page word" },
      { key: "documentPagesCount", name: "Page-count word" },
      { key: "documentMissing", name: "Missing document text" },
      { key: "documentEmptyTitle", name: "Not-uploaded status" },
      { key: "documentViewerHint", name: "Viewer hint" },
      { key: "documentReorder", name: "Reorder dialog title" },
      { key: "documentReorderHelp", name: "Reorder dialog help" },
      { key: "documentConfirmPdf", name: "PDF confirm title" },
      { key: "documentConfirmPdfHelp", name: "PDF confirm help" },
      { key: "documentSave", name: "Add-to-site button" },
      { key: "documentCancel", name: "Cancel button" },
      { key: "documentUploadOwnerOnly", name: "Owner-only note" },
      { key: "nowViewing", name: "Viewer eyebrow" },
      { key: "viewerFooter", name: "Viewer footer" },
      { key: "pdfOpenTab", name: "Open-in-tab button" },
      { key: "pdfPreparing", name: "Preparing text" },
    ],
  },
];

export function CustomizeStudio({
  open,
  tab,
  onTab,
  onClose,
  onOpenBackground,
  onLock,
}: {
  open: boolean;
  tab: StudioTab;
  onTab: (tab: StudioTab) => void;
  onClose: () => void;
  onOpenBackground: () => void;
  onLock: () => void;
}) {
  const site = useSiteContent();
  const backgroundUrl = useMediaUrl(site.background.mediaKey);
  const [warning, setWarning] = useState<WarningContent>(site.warning);
  const [warningStatus, setWarningStatus] = useState("");
  const [labelDraft, setLabelDraft] = useState<SiteLabels>(site.labels);
  const [labelStatus, setLabelStatus] = useState("");
  const [versionStatus, setVersionStatus] = useState("");
  const [pendingDelete, setPendingDelete] = useState<string | null>(null);
  const [security, setSecurity] = useState({ current: "", next: "", confirm: "" });
  const [securityStatus, setSecurityStatus] = useState<{ tone: "ok" | "error"; text: string } | null>(null);
  const [passWasCustom, setPassWasCustom] = useState(hasCustomPassphrase());

  useEffect(() => {
    if (!open) return;
    setWarning(site.warning);
    setWarningStatus("");
    setLabelDraft(site.labels);
    setLabelStatus("");
    setSecurity({ current: "", next: "", confirm: "" });
    setSecurityStatus(null);
    setPassWasCustom(hasCustomPassphrase());
    // Only reset the forms when the studio is opened; saving must keep its status.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const versions = listSiteVersions();
  const currentVersion = versions[0];

  function saveWarning() {
    const clean: WarningContent = {
      ...warning,
      kicker: warning.kicker.trim(),
      heading: warning.heading.trim() || "WARNING",
      body: warning.body.trim(),
      okText: warning.okText.trim() || "OK",
      footnote: warning.footnote.trim(),
    };
    updateSiteContent((draft) => {
      draft.warning = clean;
    }, "Warning box customized");
    setWarning(clean);
    setWarningStatus("Warning box saved. It will greet visitors with these words.");
    playSaved();
  }

  function saveLabels() {
    const clean = { ...labelDraft };
    (Object.keys(clean) as Array<keyof SiteLabels>).forEach((key) => {
      if (!clean[key].trim()) clean[key] = DEFAULT_LABELS[key];
    });
    updateSiteContent((draft) => {
      draft.labels = clean;
    }, "Site text updated");
    setLabelDraft(clean);
    setLabelStatus("Every label was saved. Visitors will see the new wording immediately.");
    playSaved();
  }

  function resetLabels() {
    setLabelDraft(DEFAULT_LABELS);
    updateSiteContent((draft) => {
      draft.labels = DEFAULT_LABELS;
    }, "Site labels reset");
    setLabelStatus("The original site wording has been restored.");
  }

  function resetWarning() {
    setWarning(DEFAULT_WARNING);
    updateSiteContent((draft) => {
      draft.warning = DEFAULT_WARNING;
    }, "Warning box reset");
    setWarningStatus("The original warning box has been restored.");
  }

  async function submitPassphrase(event: React.FormEvent) {
    event.preventDefault();
    setSecurityStatus(null);
    if (security.next !== security.confirm) {
      setSecurityStatus({ tone: "error", text: "The new passphrases do not match." });
      return;
    }
    const result = await changePassphrase(security.current, security.next);
    if (!result.ok) {
      setSecurityStatus({ tone: "error", text: result.error ?? "Could not change the passphrase." });
      return;
    }
    setSecurityStatus({ tone: "ok", text: "Passphrase updated. Use it the next time you unlock the studio." });
    setSecurity({ current: "", next: "", confirm: "" });
    setPassWasCustom(true);
    playSaved();
  }

  function restore(id: string) {
    const result = restoreSiteVersion(id);
    setVersionStatus(
      result.ok
        ? "Version restored. It is now the live, latest edited version of the site."
        : result.message ?? "That version could not be restored.",
    );
    if (result.ok) playSaved();
  }

  function removeVersion(id: string) {
    const result = deleteSiteVersion(id);
    setVersionStatus(result.ok ? "Older version deleted." : result.message ?? "Could not delete.");
    setPendingDelete(null);
  }

  return (
    <Modal open={open} onClose={onClose} labelledBy="customize-title" className="customize-dialog">
      <header className="customize-head">
        <div className="customize-heading">
          <span className="modal-kicker">
            <Asterisk className="h-3.5 w-3.5 text-[var(--aqua)]" />
            Owner only / customization studio
          </span>
          <h2 id="customize-title" className="modal-title">
            Shape the site
          </h2>
          <p className="modal-copy">
            The first screen, the atmosphere, the sounds and the site&apos;s history — all stored
            locally and loaded automatically the next time the site opens.
          </p>
        </div>
        <div className="customize-lock">
          <span className="mono-label">Owner session</span>
          <button type="button" className="btn btn-ghost btn-compact" onClick={onLock}>
            <Lock className="h-3.5 w-3.5" />
            Lock studio
          </button>
        </div>
      </header>

      <div className="customize-tabs" role="tablist" aria-label="Customization sections">
        {STUDIO_TABS.map((entry) => {
          const Icon = TAB_ICONS[entry.id];
          return (
            <button
              key={entry.id}
              type="button"
              role="tab"
              aria-selected={tab === entry.id}
              className={`customize-tab ${tab === entry.id ? "is-active" : ""}`}
              onClick={() => onTab(entry.id)}
            >
              <Icon className="h-3.5 w-3.5" />
              {entry.label}
              {entry.id === "versions" && <em>{versions.length}</em>}
            </button>
          );
        })}
      </div>

      <div className="customize-body">
        {tab === "warning" && (
          <div className="warning-editor">
            <div className="warning-editor-fields">
              <div className="studio-section-title">
                <span>
                  <AlertBox className="h-4 w-4" />
                  The first screen
                </span>
                <button
                  type="button"
                  className="text-link"
                  onClick={resetWarning}
                >
                  <RotateCcw className="h-3 w-3" /> Restore original
                </button>
              </div>
              <p className="studio-help">
                This is the advisory visitors see before the site. Only the close X and the
                confirm button can dismiss it; their behaviour stays fixed.
              </p>
              {WARNING_FIELDS.map((field) => (
                <div className="field-block" key={field.key}>
                  <label className="field-label" htmlFor={`warning-${field.key}`}>
                    {field.label}
                  </label>
                  {field.multiline ? (
                    <textarea
                      id={`warning-${field.key}`}
                      className="field-input field-textarea"
                      rows={3}
                      maxLength={field.max}
                      value={warning[field.key]}
                      onChange={(event) =>
                        setWarning((current) => ({ ...current, [field.key]: event.target.value }))
                      }
                    />
                  ) : (
                    <input
                      id={`warning-${field.key}`}
                      className="field-input"
                      maxLength={field.max}
                      value={warning[field.key]}
                      onChange={(event) =>
                        setWarning((current) => ({ ...current, [field.key]: event.target.value }))
                      }
                    />
                  )}
                  {field.hint && <p className="field-hint">{field.hint}</p>}
                </div>
              ))}
              {warningStatus && (
                <p className="sound-status" role="status">
                  <Check className="h-3.5 w-3.5" />
                  {warningStatus}
                </p>
              )}
              <div className="studio-actions">
                <button type="button" className="btn btn-ghost" onClick={() => setWarning(site.warning)}>
                  Discard changes
                </button>
                <button type="button" className="btn btn-aqua" onClick={saveWarning}>
                  <Save className="h-3.5 w-3.5" />
                  Save warning box
                </button>
              </div>
            </div>

            <div className="warning-preview-column">
              <div className="warning-preview-scene">
                <div className="warning-preview-card">
                  <div className="warning-stripes" aria-hidden="true" />
                  <div className="warning-preview-x">×</div>
                  <div className="warning-preview-body">
                    <div className="warning-kicker">
                      <span className="warning-kicker-line" />
                      <AlertTriangle className="h-3 w-3" />
                      <span>{warning.kicker || "Content advisory"}</span>
                      <span className="warning-kicker-line" />
                    </div>
                    <h3 className="warning-preview-title">
                      {warning.heading || "WARNING"}
                      <span>{warning.accent}</span>
                    </h3>
                    <p className="warning-copy">{warning.body}</p>
                    <div className="warning-divider">
                      <span />
                      <Asterisk className="h-3 w-3" />
                      <span />
                    </div>
                    <div className="warning-preview-ok">{warning.okText || "OK"}</div>
                    <p className="warning-footnote">{warning.footnote}</p>
                  </div>
                </div>
                <span className="warning-preview-label">Live preview · not active</span>
              </div>
            </div>
          </div>
        )}

        {tab === "labels" && (
          <div className="labels-tab">
            <div className="studio-section-title">
              <span>
                <Pencil className="h-4 w-4" />
                Site text
              </span>
              <button type="button" className="text-link" onClick={resetLabels}>
                <RotateCcw className="h-3 w-3" /> Restore original wording
              </button>
            </div>
            <p className="studio-help">
              Every fixed caption, label and button on the public site lives here. Page titles,
              paragraphs, FAQ entries, links and image details are edited directly on their pages
              while owner mode is active.
            </p>
            {LABEL_GROUPS.map((group) => (
              <fieldset className="labels-group" key={group.title}>
                <legend>{group.title}</legend>
                <p className="labels-note">{group.note}</p>
                <div className="labels-grid">
                  {group.fields.map((field) => (
                    <label className="label-field" key={field.key}>
                      <span>{field.name}</span>
                      <input
                        className="field-input"
                        value={labelDraft[field.key]}
                        maxLength={220}
                        onChange={(event) =>
                          setLabelDraft((current) => ({
                            ...current,
                            [field.key]: event.target.value,
                          }))
                        }
                      />
                    </label>
                  ))}
                </div>
              </fieldset>
            ))}
            {labelStatus && (
              <p className="sound-status" role="status">
                <Check className="h-3.5 w-3.5" />
                {labelStatus}
              </p>
            )}
            <div className="studio-actions">
              <button type="button" className="btn btn-ghost" onClick={() => setLabelDraft(site.labels)}>
                Discard changes
              </button>
              <button type="button" className="btn btn-aqua" onClick={saveLabels}>
                <Save className="h-3.5 w-3.5" />
                Save site text
              </button>
            </div>
          </div>
        )}

        {tab === "background" && (
          <div className="background-tab">
            <div className="studio-section-title">
              <span>
                <Sliders className="h-4 w-4" />
                Atmosphere
              </span>
            </div>
            <p className="studio-help">
              The background is fixed to the viewport and always covers every screen edge. Upload
              an image, GIF or looping video, then choose Fill, Fit, Stretch or Tile and tune the
              filters.
            </p>
            <div className="background-summary">
              <div
                className="background-summary-thumb"
                style={{
                  backgroundImage: `url(${backgroundUrl ?? backdropImage})`,
                  filter: `brightness(${site.background.filters.brightness}) saturate(${site.background.filters.saturation})`,
                }}
              >
                {site.background.kind === "media" && site.background.mediaType === "video" && (
                  <span className="background-summary-kind">Video</span>
                )}
              </div>
              <div className="background-summary-copy">
                <span className="mono-label">Currently using</span>
                <h3>
                  {site.background.kind === "media"
                    ? site.background.fileName || "Uploaded background"
                    : "Default rain scene"}
                </h3>
                <p>
                  Framing: <strong>{site.background.fit}</strong> · Grain{" "}
                  {site.background.filters.noise.toFixed(2)} · Blur{" "}
                  {site.background.filters.blur.toFixed(1)}px
                </p>
                <button type="button" className="btn btn-aqua" onClick={onOpenBackground}>
                  <Sliders className="h-4 w-4" />
                  Open background studio
                </button>
              </div>
            </div>
            <div className="studio-callout">
              <AlertBox className="h-4 w-4" />
              <span>
                Cover mode is enforced across phones, tablets and desktop so the image or video
                never leaves a bare edge. Tile mode is available for images and GIFs.
              </span>
            </div>
          </div>
        )}

        {tab === "sound" && (
          <div>
            <div className="studio-section-title">
              <span>
                <SoundOn className="h-4 w-4" />
                Sound window
              </span>
            </div>
            <p className="studio-help">
              Choose an interface event, inspect its waveform, select a segment, then trim it, erase
              silences, add room noise, fade and save. The saved take replaces the built-in sound
              for visitors.
            </p>
            <SoundEditor />
          </div>
        )}

        {tab === "versions" && (
          <div className="versions-tab">
            <div className="studio-section-title">
              <span>
                <History className="h-4 w-4" />
                Version ledger
              </span>
              <span className="mini-pill">{versions.length} versions</span>
            </div>
            <p className="studio-help">
              Every saved change adds a new version instead of overwriting the past. The site
              always opens the newest version automatically. Restoring an older one creates a new
              current version, so nothing is lost by looking back.
            </p>
            <div className="version-live">
              <span className="version-live-dot" aria-hidden="true" />
              <span>
                In use now: <strong>Version {currentVersion?.number}</strong> · {currentVersion?.label}
              </span>
              <button
                type="button"
                className="text-link"
                onClick={() => {
                  resetSiteContent();
                  playSaved();
                  setVersionStatus("Restored the original unedited site as a new version.");
                }}
              >
                <RotateCcw className="h-3 w-3" /> Back to original
              </button>
            </div>
            {versionStatus && (
              <p className="sound-status" role="status">
                <Check className="h-3.5 w-3.5" />
                {versionStatus}
              </p>
            )}
            <ol className="version-list">
              {versions.map((version, index) => {
                const isCurrent = index === 0;
                const isOriginal = version.id === "baseline";
                return (
                  <li className={`version-row ${isCurrent ? "is-current" : ""}`} key={version.id}>
                    <span className="version-number">v{version.number}</span>
                    <div className="version-copy">
                      <div className="version-title">
                        <strong>{version.label}</strong>
                        {isCurrent && <em className="version-badge is-live">Latest · in use</em>}
                        {isOriginal && <em className="version-badge">Original site</em>}
                      </div>
                      <span className="version-date">{formatEditedDateTime(version.createdAt)}</span>
                    </div>
                    <div className="version-actions">
                      <button
                        type="button"
                        className="btn btn-ghost btn-compact"
                        onClick={() => restore(version.id)}
                        disabled={isCurrent}
                        title={isCurrent ? "This version is already live" : "Restore this version"}
                      >
                        <RotateCcw className="h-3 w-3" />
                        {isCurrent ? "In use" : "Restore"}
                      </button>
                      {pendingDelete === version.id ? (
                        <>
                          <button
                            type="button"
                            className="btn btn-danger btn-compact"
                            onClick={() => removeVersion(version.id)}
                          >
                            Confirm
                          </button>
                          <button
                            type="button"
                            className="btn btn-ghost btn-compact"
                            onClick={() => setPendingDelete(null)}
                          >
                            Cancel
                          </button>
                        </>
                      ) : (
                        <button
                          type="button"
                          className="icon-action icon-action-danger"
                          onClick={() => setPendingDelete(version.id)}
                          disabled={isCurrent || isOriginal}
                          aria-label={`Delete version ${version.number}`}
                          title={
                            isCurrent || isOriginal
                              ? "The original and current versions are protected"
                              : "Delete this older version"
                          }
                        >
                          <Trash className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </div>
                  </li>
                );
              })}
            </ol>
            <p className="field-hint">
              The original unedited site and the version currently in use cannot be deleted. Older
              snapshots can be removed to keep the ledger tidy.
            </p>
          </div>
        )}

        {tab === "security" && (
          <div className="security-tab">
            <div className="studio-section-title">
              <span>
                <Shield className="h-4 w-4" />
                Owner security
              </span>
              <span className={`mini-pill ${passWasCustom ? "mini-pill-aqua" : ""}`}>
                {passWasCustom ? "Custom passphrase set" : "Initial passphrase in use"}
              </span>
            </div>
            <div className="studio-callout">
              <Lock className="h-4 w-4" />
              <span>
                The sign-in window never shows the passphrase. The studio also locks itself when the
                site is closed or reloaded, so an unattended browser cannot stay in owner mode.
              </span>
            </div>
            <form className="security-form" onSubmit={submitPassphrase}>
              <label className="field-label" htmlFor="current-passphrase">
                Current passphrase
              </label>
              <input
                id="current-passphrase"
                type="password"
                className="field-input"
                autoComplete="current-password"
                value={security.current}
                onChange={(event) => setSecurity({ ...security, current: event.target.value })}
              />
              <div className="security-grid">
                <div>
                  <label className="field-label mt-4" htmlFor="new-passphrase">
                    New passphrase
                  </label>
                  <input
                    id="new-passphrase"
                    type="password"
                    className="field-input"
                    autoComplete="new-password"
                    minLength={6}
                    value={security.next}
                    onChange={(event) => setSecurity({ ...security, next: event.target.value })}
                  />
                </div>
                <div>
                  <label className="field-label mt-4" htmlFor="confirm-passphrase">
                    Confirm new passphrase
                  </label>
                  <input
                    id="confirm-passphrase"
                    type="password"
                    className="field-input"
                    autoComplete="new-password"
                    minLength={6}
                    value={security.confirm}
                    onChange={(event) => setSecurity({ ...security, confirm: event.target.value })}
                  />
                </div>
              </div>
              <p className="field-hint">At least six characters. Change it immediately if an unwanted sign-in occurs.</p>
              {securityStatus && (
                <p
                  className={securityStatus.tone === "ok" ? "sound-status" : "field-error"}
                  role="status"
                >
                  {securityStatus.tone === "ok" && <Check className="h-3.5 w-3.5" />}
                  {securityStatus.text}
                </p>
              )}
              <div className="studio-actions">
                <button type="button" className="btn btn-ghost" onClick={onLock}>
                  <Lock className="h-3.5 w-3.5" />
                  Lock now
                </button>
                <button type="submit" className="btn btn-aqua">
                  <Shield className="h-3.5 w-3.5" />
                  Update passphrase
                </button>
              </div>
            </form>
          </div>
        )}
      </div>

      <footer className="customize-foot">
        <span className="mono-label">
          <Asterisk className="mr-1.5 inline h-3 w-3 text-[var(--aqua)]" />
          Saved locally · loaded automatically
        </span>
        <button type="button" className="btn btn-ghost" onClick={onClose}>
          Close studio
        </button>
      </footer>
    </Modal>
  );
}
